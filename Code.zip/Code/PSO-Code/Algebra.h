#ifndef BEHAVIORAL_GENE_SIMULATION_ALGEBRA_H
#define BEHAVIORAL_GENE_SIMULATION_ALGEBRA_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <functional>
#include <cstring>
#include <numeric>
#include <iomanip>

using namespace std;


class Algebra {
public:
    Algebra() = default;

    ~Algebra()= default;

    // Deep Coping
    template <typename T>
    static T* deepCopy(T* original, int size) {
        T* copy = new T[size];
        for (int i = 0; i < size; ++i) {
            copy[i] = original[i];
        }
        return copy;
    }

    template <typename T>
    static void deleteArray(T* array) {
        delete[] array;
    }

    template <typename T>
    static T** deepCopy(T** original, int rows, int cols) {
        T** copy = new T*[rows];
        for (int i = 0; i < rows; ++i) {
            copy[i] = new T[cols];
            for (int j = 0; j < cols; ++j) {
                copy[i][j] = original[i][j];
            }
        }
        return copy;
    }

    template <typename T>
    static void deleteArray(T** array, int rows) {
        for (int i = 0; i < rows; ++i) {
            delete[] array[i];
        }
        delete[] array;
    }

    static int* vec2Arr(const vector<int>& vec) {
        int* arr = new int[vec.size()];
        memcpy(arr, vec.data(), vec.size() * sizeof(int));
        return arr;
    }

    static double* vec2Arr(const vector<double>& vec) {
        double* arr = new double[vec.size()];
        memcpy(arr, vec.data(), vec.size() * sizeof(double));
        return arr;
    }

    static vector<int> arr2Vec(int* arr, size_t size) {
        vector<int> vec(arr, arr + size);
        return vec;
    }

    static vector<double> arr2Vec(double* arr, size_t size) {
        vector<double> vec(arr, arr + size);
        return vec;
    }

    static int** vecOfVec2Arr(const vector<vector<int>>& vec) {
        int** arr = new int*[vec.size()];
        for (size_t i = 0; i < vec.size(); ++i) {
            arr[i] = new int[vec[i].size()];
            memcpy(arr[i], vec[i].data(), vec[i].size() * sizeof(int));
        }
        return arr;
    }

    static double** vecOfVec2Arr(const vector<vector<double>>& vec) {
        double** arr = new double*[vec.size()];
        for (size_t i = 0; i < vec.size(); ++i) {
            arr[i] = new double[vec[i].size()];
            memcpy(arr[i], vec[i].data(), vec[i].size() * sizeof(double));
        }
        return arr;
    }

    static vector<vector<int>> arr2VecOfVec(int** arr, size_t numRows, size_t numCols) {
        vector<vector<int>> vec(numRows, vector<int>(numCols));
        for (size_t i = 0; i < numRows; ++i) {
            vec[i].assign(arr[i], arr[i] + numCols);
        }
        return vec;
    }

    static vector<vector<double>> arr2VecOfVec(double** arr, size_t numRows, size_t numCols) {
        vector<vector<double>> vec(numRows, vector<double>(numCols));
        for (size_t i = 0; i < numRows; ++i) {
            vec[i].assign(arr[i], arr[i] + numCols);
        }
        return vec;
    }

    static int** oneDArr2TwoDArray(const int* array, int row_size, int col_size) {
        // Allocate memory for the 2D array
        int** array2D = new int*[row_size];
        for (int i = 0; i < row_size; ++i) {
            array2D[i] = new int[col_size];
        }

        // Fill the 2D array with elements from the 1D array
        for (int i = 0; i < row_size * col_size; ++i) {
            int row = i / col_size;
            int col = i % col_size;
            array2D[row][col] = array[i];
        }

        return array2D;
    }

    static double** oneDArr2TwoDArray(const double* array, int row_size, int col_size) {
        // Allocate memory for the 2D array
        double** array2D = new double*[row_size];
        for (int i = 0; i < row_size; ++i) {
            array2D[i] = new double[col_size];
        }

        // Fill the 2D array with elements from the 1D array
        for (int i = 0; i < row_size * col_size; ++i) {
            int row = i / col_size;
            int col = i % col_size;
            array2D[row][col] = array[i];
        }

        return array2D;
    }

    // Helper function to free the memory allocated for the 2D array
    static void free2DArray(int** array2D, int row_size) {
        for (int i = 0; i < row_size; ++i) {
            delete[] array2D[i];
        }
        delete[] array2D;
    }

    static void free2DArray(double** array2D, int row_size) {
        for (int i = 0; i < row_size; ++i) {
            delete[] array2D[i];
        }
        delete[] array2D;
    }

    static string arrToString(double** array, int row_size, int col_size) {
        ostringstream oss;
        oss << fixed << setprecision(3); // Set the precision to 5 digits

        for (int i = 0; i < row_size; ++i) {
            oss << "\t\t";
            for (int j = 0; j < col_size; ++j) {
                oss << array[i][j];
                if (j < col_size - 1) {
                    oss << "\t";
                }
            }
            if (i < row_size - 1){
                oss << "\n";
            }
        }

        return oss.str();
    }

    static string arrToString(int* array, int size) {
        ostringstream oss;
//        oss << fixed << setprecision(3); // Set the precision to 5 digits
        for (int i = 0; i < size; ++i) {
            oss << array[i];
            if (i < size - 1) {
                oss << "\t";
            }
        }

        return oss.str();
    }

    static string arrToString(double* array, int size) {
        ostringstream oss;
        oss << fixed << setprecision(3); // Set the precision to 5 digits
        for (int i = 0; i < size; ++i) {
            oss << array[i];
            if (i < size - 1) {
                oss << "\t";
            }
        }

        return oss.str();
    }

    template <typename T>
    static string vectorToString(const vector<T>& vec, int precision = 3) {
        ostringstream oss;
        oss << fixed << setprecision(precision); // Set the precision for floating-point numbers

        for (size_t i = 0; i < vec.size(); ++i) {
            oss << vec[i];
            if (i < vec.size() - 1) {
                oss << "\t"; // Separator between elements
            }
        }

        return oss.str();
    }

    // Function to compute the sum of a vector
    static int computeSumOfVector(const vector<int>& vec) {
        return accumulate(vec.begin(), vec.end(), 0.0);
    }

    // Function to compute the sum of a vector
    static double computeSumOfVector(const vector<double>& vec) {
        return accumulate(vec.begin(), vec.end(), 0.0);
    }

    // Function to sum the absolute value of every element in a vector
    static double sumOfAbsoluteValues(const vector<double>& vec) {
        return accumulate(vec.begin(), vec.end(), 0.0, [](double acc, double val) {
            return acc + fabs(val);
        });
    }

    // Function to compute the mean of a vector
    static double computeMeanOfVector(const vector<int>& vec) {
        double sum = computeSumOfVector(vec);
        return sum / vec.size();
    }

    // Function to compute the mean of a vector
    static double computeMeanOfVector(const vector<double>& vec) {
        double sum = computeSumOfVector(vec);
        return sum / vec.size();
    }

    // Function to compute the magnitude of a vector
    static double computeMagnitude(const vector<int> &vec) {
        double sumOfSquares = 0.0;
        for (const auto &val : vec) {
            sumOfSquares += val * val;
        }
        return sqrt(sumOfSquares);
    }

    // Function to compute the magnitude of a vector
    static double computeMagnitude(const vector<double> &vec) {
        double sumOfSquares = 0.0;
        for (const double &val : vec) {
            sumOfSquares += val * val;
        }
        return sqrt(sumOfSquares);
    }

    // Function to compute the mean vector
    static vector<double> computeMeanVector(const vector<vector<int>> &cabAllocations) {
        int numRows = cabAllocations.size();
        int numCols = cabAllocations[0].size();
        vector<double> meanVector(numCols, 0.0);

        // Sum each column
        for (const auto &row : cabAllocations) {
            for (int j = 0; j < numCols; ++j) {
                meanVector[j] += row[j];
            }
        }

        // Divide by the number of rows to get the mean
        for (int j = 0; j < numCols; ++j) {
            meanVector[j] /= numRows;
        }

        return meanVector;
    }

    // Function to compute the mean vector
    static vector<double> computeMeanVector(const vector<vector<double>> &cabAllocations) {
        int numRows = cabAllocations.size();
        int numCols = cabAllocations[0].size();
        vector<double> meanVector(numCols, 0.0);

        // Sum each column
        for (const auto &row : cabAllocations) {
            for (int j = 0; j < numCols; ++j) {
                meanVector[j] += row[j];
            }
        }

        // Divide by the number of rows to get the mean
        for (int j = 0; j < numCols; ++j) {
            meanVector[j] /= numRows;
        }

        return meanVector;
    }

    // Function to calculate the magnitude of a vector
    static vector<double> normalizeVector(const vector<double> &vec, string norm="L2") {
        double magnitude = 0.0;
        if (norm == "L1"){
            magnitude = sumOfAbsoluteValues(vec);
        }
        else if (norm == "L2") {
            magnitude = computeMagnitude(vec);
        }
        else {
            throw invalid_argument( norm.append(" does not exist!"));
        }
        vector<double> normalizedVec(vec.size());
        for (size_t i = 0; i < vec.size(); ++i) {
            normalizedVec[i] = vec[i] / magnitude;
        }
        return normalizedVec;
    }

    static double computeCosineSimilarity(const vector<int>& vec1, const vector<int>& vec2) {
        double dot_prod = computeDotProduct(vec1, vec2);
        double mag1 = computeMagnitude(vec1);
        double mag2 = computeMagnitude(vec2);
        return dot_prod / (mag1 * mag2);
    }

    static double computeCosineSimilarity(const vector<double>& vec1, const vector<double>& vec2) {
        double dot_prod = computeDotProduct(vec1, vec2);
        double mag1 = computeMagnitude(vec1);
        double mag2 = computeMagnitude(vec2);
        return dot_prod / (mag1 * mag2);
    }

    // Function to compute the dot product of two vectors
    static int computeDotProduct(const vector<int> &vec1, const vector<int> &vec2) {
        if (vec1.size() != vec2.size()) {
            cerr << "Error: Vectors must be of the same length to compute dot product." << endl;
            return 0.0;
        }

        int dotProduct = 0.0;
        for (size_t i = 0; i < vec1.size(); ++i) {
            dotProduct += vec1[i] * vec2[i];
        }

        return dotProduct;
    }

    // Function to compute the dot product of two vectors
    static double computeDotProduct(const vector<double> &vec1, const vector<double> &vec2) {
        if (vec1.size() != vec2.size()) {
            cerr << "Error: Vectors must be of the same length to compute dot product." << endl;
            return 0.0;
        }

        double dotProduct = 0.0;
        for (size_t i = 0; i < vec1.size(); ++i) {
            dotProduct += vec1[i] * vec2[i];
        }

        return dotProduct;
    }

    // Function to compute the absolute error between two vectors
    static double computeAbsoluteError(const vector<double>& vec1, const vector<double>& vec2) {
        if (vec1.size() != vec2.size()) {
            cerr << "Error: Vectors must be of the same length to compute absolute error." << endl;
            return 0.0;
        }

        double absoluteError = 0.0;
        for (size_t i = 0; i < vec1.size(); ++i) {
            double error = fabs(vec1[i] - vec2[i]);
            absoluteError += error;
        }

        return absoluteError;
    }

    // Function to compute the squared error between two vectors
    static double computeSquaredError(const vector<double>& vec1, const vector<double>& vec2) {
        if (vec1.size() != vec2.size()) {
            cerr << "Error: Vectors must be of the same length to compute squared error." << endl;
            return 0.0;
        }

        double squaredError = 0.0;
        for (size_t i = 0; i < vec1.size(); ++i) {
            double error = vec1[i] - vec2[i];
            squaredError += error * error;
        }

        return squaredError;
    }

    static int numPosGives(const std::vector<double>& vec, int playerIndex) {
        int count = 0;
        for (size_t i = 0; i < vec.size(); ++i) {
            if (i != static_cast<size_t>(playerIndex) && vec[i] > 0) {
                ++count;
            }
        }
        return count;
    }

    static double tokensGiven(const std::vector<double>& vec, int playerIdx) {
        double sum = 0.0;
        for (size_t i = 0; i < vec.size(); ++i) {
            if (i != static_cast<size_t>(playerIdx) && vec[i] > 0) {
                sum += vec[i];
            }
        }
        return sum;
    }


    // Function to compute the squared error between two vectors
    static double computePropertyScore(const vector<double>& vec1, const vector<double>& vec2, int playerIdx) {
        if (vec1.size() != vec2.size()) {
            cerr << "Error: Vectors must be of the same length to compute squared error." << endl;
            return 0.0;
        }

        int numPlayers = vec1.size();

        double cuenta = 0.0;
        // Property: Give to the right # of players
        int a = numPosGives(vec2, playerIdx);
        int b = numPosGives(vec1, playerIdx);
        double rel = numPlayers / 2;
        cuenta += max(0.0, (rel - fabs(a - b)) / rel);

        // Property: Give to the right players
        if (a > 0) {
            int cnt = 0;
            for (int i = 0; i < numPlayers; i++) {
                if (i == playerIdx) continue;

                if ((vec2[i] > 0) && (vec1[i] > 0))
                    cnt ++;
                if ((vec2[i] <= 0) && (vec1[i] > 0))
                    cnt --;
                if ((vec2[i] <= 0) && (vec1[i] > 0))
                    cnt --;
            }
            cuenta += max(0.0, (double)cnt / a);

            // Property: Give the right # of tokens in total
            int c = tokensGiven(vec2, playerIdx);
            int d = tokensGiven(vec1, playerIdx);

            cuenta += max(0.0, (c - fabs(c - d)) / (double)c);

            // Property: Give the right # of tokens to each player
            int off = 0;
            for (int i = 0; i < numPlayers; i++) {
                if (vec2[i] > 0)
                    off += abs(vec2[i] - vec1[i]);
            }
            cuenta += max(0.0, (c - off) / (double)c);
        }

        // Property: Keeping the right number of tokens
        cuenta += max(0.0, (numPlayers - fabs(vec2[playerIdx] - vec1[playerIdx])) / (double)numPlayers);

        vector<int> allocSteal, propSteal;
        for (int i = 0; i < numPlayers; i++) {
            if (vec2[i] < 0)
                allocSteal.push_back(i);
            if (vec1[i] < 0)
                propSteal.push_back(i);
        }
        if (allocSteal.size() > 0) {
            // Property: Steal when stealing happens
            if (propSteal.size() > 0)
                cuenta += 1.0;

            // Property: Steal right number of tokens
            int actual = 0, proposed = 0;
            for (int i = 0; i < allocSteal.size(); i++)
                actual -= vec2[allocSteal[i]];
            for (int i = 0; i < propSteal.size(); i++)
                proposed -= vec1[propSteal[i]];
            cuenta += max(0.0, (numPlayers - fabs(actual - proposed)) / numPlayers);

            // Property: Stealing from the right player
            for (int i = 0; i < allocSteal.size(); i++) {
                if (vec1[allocSteal[i]] < 0)
                    cuenta += 1.0;
            }
        }

        // Property: Penalize giving to a player instead of stealing from them
        // Property: Penalize stealing from a player instead of giving to them
        bool gaveBad = false;
        bool stoleBad = false;
        for (int i = 0; i < numPlayers; i++) {
            if ((vec2[i] > 0) && (vec1[i] < 0))
                stoleBad = true;
            else if ((vec2[i] < 0) && (vec1[i] > 0))
                gaveBad = true;
        }
        if (stoleBad)
            cuenta -= 1.0;
        if (gaveBad)
            cuenta -= 1.0;

        return -cuenta;
    }


    // Function to transpose a matrix
    static vector<vector<int>> transpose(const vector<vector<int>>& matrix) {
        if (matrix.empty()) return {};

        size_t numRows = matrix.size();
        size_t numCols = matrix[0].size();
        vector<vector<int>> transposed(numCols, vector<int>(numRows));

        for (size_t i = 0; i < numRows; ++i) {
            for (size_t j = 0; j < numCols; ++j) {
                transposed[j][i] = matrix[i][j];
            }
        }

        return transposed;
    }

    // Function to transpose a matrix
    static vector<vector<double>> transpose(const vector<vector<double>>& matrix) {
        if (matrix.empty()) return {};

        size_t numRows = matrix.size();
        size_t numCols = matrix[0].size();
        vector<vector<double>> transposed(numCols, vector<double>(numRows));

        for (size_t i = 0; i < numRows; ++i) {
            for (size_t j = 0; j < numCols; ++j) {
                transposed[j][i] = matrix[i][j];
            }
        }

        return transposed;
    }

    static int** transpose(int** array, int row_size, int col_size) {
        // Allocate memory for the transposed array
        auto** transposedArray = new int*[col_size];
        for (int i = 0; i < col_size; ++i) {
            transposedArray[i] = new int[row_size];
        }

        // Transpose the elements
        for (int i = 0; i < row_size; ++i) {
            for (int j = 0; j < col_size; ++j) {
                transposedArray[j][i] = array[i][j];
            }
        }

        return transposedArray;
    }

    static double** transpose(double** array, int row_size, int col_size) {
        // Allocate memory for the transposed array
        auto** transposedArray = new double*[col_size];
        for (int i = 0; i < col_size; ++i) {
            transposedArray[i] = new double[row_size];
        }

        // Transpose the elements
        for (int i = 0; i < row_size; ++i) {
            for (int j = 0; j < col_size; ++j) {
                transposedArray[j][i] = array[i][j];
            }
        }

        return transposedArray;
    }

};


#endif //BEHAVIORAL_GENE_SIMULATION_ALGEBRA_H


