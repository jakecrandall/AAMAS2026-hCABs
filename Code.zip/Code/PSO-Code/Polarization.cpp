#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <cmath>

//#include "defs.h"
// #include "GeneAgent.h"

using namespace std;

#define MAX_PLAYERS     20

struct GroupPrefs {
    GroupPrefs(int _i, int _j, int _numPlayers, double _G[MAX_PLAYERS][MAX_PLAYERS], vector<double> _mag) {
        for (int k = 0; k < _numPlayers; k++) {
            for (int m = 0; m < _numPlayers; m++) {
                G[k][m] = _G[k][m];
            }
        }
        // G = _G;
        i = _i;
        j = _j;
        numPlayers = _numPlayers;
        mag = _mag;
        total = 0.0;
        samesame = 0.0;
        polarization = 0.0;
        groupWeight_i = groupWeight_j = groupWeight_neutral = minWeightScale = 0.0;

        getPrefs();
    }

    ~GroupPrefs() {}

    void getPrefs() {
        for (int k = 0; k < numPlayers; k++) {
            if (k == i)
                for_i.insert(k);
            else if (k == j)
                for_j.insert(k);
            else {
                double threshold = 0.04 * mag[k];
                if (G[i][k] > (G[j][k] + threshold))
                    for_i.insert(k);
                else if (G[j][k] > (G[i][k] + threshold))
                    for_j.insert(k);
                else
                    neutral.insert(k);
            }
        }
    }

    void compare(GroupPrefs *other, int i, int j, vector<double> w) {
        double totalEste = 0;
        double samesameEste = 0.0;
        for (set<int>::iterator itr = for_i.begin(); itr != for_i.end(); itr++) {
            totalEste += w[*itr];
            if (i < j) {
                if (other->for_i.find(*itr) != other->for_i.end())
                    samesameEste += 1.0 * w[*itr];
                else if (other->neutral.find(*itr) != other->neutral.end())
                    samesameEste += 0.5 * w[*itr];
            }
            else {
                if (other->for_j.find(*itr) != other->for_j.end())
                    samesameEste += 1.0 * w[*itr];
                else if (other->neutral.find(*itr) != other->neutral.end())
                    samesameEste += 0.5 * w[*itr];
            }
        }

        for (set<int>::iterator itr = for_j.begin(); itr != for_j.end(); itr++) {
            totalEste += w[*itr];
            if (i < j) {
                if (other->for_j.find(*itr) != other->for_j.end())
                    samesameEste += 1.0 * w[*itr];
                else if (other->neutral.find(*itr) != other->neutral.end())
                    samesameEste += 0.5 * w[*itr];
            }
            else {
                if (other->for_i.find(*itr) != other->for_i.end())
                    samesameEste += 1.0 * w[*itr];
                else if (other->neutral.find(*itr) != other->neutral.end())
                    samesameEste += 0.5 * w[*itr];
            }
        }

        for (set<int>::iterator itr = neutral.begin(); itr != neutral.end(); itr++) {
            totalEste += w[*itr];// / 2.0;
        }

        // cout << "    " << i << "," << j << ": " << samesameEste << " / " << totalEste << endl;

        total += totalEste;
        samesame += samesameEste;

        polarization = (((samesame * minWeightScale) / total) - 0.5) / 0.5;
    }

    void computeWeights(vector<double> w) {
        for (set<int>::iterator itr = for_i.begin(); itr != for_i.end(); itr++)
            groupWeight_i += w[*itr];
        for (set<int>::iterator itr = for_j.begin(); itr != for_j.end(); itr++)
            groupWeight_j += w[*itr];
        for (set<int>::iterator itr = neutral.begin(); itr != neutral.end(); itr++)
            groupWeight_neutral += w[*itr];

        double minWeight = groupWeight_i;
        if (groupWeight_j < groupWeight_i)
            minWeight = groupWeight_j;
        if (minWeight < 0.2)
            minWeightScale = minWeight / 0.2;
        else
            minWeightScale = 1.0;
    }

    void print() {
        cout << "for_" << i << ": ";
        for (set<int>::iterator itr = for_i.begin(); itr != for_i.end(); itr++)
            cout << *itr << ", ";
        cout << " (" << groupWeight_i << "); for_" << j << ": ";
        for (set<int>::iterator itr = for_j.begin(); itr != for_j.end(); itr++)
            cout << *itr << ", ";
        cout << " (" << groupWeight_j << "); neutral: ";
        for (set<int>::iterator itr = neutral.begin(); itr != neutral.end(); itr++)
            cout << *itr << ", ";
        cout << " (" << groupWeight_neutral << ") -> " << polarization << endl;
    }

    set<int> for_i, for_j, neutral;
    int i, j, numPlayers;
    double G[MAX_PLAYERS][MAX_PLAYERS], polarization;
    vector<double> mag;
    double total, samesame;
    double groupWeight_i, groupWeight_j, groupWeight_neutral, minWeightScale;
};

struct EconAction {
    double givePerc, takePerc, keepPerc;
    int giveCount, takeCount, keepCount;

    EconAction() {
        giveCount = takeCount = keepCount = 0;
    }
};

struct RoundInfo {
    int numPlayers;
    int round;
    double alpha, beta, give, keep, steal;
    double popularities[MAX_PLAYERS];
    double transactions[MAX_PLAYERS][MAX_PLAYERS];
    double influences[MAX_PLAYERS][MAX_PLAYERS];
    string playerTypes[MAX_PLAYERS];
};

vector<string> parse(const string& s) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(s);
    while (getline(tokenStream, token, ','))
        tokens.push_back(token);
    return tokens;
}


RoundInfo readRound(string line, int numPlayers, bool flip) {
    RoundInfo rnd;
    vector<string> words = parse(line);

    rnd.numPlayers = numPlayers;
    rnd.round = stoi(words[0]);
    rnd.alpha = stof(words[1]);
    rnd.beta = stof(words[2]);
    rnd.give = stof(words[3]);
    rnd.keep = stof(words[4]);
    rnd.steal = stof(words[5]);

    for (int i = 0; i < numPlayers; i++) {
        rnd.popularities[i] = stof(words[i+6]);
    }

    int ind = 6 + numPlayers;
    for (int i = 0; i < numPlayers; i++) {
        for (int j = 0; j < numPlayers; j++) {
            rnd.transactions[i][j] = stof(words[ind]);
            ind ++;
        }
    }

    for (int i = 0; i < numPlayers; i++) {
        for (int j = 0; j < numPlayers; j++) {
            if (!flip)
                rnd.influences[i][j] = stof(words[ind]);
            else
                rnd.influences[j][i] = stof(words[ind]);
            ind ++;
        }
    }

    // bring this back in if it is for the human-bot studies
    // for (int i = 0; i < numPlayers; i++) {
    //     rnd.playerTypes[i] = words[ind];
    //     ind ++;
    // }

    return rnd;
}

int getNumPlayers(string line) {
    vector<string> words = parse(line);
    int i = 6;
    while (words[i][0] == 'p') {
        i++;
    }

    return i - 6;
}

vector<RoundInfo> readGame(string fnombre, bool flip) {
    cout << fnombre << endl;
    ifstream input(fnombre);

    if (!input) {
        cout << "Could not read file " << fnombre << endl;
        exit(-1);
    }

    vector<RoundInfo> v;

    string line;

    getline(input, line);  // read header
    int numPlayers = getNumPlayers(line);
    int c = 0;
    while (!input.eof()) {
        getline(input, line);
        // cout << c << ": " << line << " is it?" << endl;
        if (line.length() > 2) {
            v.push_back(readRound(line, numPlayers, flip));
            c++;
        }

        // if (c == 1) {
        //     cout << "Types for game: " << fnombre << endl;
        //     for (int i = 0; i < 8; i++) {
        //         cout << "  " << v[c-1].playerTypes[i] << endl;
        //         // cout << "  " << v[0].playerTypes[i] << endl;
        //     }
        // }
    }

    input.close();

    return v;
}

double getAveReciprocity(vector<RoundInfo> esto) {
    int numEdges = 0;
    int both = 0;
    for (int r = 1; r < esto.size(); r++) {
        for (int i = 0; i < esto[0].numPlayers; i++) {
            for (int j = i; j < esto[0].numPlayers; j++) {
                if (i == j) continue;
                if ((esto[r].transactions[j][i] > 0) && (esto[r].transactions[i][j]))
                    both ++;
                if (esto[r].transactions[i][j] > 0)
                    numEdges ++;
                if (esto[r].transactions[j][i] > 0)
                    numEdges ++;
            }
        }
    }

    // cout << "numEdges: " << numEdges << endl;
    // cout << "numReciprocations: " << both << endl;

    return (2.0 * both) / numEdges;
}

double getAveDegree(vector<RoundInfo> esto) {
    double overallAverage = 0.0;
    for (int r = 1; r < esto.size(); r++) {
        double aveDegree = 0.0;
        for (int i = 0; i < esto[0].numPlayers; i++) {
            int numConnections = 0;
            for (int j = 0; j < esto[0].numPlayers; j++) {
                // cout << (int)(esto[r].transactions[i][j]*numTokens) << ", ";
                if (i == j) continue;
                if ((esto[r].transactions[i][j] > 0) && (esto[r].transactions[j][i] > 0))
                    numConnections ++;
            }
            aveDegree += numConnections / (double)(esto[0].numPlayers-1);
        }
        aveDegree /= esto[0].numPlayers;
        // cout << "Degree in round " << r << " is " << aveDegree << endl;
        overallAverage += aveDegree;
    }

    return overallAverage / (esto.size()-1);
}

EconAction getEconomicActionPercentages(vector<RoundInfo> esto) {
    EconAction econ;
    int numTokens = 2 * esto[0].numPlayers;
    for (int r = 1; r < esto.size(); r++) {
        for (int i = 0; i < esto[0].numPlayers; i++) {
            for (int j = 0; j < esto[0].numPlayers; j++) {
                if (i == j)
                    econ.keepCount += (int)(esto[r].transactions[i][j] * numTokens);
                else if (esto[r].transactions[i][j] > 0)
                    econ.giveCount += (int)(esto[r].transactions[i][j] * numTokens);
                else
                    econ.takeCount -= (int)(esto[r].transactions[i][j] * numTokens);
            }
        }
    }

    int total = econ.takeCount + econ.keepCount + econ.giveCount;
    econ.takePerc = econ.takeCount / (double)total;
    econ.keepPerc = econ.keepCount / (double)total;
    econ.givePerc = econ.giveCount / (double)total;

    return econ;
}

double getClusterCoef(vector<RoundInfo> esto) {
    int numPlayers = esto[0].numPlayers;
    // create the friend graph
    int **amigos = new int*[numPlayers];
    for (int i = 0; i < numPlayers; i++)
        amigos[i] = new int[numPlayers];

    int numPossible = 0;
    int numFound = 0;
    for (int r = 1; r < esto.size(); r++) {
        // // get the amigo graph
        int nuevoPossible = 0;
        int nuevoFound = 0;
        for (int i = 0; i < numPlayers; i++) {
            for (int j = 0; j < numPlayers; j++) {
                if ((esto[r].transactions[i][j] > 0) && (i != j)) {
                    for (int k = 0; k < numPlayers; k++) {
                        if ((j == k) || (i == k)) continue;
                        if (esto[r].transactions[i][k] > 0) {
                            nuevoPossible ++;
                            if (esto[r].transactions[j][k])
                                nuevoFound ++;
                        }
                    }
                }
            }
        }
        cout << (nuevoFound / (double)nuevoPossible) << endl;
        // cout << "nuevoPossibe after " << r << ": " << nuevoPossible << endl;

        numFound += nuevoFound;
        numPossible += nuevoPossible;

        // cout << "T:" << endl;
        // for (int i = 0; i < numPlayers; i++) {
        //     for (int j = 0; j < numPlayers; j++) {
        //         cout << (int)(esto[r].transactions[i][j]*2*numPlayers) << ", ";
        //     }
        //     cout << endl;
        // }

        // cout << endl << "Amigos: " << endl;
        // for (int i = 0; i < numPlayers; i++) {
        //     for (int j = 0; j < numPlayers; j++) {
        //         cout << amigos[i][j] << ", ";
        //     }
        //     cout << endl;
        // }


        // see how many of my friends are connected to each other

        // for (int i = 0; i < numPlayers; i++) {
        //     for (int j = 0; j < numPlayers; j++) {
        //         if (amigos[i][j] == 1) {
        //             for (int k = j+1; k < numPlayers; k++) {
        //                 if (amigos[i][k] == 1) {
        //                     numPossible ++;
        //                     if (amigos[j][k] == 1)
        //                         numFound ++;
        //                 }
        //             }
        //         }
        //     }
        // }
    }

    cout << "numFound: " << numFound << endl;
    cout << "numPossible: " << numPossible << endl;

    for (int i = 0; i < numPlayers; i++)
        delete[] amigos[i];
    delete[] amigos;

    return numFound / (double)numPossible;
}

double computePolarization(RoundInfo theRound) {
    vector<double> mag;
    vector<double> weights1, weights2;
    double totalWeight = 0.0;
    for (int k = 0; k < theRound.numPlayers; k++) {
        double s = 0.0;
        for (int m = 0; m < theRound.numPlayers; m++)
            s += fabs(theRound.influences[m][k]);
        mag.push_back(s);
        totalWeight += s;
    }
    // cout << "totalWeight: " << totalWeight << " -> ";
    for (int k = 0; k < theRound.numPlayers; k++) {
        weights1.push_back(1.0);
        weights2.push_back(mag[k] / totalWeight);
        // cout << weights2[k] << ", ";
    }
    // cout << endl;

    map<int, GroupPrefs *> groupings;
    for (int i = 0; i < theRound.numPlayers; i++) {
        for (int j = i+1; j < theRound.numPlayers; j++) {
            // determine sets specifying preferences for i or j (indifferent, for_i, for_j)
            GroupPrefs *group = new GroupPrefs(i, j, theRound.numPlayers, theRound.influences, mag);
            group->computeWeights(weights2);
            int index = i * theRound.numPlayers + j;
            // cout << index << endl;
            groupings[index] = group;
        }
    }

    // cout << "now compute polarization" << endl;

    double maxPolarization = 0.0;
    for (int i = 0; i < theRound.numPlayers; i++) {
        for (int j = i+1; j < theRound.numPlayers; j++) {
            int indexOrig = i * theRound.numPlayers + j;
            // groupings[indexOrig]->print();

            // compute polarization here
            for (set<int>::iterator itr_i = groupings[indexOrig]->for_i.begin(); itr_i != groupings[indexOrig]->for_i.end(); itr_i++) {
                for (set<int>::iterator itr_j = groupings[indexOrig]->for_j.begin(); itr_j != groupings[indexOrig]->for_j.end(); itr_j++) {
                    int index;
                    if (*itr_i > *itr_j)
                        index = *itr_j * theRound.numPlayers + *itr_i;
                    else
                        index = *itr_i * theRound.numPlayers + *itr_j;
                    // cout << *itr_i << " and " << *itr_j << " compare: " << index << endl;
                    groupings[indexOrig]->compare(groupings[index], *itr_i, *itr_j, weights1);
                }
            }

            // groupings[indexOrig]->print();
            // if (((groupings[indexOrig]->for_i.size() + groupings[indexOrig]->for_j.size()) > numPlayers * 0.7) && (groupings[indexOrig]->for_i.size() > 1) && (groupings[indexOrig]->for_j.size() > 1)) {
            // if ((groupings[indexOrig]->groupWeight_i > 0.2) && (groupings[indexOrig]->groupWeight_j > 0.2)) {
            if (groupings[indexOrig]->polarization > maxPolarization)
                maxPolarization = groupings[indexOrig]->polarization;
            // }
        }
    }

    cout << "Polarization: " << maxPolarization << endl;
    return maxPolarization;
}

double getPolarizationCoef(vector<RoundInfo> esto) {
    double polarizationCoef = 0.0;
    for (int r = 1; r < esto.size(); r++) {
        polarizationCoef += computePolarization(esto[r]);
    }

    return polarizationCoef / esto.size();
}

int main(int argc, char *argv[]) {
    // vector<RoundInfo> esto = readGame("../Results/theGameLogs/log_1000_1000.csv", false);

    vector<RoundInfo> esto;
    vector<vector<RoundInfo>> estos;

    // Human test set (experienced)
    string testing_set_dir =
        "/home/watchtower/Datasets/JuniorHighNetwork/BehaviorStudy/JHG_DataSets/study_games/testing_set_experienced/";
    esto = readGame(testing_set_dir + "jhg_BKFV.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_CHLN.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_DWMG.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_KRJP.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_LWRB.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_MCQF.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_MQCK.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_NMDQ.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_NZKH.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_RWFL.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_SNCR.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_TDRP.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_VWJH.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_WTMR.csv", true);
    estos.push_back(esto);
    esto = readGame(testing_set_dir + "jhg_ZQXV.csv", true);
    estos.push_back(esto);


    // Human training set (experienced)
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BPMQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BQKP.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BZQK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_CXJR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_CZWN.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DKRV.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DNQX.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DTHW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DZJR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_FVSP.csv", true);

    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GCLQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GHBK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GJDV.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GJFD.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GSCW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GSDH.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GXVS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_HLCK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_HNCQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KBRW.csv", true);

    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KCSF.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KWMG.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KXRJ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_LZFC.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MCDL.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MCZG.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MDJS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MXGN.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_NRFS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_NTLM.csv", true);

    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_QLHS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_RPLW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_RSGK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_SHFC.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_SMBD.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TDGM.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TKRW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TSJW.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VBLN.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VCNK.csv", true);

    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VSJQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VSKR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WBHQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WCJQ.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WQDS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WQJR.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XQRT.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XTWS.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XWHK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_ZRHK.csv", true);
    // vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_ZSLG.csv", true);


    // cout << esto.size() << endl;

    // double degree = getAveDegree(esto);
    // cout << "Average degree was " << degree << endl;

    // EconAction econ = getEconomicActionPercentages(esto);

    // cout << "Percent keep: " << (econ.keepPerc * 100.0) << endl;
    // cout << "Percent take: " << (econ.takePerc * 100.0) << endl;
    // cout << "Percent give: " << (econ.givePerc * 100.0) << endl;

    // double recip = getAveReciprocity(esto);

    // cout << "Reciprocity: " << recip << endl;

    // double clusterCoef = getClusterCoef(esto);

    // cout << "clusterCoef: " << clusterCoef << endl;

    double averagePolarizationCoef = 0;
    for (int i =0; i < estos.size(); i++){
        double polarizationCoef = getPolarizationCoef(estos[i]);
        cout << "Polarization Coef: " << polarizationCoef << endl;

        averagePolarizationCoef += polarizationCoef;
    }


    cout << "Average Polarization Coef: " << averagePolarizationCoef / estos.size() << endl;




    return 0;
}
