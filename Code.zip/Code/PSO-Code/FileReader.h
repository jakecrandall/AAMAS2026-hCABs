#ifndef BEHAVIORAL_GENE_SIMULATION_FILEREADER_H
#define BEHAVIORAL_GENE_SIMULATION_FILEREADER_H

#include <iostream>
#include <vector>
#include <string>
#include <filesystem>

using namespace std;

class FileReader {
public:
    // Function to list files in a directory
    static vector<string> listFilesInDirectory(const string& dir) {
        vector<string> files;

        for (const auto& entry : filesystem::directory_iterator(dir)) {
            if (entry.is_regular_file()) { // Ensure it's a file (not a directory)
                files.push_back(dir + entry.path().filename().string());
            }
        }

        return files;
    }
};

// #include <iostream>
// #include <vector>
// #include <string>
// #include <dirent.h>
// #include <sys/stat.h>

// using namespace std;

// class FileReader {
// public:
//     // Function to list files in a directory
//     static vector<string> listFilesInDirectory(const string& dir) {
//         vector<string> files;
//         DIR* dp = opendir(dir.c_str()); // Open the directory
//         if (dp == nullptr) {
//             cerr << "Cannot open directory: " << dir << endl;
//             return files;
//         }
//
//         struct dirent* entry;
//         struct stat fileStat;
//
//         while ((entry = readdir(dp)) != nullptr) {
//             string fullPath = dir + "/" + entry->d_name;
//             if (stat(fullPath.c_str(), &fileStat) == 0 && S_ISREG(fileStat.st_mode)) {
//                 files.push_back(entry->d_name); // Add the file to the list
//             }
//         }
//
//         closedir(dp); // Close the directory
//         return files;
//     }
// };



#endif //BEHAVIORAL_GENE_SIMULATION_FILEREADER_H
