#ifndef GENEAGENTMOD_H
#define GENEAGENTMOD_H

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <sstream>
#include <fstream>
#include <chrono>
#include <unistd.h>
#include <climits>
#include <queue>
#include <cmath>

#include "defs.h"
#include "AbstractAgent.h"
#include "ToString.h"
#include "CommunityEvaluation.h"
#include "GeneAgent.h"
#include "Algebra.h"


using namespace std;
using namespace ToString;

struct RoundStateInfo {
private:
    bool stateHasBeenSet;
    double *_popularities = nullptr;
    double **_influence = nullptr;
    int *_groupCat = nullptr;
    int playerIdx;
    int roundNum;
    int numPlayers;
    int numTokens;
    int remainingToks;
    set<int> selectedCommunity;
    vector< set<int> > communities;

    double *tally, *unpaidDebt, *punishableDebt, *expectedReturn, *scaledBackNums;
    double ave_return, received_value, invested_value, ROI;
    int *prevAllocations, *attackAlloc, nPlayers;
    int *theCurComm;
    double **prevInfluence, **inflPos, **inflNeg, **inflNegPrev, **sumInflPos, **newSteals, *inflPos_sumcol, *inflPos_sumrow;
    double *attacksWithMe, *othersAttacksOn, *badGuys, *badGuysCopy;
    double inflictedDamageRatio, expectedDefendFriendDamage;
    double coalitionTarget, underAttack;
    double *meImporta, *keepingStrength;

public:

    RoundStateInfo() {
        stateHasBeenSet = false;
    }

    ~RoundStateInfo() {
        if (_popularities != nullptr) {
            delete[] _popularities;
            _popularities = nullptr;
        }
        if (_influence != nullptr) {
            for (int i = 0; i < numPlayers; ++i) {
                delete[] _influence[i];
            }
            delete[] _influence;
            _influence = nullptr;
        }
        if (_groupCat != nullptr) {
            delete[] _groupCat;
            _groupCat = nullptr;
        }
    }

    void saveRoundStateInfo(int _playerIdx, int _roundNum, int _numPlayers, int _numTokens, int _remainingToks, double *_popularities, double **_influence, set<int> _selectedCommunity, vector< set<int> > _communities, int *_groupCat) {
        stateHasBeenSet = true;
        playerIdx = _playerIdx;
        roundNum = _roundNum;
        numPlayers = _numPlayers;
        numTokens = _numTokens;
        remainingToks = _remainingToks;
        setPopularities(_popularities);
        setInfluence(_influence);
        selectedCommunity = _selectedCommunity;
        communities = _communities;
        setGroupCat(_groupCat);
    }

    int getPlayerIdx() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return playerIdx;
    }

    void setPlayerIdx(int playerIdx) {
        RoundStateInfo::playerIdx = playerIdx;
    }

    int getRoundNum() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return roundNum;
    }

    void setRoundNum(int roundNum) {
        RoundStateInfo::roundNum = roundNum;
    }

    int getNumPlayers() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return numPlayers;
    }

    void setNumPlayers(int numPlayers) {
        RoundStateInfo::numPlayers = numPlayers;
    }

    int getNumTokens() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return numTokens;
    }

    void setNumTokens(int numTokens) {
        RoundStateInfo::numTokens = numTokens;
    }

    int getRemainingToks() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return remainingToks;
    }

    void setRemainingToks(int remainingToks) {
        RoundStateInfo::remainingToks = remainingToks;
    }

    const set<int> &getSelectedCommunity() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return selectedCommunity;
    }

    void setSelectedCommunity(const set<int> &selectedCommunity) {
        RoundStateInfo::selectedCommunity = selectedCommunity;
    }

    const vector<set<int>> &getCommunities() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return communities;
    }

    void setCommunities(const vector<set<int>> &communities) {
        RoundStateInfo::communities = communities;
    }

    double *getPopularities() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return _popularities;
    }

    void setPopularities(double *popularities) {
        if (_popularities != nullptr) {
            delete[] _popularities;
            _popularities = nullptr;
        }
        _popularities = Algebra::deepCopy(popularities, numPlayers);
    }

    double **getInfluence() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return _influence;
    }

    void setInfluence(double **influence) {
        if (_influence != nullptr) {
            for (int i = 0; i < numPlayers; ++i) {
                delete[] _influence[i];
            }
            delete[] _influence;
            _influence = nullptr;
        }
        _influence = Algebra::deepCopy(influence, numPlayers, numPlayers);
    }

    int *getGroupCat() const {
        if (!stateHasBeenSet) {
            throw "the state has not been set!";
        }
        return _groupCat;
    }

    void setGroupCat(int *groupCat) {
        if (_groupCat != nullptr) {
            delete[] _groupCat;
            _groupCat = nullptr;
        }
        _groupCat = Algebra::deepCopy(groupCat, numPlayers);
    }
};

class GeneAgentMod : public GeneAgent {

protected:
    int count;
    double relativeFitness, absoluteFitness;
    int numPlayers;

    int *myGeneMods, numGeneMods;
    bool playedGenes;
    string dirSTATE;
    RoundStateInfo roundStateInfo;

public:
    using GeneAgent::GeneAgent;

    struct Node {
        int index;
        double influence;

        // Custom comparator for priority queue (max-heap behavior)
        bool operator<(const Node& other) const {
            return influence < other.influence; // Max heap based on influence
        }
    };

    struct attackProfileObject {
        int numPlayers, playerIndex;
        double* whoToAttack; // Who to Attack (negative values represent a desire not to attack)
        double* amountToAttack; // How much to Attack (negative values represent a desire not to attack)
        double* gainFromAttack; // Desire to attack
        int numberOfProfiles = 1;
        string name = "";

    private:
        void _construct(int _numPlayers, int _playerIndex, string _name) {
            numPlayers = _numPlayers;
            playerIndex = _playerIndex;
            whoToAttack = new double[numPlayers];
            amountToAttack = new double[numPlayers];
            gainFromAttack = new double[numPlayers];
            for (int i = 0; i < numPlayers; ++i) {
                whoToAttack[i] = 0;
                amountToAttack[i] = 0;
                gainFromAttack[i] = 0;
            }
            name = _name;
        }

        int determineWhoToAttack() {
            int result = 0;
            for (int i = 0; i < numPlayers; ++i) {
                if (whoToAttack[i] > whoToAttack[result]) {
                    result = i;
                }
            }
            if (result == playerIndex) {
                return -1;
            }
            return result;
        }

    public:
        attackProfileObject(int _numPlayers, int _playerIndex, string _name) {
            _construct(_numPlayers, _playerIndex, _name);
        }

        attackProfileObject(int _numPlayers, int _playerIndex, attackObject object, string _name) {
            _construct(_numPlayers, _playerIndex, _name);
            if (object.index != -1){
                whoToAttack[object.index] = object.amount;
                amountToAttack[object.index] = object.amount;
                gainFromAttack[object.index] = object.gain;
            }
        }

        ~attackProfileObject() {
            delete[] whoToAttack;
            delete[] amountToAttack;
            delete[] gainFromAttack;
        }

        int tokenAllocation(int remainingToks, int* attackToks){
            int whoToAttackIndex = determineWhoToAttack();
            int attackTokens = amountToAttack[whoToAttackIndex];

            if (attackTokens > remainingToks) {
                attackToks[whoToAttackIndex] = remainingToks;
                return remainingToks;
            }
            attackToks[whoToAttackIndex] = attackTokens;
            return attackTokens;
        }

        // Copy assignment operator
        attackProfileObject& operator=(const attackProfileObject& other) {
            if (this == &other) return *this;

            delete[] whoToAttack;
            delete[] amountToAttack;
            delete[] gainFromAttack;

            numPlayers = other.numPlayers;
            playerIndex = other.playerIndex;
            numberOfProfiles = other.numberOfProfiles;

            whoToAttack = new double[numPlayers];
            amountToAttack = new double[numPlayers];
            gainFromAttack = new double[numPlayers];

            for (int i = 0; i < numPlayers; ++i) {
                whoToAttack[i] = other.whoToAttack[i];
                amountToAttack[i] = other.amountToAttack[i];
                gainFromAttack[i] = other.gainFromAttack[i];
            }
            return *this;
        }

        // Overload the + operator
        attackProfileObject operator+(const attackProfileObject& other) const {
            if (numPlayers != other.numPlayers) {
                throw std::runtime_error("There is a mismatch of players!");
            }

            attackProfileObject result(numPlayers, playerIndex, "createdThroughAddition");
            for (int i = 0; i < numPlayers; ++i) {
                result.whoToAttack[i] = whoToAttack[i] + other.whoToAttack[i];
                result.amountToAttack[i] = amountToAttack[i] + other.amountToAttack[i];
                result.gainFromAttack[i] = gainFromAttack[i] + other.gainFromAttack[i];
            }
            result.numberOfProfiles = numberOfProfiles + other.numberOfProfiles;

            return result;
        }

        // Overload the * operator
        attackProfileObject operator*(const int scalar) const {
            // Create a new object with the same number of players and player index
            attackProfileObject result(numPlayers, playerIndex, this->name);

            for (int i = 0; i < numPlayers; ++i) {
                result.whoToAttack[i] = whoToAttack[i] * scalar;
                result.amountToAttack[i] = amountToAttack[i] * scalar;
                result.gainFromAttack[i] = gainFromAttack[i] * scalar;
            }
            return result;
        }


    };

    // Constructor for the child class
    GeneAgentMod(string geneStr, int _numGeneCopies, string geneModStr) : GeneAgent(geneStr, _numGeneCopies){
        if (geneModStr == "") {
            numGeneMods = predef_NUMGENEMODS * numGeneCopies;
            myGeneMods = new int[numGeneMods];
            for (int i = 0; i < numGeneMods; i++) {
                myGeneMods[i] = rand() % 101;
            }
        }
        else {
            // printf("%s\n", geneStr.c_str());
            vector<string> words = parse(geneModStr);
            numGeneMods = words.size()-1;

            if (numGeneMods != (predef_NUMGENEMODS * numGeneCopies)) {
                printf("confusion about the number of genes I should have; %i vs %i\n", predef_NUMGENEMODS, numGeneMods);
                exit(1);
            }

            myGeneMods = new int[numGeneMods];
            for (int i = 1; i < numGeneMods+1; i++)    // // // put +1 back once generate it
                myGeneMods[i-1] = stoi(words[i]);
        }
    }


//    ~GeneAgentMod(){
//
//    }

    // Function to calculate percolation centrality using a priority queue
    vector<double> calculatePercolationCentrality(int startNode, int numNodes, double** adjacencyMatrix) {
        // Normalize the adjacency matrix
        vector<vector<double>> normalizedAdjacencyMatrix(numNodes, vector<double>(numNodes));
        double sum = 0;
        for (int i = 0; i < numNodes; ++i) {
            for (int j = 0; j < numNodes; ++j) {
                sum += adjacencyMatrix[i][j];
            }
        }
        sum /= numNodes;

        for (int i = 0; i < numNodes; ++i) {
            for (int j = 0; j < numNodes; ++j) {
                normalizedAdjacencyMatrix[i][j] = adjacencyMatrix[i][j] / sum;
            }
        }

        
        // Centrality score for each node
        vector<double> percolationCentrality(numNodes, 0.0);

        // Priority queue (max heap), starting with the source node
        priority_queue<Node> pq;

        // Vector to track visited nodes
        vector<bool> visited(numNodes, false);

        // Vector to track influence strength per node
        vector<double> influenceStrength(numNodes, 0.0);

        // Start from the source node with full influence
        pq.push({startNode, 1.0});
        influenceStrength[startNode] = 1.0;

        while (!pq.empty()) {
            Node currentNode = pq.top();
            pq.pop();

            int currentIndex = currentNode.index;
            double currentInfluence = currentNode.influence;

            // Skip if already visited
            if (visited[currentIndex]) continue;
            visited[currentIndex] = true;

            // Update percolation centrality for the current node
            percolationCentrality[currentIndex] += currentInfluence;

            // Explore all neighbors
            for (int neighbor = 0; neighbor < numNodes; ++neighbor) {
                double weight = normalizedAdjacencyMatrix[currentIndex][neighbor];
                if (weight > 0 && !visited[neighbor]) {
                    // Influence is propagated based on the weight
                    double newInfluence = currentInfluence * (weight);  // Normalized influence propagation
                    if (newInfluence > influenceStrength[neighbor]) {
                        influenceStrength[neighbor] = newInfluence;
                        pq.push({neighbor, newInfluence});  // Push neighbor with updated influence
                    }
                }
            }
        }

        return percolationCentrality;
    }

    int* resetAllocationArray(int* allocationArray, int numPlayers){
        for (int i = 0; i < numPlayers; ++i) {
            allocationArray[i] = 0;
        }
        return allocationArray;
    }

    /// New methods for discrimination on who to attack

    virtual attackProfileObject thereWasAnAttack() {
        // detect if there was an Attack
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "thereWasAnAttack");
    }

    virtual attackProfileObject unsucessfulTrading() {
        //
//        roundStateInfo.getDebt();

        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "unsucessfulTrading");
    }

    virtual attackProfileObject youAreMyFriend() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "youAreMyFriend");
    }

    virtual attackProfileObject youOweMe() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "youOweMe");
    }

    virtual attackProfileObject tooPowerfulPerson() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "tooPowerfulPerson");
    }

    virtual attackProfileObject tooPowerfulFriendships() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "tooPowerfulFriendships");
    }

    virtual attackProfileObject tooPowerfulGroup() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "tooPowerfulGroup");
    }

    virtual attackProfileObject tooWeakPerson() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "tooWeakPerson");
    }

    virtual attackProfileObject tooWeakFriendships() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "tooWeakFriendships");
    }

    virtual attackProfileObject tooWeakGroup() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "tooWeakGroup");
    }

    virtual attackProfileObject youWereAttacked() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "youWereAttacked");
    }

    virtual attackProfileObject youAttackedMyGroup() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "youAttackedMyGroup");
    }

    virtual attackProfileObject youAttackedMyFriend() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "youAttackedMyFriend");
    }

    virtual attackProfileObject youAttackedMe() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "youAttackedMe");
    }

    virtual attackProfileObject youAttackedSomebody() {
        //
        return attackProfileObject(roundStateInfo.getNumPlayers(), roundStateInfo.getNumTokens(), "youAttackedSomebody");
    }

    /// Modified quienAtaco function

    virtual int quienAtaco(int roundNum, int playerIdx, int numPlayers, int numTokens, int remainingToks, double *popularities, double **influence, set<int> selectedCommunity, vector< set<int> > communities, int *attackToks) {
        for (int i = 0; i < numPlayers; i++)
            attackToks[i] = 0;

        if (remainingToks <= 0)
            return 0;

        int numAttackToks = 0;
        int *groupCat = new int[numPlayers];

        groupCompare(numPlayers, playerIdx, popularities, communities, groupCat);

        attackProfileObject pillageChoice = attackProfileObject(numPlayers, playerIdx, pillageTheVillage(roundNum, playerIdx, numPlayers, selectedCommunity, numTokens, remainingToks, popularities, influence, groupCat), "pillage");
        attackProfileObject vengeanceChoice = attackProfileObject(numPlayers, playerIdx, takeVengence(roundNum, playerIdx, numPlayers, selectedCommunity, numTokens, remainingToks, popularities, influence), "vengeance");
        attackProfileObject defendFriendChoice = attackProfileObject(numPlayers, playerIdx, defendFriend(playerIdx, roundNum, numPlayers, numTokens, remainingToks, popularities, influence, selectedCommunity, communities, groupCat), "defence");

        roundStateInfo.saveRoundStateInfo(playerIdx, roundNum, numPlayers, numTokens, remainingToks, popularities, influence, selectedCommunity, communities, groupCat);
        attackProfileObject thereWasAnAttackChoice = thereWasAnAttack();
        attackProfileObject unsuccessfulTradingChoice = unsucessfulTrading();
        attackProfileObject youAreMyFriendChoice = youAreMyFriend();
        attackProfileObject youOweMeChoice = youOweMe();
        attackProfileObject tooPowerfulPersonChoice = tooPowerfulPerson();
        attackProfileObject tooPowerfulFriendshipsChoice = tooPowerfulFriendships();
        attackProfileObject tooPowerfulGroupChoice = tooPowerfulGroup();
        attackProfileObject tooWeakPersonChoice = tooWeakPerson();
        attackProfileObject tooWeakFriendshipsChoice = tooWeakFriendships();
        attackProfileObject tooWeakGroupChoice = tooWeakGroup();
        attackProfileObject youWereAttackedChoice = youWereAttacked();
        attackProfileObject youAttackedMyGroupChoice = youAttackedMyGroup();
        attackProfileObject youAttackedMyFriendChoice = youAttackedMyFriend();
        attackProfileObject youAttackedMe1youAttackedMeChoice = youAttackedMe();
        attackProfileObject youAttackedSomebodyChoice = youAttackedSomebody();


        bool printSummary = true;
        if (printSummary){
            // Look at which each choice is saying to steal from
            int* allocationArray = new int[numPlayers];
            resetAllocationArray(allocationArray, numPlayers);

            pillageChoice.tokenAllocation(remainingToks, allocationArray);
            print("pillageChoice      : ", str(allocationArray, numPlayers));
            resetAllocationArray(allocationArray, numPlayers);

            vengeanceChoice.tokenAllocation(remainingToks, allocationArray);
            print("vengeanceChoice    : ", str(allocationArray, numPlayers));
            resetAllocationArray(allocationArray, numPlayers);

            defendFriendChoice.tokenAllocation(remainingToks, allocationArray);
            print("defendFriendChoice : ", str(allocationArray, numPlayers));
            resetAllocationArray(allocationArray, numPlayers);

            print();

            delete[] allocationArray;
        }


        // Combine profile objects
        attackProfileObject attackChoice = pillageChoice * myGeneMods[GENEMOD_pillageWeighting]
                + vengeanceChoice * myGeneMods[GENEMOD_vengeanceWeighting]
                + defendFriendChoice * myGeneMods[GENEMOD_defenseWeighting]
                + thereWasAnAttackChoice * myGeneMods[GENEMOD_thereWasAnAttack]
                + unsuccessfulTradingChoice * myGeneMods[GENEMOD_unsuccessfulTrading]
                + youAreMyFriendChoice * myGeneMods[GENEMOD_youAreMyFriend]
                + youOweMeChoice * myGeneMods[GENEMOD_youOweMe]
                + tooPowerfulPersonChoice * myGeneMods[GENEMOD_tooPowerfulPerson]
                + tooPowerfulFriendshipsChoice * myGeneMods[GENEMOD_tooPowerfulFriendships]
                + tooPowerfulGroupChoice * myGeneMods[GENEMOD_tooPowerfulGroup]
                + tooWeakPersonChoice * myGeneMods[GENEMOD_tooWeakPerson]
                + tooWeakFriendshipsChoice * myGeneMods[GENEMOD_tooWeakFriendships]
                + tooWeakGroupChoice * myGeneMods[GENEMOD_tooWeakGroup]
                + youWereAttackedChoice * myGeneMods[GENEMOD_youWereAttacked]
                + youAttackedMyGroupChoice * myGeneMods[GENEMOD_youAttackedMyGroup]
                + youAttackedMyFriendChoice * myGeneMods[GENEMOD_youAttackedMyFriend]
                + youAttackedMe1youAttackedMeChoice * myGeneMods[GENEMOD_youAttackedMe1youAttackedMe]
                + youAttackedSomebodyChoice * myGeneMods[GENEMOD_youAttackedSomebody];


        // Calculate token allocations based on attack profile
        numAttackToks = attackChoice.tokenAllocation(remainingToks, attackToks);

        delete[] groupCat;

        return numAttackToks;
    }


};

#endif