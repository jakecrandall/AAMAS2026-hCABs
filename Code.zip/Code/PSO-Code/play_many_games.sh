c++ /home/watchtower/CLionProjects/Behavioral-Gene-Simulation/GeneSimulation_cpp/play_many_games.cpp -o play_many_games

/home/watchtower/CLionProjects/Behavioral-Gene-Simulation/GeneSimulation_cpp/play_many_games play /home/watchtower/Datasets/JuniorHighNetwork/BehaviorStudy/JHG_DataSets/gene_training/best_bots/CAB-v1.csv /home/watchtower/Datasets/JuniorHighNetwork/BehaviorStudy/JHG_DataSets/swarm_optimization/cosine_human_all.csv 0 8 0 30 best_agents equal 30 nondeterministic basicConfig varied /home/watchtower/Datasets/JuniorHighNetwork/BehaviorStudy/JHG_DataSets/simulated_games/hcab_mean_human_all/ 1000

