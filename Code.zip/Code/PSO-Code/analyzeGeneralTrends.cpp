#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

#define MAX_PLAYERS     10

struct RoundInfo {
    int numPlayers;
    int round;
    double alpha, beta, give, keep, steal;
    double popularities[MAX_PLAYERS];
    double transactions[MAX_PLAYERS][MAX_PLAYERS];
    double influences[MAX_PLAYERS][MAX_PLAYERS];
};

vector<string> parse(const string& s) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(s);
    while (getline(tokenStream, token, ','))
        tokens.push_back(token);
    return tokens;
}


RoundInfo readRound(string line, int numPlayers) {
    RoundInfo rnd;
    vector<string> words = parse(line);

    rnd.numPlayers = numPlayers;
    rnd.round = stoi(words[0]);
    rnd.alpha = stof(words[1]);
    rnd.beta = stof(words[2]);
    rnd.give = stof(words[3]);
    rnd.keep = stof(words[4]);
    rnd.steal = stof(words[5]);

    for (int i = 0; i < numPlayers; i++) {
        rnd.popularities[i] = stof(words[i+6]);
    }

    int ind = 6 + numPlayers;
    for (int i = 0; i < numPlayers; i++) {
        for (int j = 0; j < numPlayers; j++) {
            rnd.transactions[i][j] = stof(words[ind]);
            ind ++;
        }
    }

    for (int i = 0; i < numPlayers; i++) {
        for (int j = 0; j < numPlayers; j++) {
            rnd.influences[i][j] = stof(words[ind]);
            ind ++;
        }
    }

    return rnd;
}

int getNumPlayers(string line) {
    vector<string> words = parse(line);
    int i = 6;
    while (words[i][0] == 'p') {
        i++;
    }

    return i - 6;
}

vector<RoundInfo> readGame(string fnombre) {
    cout << fnombre << endl;
    ifstream input(fnombre);

    if (!input) {
        cout << "Could not read file " << fnombre << endl;
        exit(-1);
    }

    vector<RoundInfo> v;

    string line;

    getline(input, line);  // read header
    int numPlayers = getNumPlayers(line);
    int c = 0;
    while (!input.eof()) {
        getline(input, line);
        if (line.length() > 2) {
            v.push_back(readRound(line, numPlayers));
            c++;
        }
    }

    input.close();

    return v;
}

double getSocialWelfare(double popularities[MAX_PLAYERS], int numPlayers) {
    double s = 0.0;
    for (int i = 0; i < numPlayers; i++) {
        s += popularities[i];
    }
    return s / numPlayers;
}

void logSamples(ofstream& output, int gen, string config) {
    for (int trial = 0; trial < 30; trial ++) {
        string fnombre = "../Results/RndGames_" + to_string(gen) + "_10_30_" + config + "/game_" + to_string(trial) + ".csv";
        vector<RoundInfo> v = readGame(fnombre);
        for (int i = 0; i <= 30; i+=5) {
            output << gen << "_" << config << "," << trial << "," << i << "," << getSocialWelfare(v[i].popularities, v[i].numPlayers) << endl;
        }
    }
}

int main(int argc, char *argv[]) {
    ofstream output("../Analysis/csvs/trends.csv");
    output << "Generation_Config,Trial,Round,SocialWelfare" << endl;

    logSamples(output, 9, "equal");
    logSamples(output, 9, "step");
    logSamples(output, 49, "equal");
    logSamples(output, 49, "step");

    output.close();

    return 0;
}