#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <functional>
#include <cstring>
#include <numeric>
#include <limits>
#include <cstdlib>
#include <ctime>
#include <thread>
// #include <pthread>
#include <future>
#include <chrono>

#include "ToString.h"
#include "Algebra.h"
#include "FileReader.h"

#include "AbstractAgent.h"
#include "GeneAgent.h"
#include "GeneAgentMod.h"
#include "GeneAgentHMod.h"
#include "RandomAgent.h"
#include "TFTAgent.h"
#include "HumanAgent.h"
#include "CoOpAgent.h"
#include "assassinAgent.h"
#include "JHGEngine.h"
#include <mutex>

mutex gBest_mutex;  // Global mutex for synchronization


using namespace std;
using namespace ToString;

// global variables
bool output2Console = false;

struct PopularityMetrics {
    double avePop, endPop, relPop;
};


vector<string> split(const string& s, char delim=',') {
    vector<string> tokens;
    string token;
    istringstream tokenStream(s);
    while (getline(tokenStream, token, delim))
        tokens.push_back(token);
    return tokens;
}

pair<vector<int>, vector<int>> splitVector(const vector<int>& genes, int n) {
    vector<int> first(genes.begin(), genes.begin() + n); // 0 to (n-1)
    vector<int> second(genes.begin() + n, genes.end());  // n to (size-1)
    return {first, second};
}


GeneAgent **loadPopulationsFromFile(const string& theFolder, int theGen, int popSize, int numGeneCopies, const string& varied, const string folderNum) {
    // allocate memory for theGenePools
    GeneAgent **theGenePools = new GeneAgent*[popSize];
    string fnombre = theFolder + "/" + folderNum + "/" + to_string(numGeneCopies) + "pool_" + varied + "pop/gen_" + to_string(theGen) + ".csv";
//    string fnombre = theFile;
    ifstream input(fnombre);
    for (int i = 0; i < popSize; i++) {
        // read in all of the GeneAgents
        // cout << "theGen: " << theGen << endl;
        // string fnombre = theFolder + "/" + to_string(i) + "/gen_" + to_string(theGen) + ".csv";

        string line;
        getline(input, line);
        vector<string> words = split(line);

        theGenePools[i] = new GeneAgent(words[0], numGeneCopies);
        theGenePools[i]->count = stoi(words[1]);
        theGenePools[i]->relativeFitness = stod(words[2]);
        theGenePools[i]->absoluteFitness = stod(words[3]);

    }
    input.close();

    return theGenePools;
}

GeneAgent **loadPopulationsFromFile(string fnombre, int popSize, int numGeneCopies, bool useModifiedGeneAgent) {
    // allocate memory for theGenePools
    GeneAgent **theGenePools = new GeneAgent*[popSize];
    ifstream input(fnombre);
    for (int i = 0; i < popSize; i++) {
        string line;
        getline(input, line);
        vector<string> words = split(line);

        vector<string> gene_str = split(words[0], '_');
        vector<int> genes;
        for (int i = 1; i < gene_str.size(); i++) {
            genes.push_back(stoi(gene_str[i]));
        }
        if (useModifiedGeneAgent) {
            auto [geneOrgs, geneMods] = splitVector(genes, predef_NUMGENES);
            theGenePools[i] = new GeneAgentHMod(geneOrgs, numGeneCopies, geneMods);
        } else {
            theGenePools[i] = new GeneAgent(genes, numGeneCopies);
            // theGenePools[i] = new GeneAgentHMod(words[0], numGeneCopies);

        }

        theGenePools[i]->count = stoi(words[1]);
        theGenePools[i]->relativeFitness = stod(words[2]);
        theGenePools[i]->absoluteFitness = stod(words[3]);

    }
    input.close();

    return theGenePools;
}

RandomAgent **loadRandomAgents(int popSize) {
    // allocate memory for theGenePools
    RandomAgent **theGenePools = new RandomAgent*[popSize];
    for (int i = 0; i < popSize; i++) {
        theGenePools[i] = new RandomAgent();
    }
    return theGenePools;
}

TFTAgent **loadTftAgents(string fnombre, int popSize) {
    // allocate memory for theGenePools
    TFTAgent **theGenePools = new TFTAgent*[popSize];
    ifstream input(fnombre);
    for (int i = 0; i < popSize; i++) {
        string line;
        getline(input, line);
        vector<string> words = split(line);

        vector<string> gene_str = split(words[0], '_');
        vector<int> genes;
        for (int i = 1; i < gene_str.size(); i++) {
            genes.push_back(stoi(gene_str[i]));
        }
        theGenePools[i] = new TFTAgent(genes);

        theGenePools[i]->count = stoi(words[1]);
        theGenePools[i]->relativeFitness = stod(words[2]);
        theGenePools[i]->absoluteFitness = stod(words[3]);

    }
    input.close();

    return theGenePools;
}

void deleteGenePool(GeneAgent **theGenePools, int popSize) {
    for (int j = 0; j < popSize; j++) {
        delete theGenePools[j];
    }
    delete[] theGenePools;
}

void shuffle(double *initialPopularities, int numPlayers) {
    int n1, n2;
    double tmp;
    for (int i = 0; i < numPlayers; i++) {
        n1 = rand() % numPlayers;
        n2 = rand() % numPlayers;
        tmp = initialPopularities[n1];
        initialPopularities[n1] = initialPopularities[n2];
        initialPopularities[n2] = tmp;
    }
}

double sumVec(double *v, int len) {
    double sm = 0.0;
    for (int i = 0; i < len; i++)
        sm += v[i];

    return sm;
}

void defineInitialPopularities(string initPopType, int numPlayers, double *initialPopularities) {
    double basePop = 100.0;

    // assign the initial popularities
    if (initPopType == "equal") {
        for (int i = 0; i < numPlayers; i++)
            initialPopularities[i] = basePop;
    }
    else if (initPopType == "random") {
        for (int i = 0; i < numPlayers; i++)
            initialPopularities[i] = (rand() % 200) + 1.0;
    }
    else if (initPopType == "step") {
        for (int i = 0; i < numPlayers; i++)
            initialPopularities[i] = i + 1.0;
        shuffle(initialPopularities, numPlayers);
    }
    else if (initPopType == "power") {
        for (int i = 0; i < numPlayers; i++)
            initialPopularities[i] = 1.0 / pow(i+1, 0.7);
        shuffle(initialPopularities, numPlayers);
    }
    else if (initPopType == "highlow") {
        for (int i = 0; i < numPlayers / 2; i++) {
            initialPopularities[i] = 1.0 + rand() % 50 + 150;
        }
        for (int i = numPlayers / 2; i < numPlayers; i++) {
            initialPopularities[i] = 1.0 + rand() % 50;
        }
        shuffle(initialPopularities, numPlayers);
    }
    else {
        printf("don't understand init_pop %s, so just going with equal\n", initPopType.c_str());
        for (int i = 0; i < numPlayers; i++)
            initialPopularities[i] = basePop;
    }

    double totStartPop = basePop * numPlayers;
    double sm = sumVec(initialPopularities, numPlayers);
    for (int i = 0; i < numPlayers; i++) {
        initialPopularities[i] /= sm;
        initialPopularities[i] *= totStartPop;
    }
}

void recordState(int roundNum, JHGEngine *jhg, int humanInd, bool gameOver) {
    string dirSTATE = "/home/watchtower/Datasets/JuniorHighNetwork/BehaviorStudy/State/";
    ofstream output(dirSTATE + "state.tmp");

    if (!gameOver)
        output << "inprogress" << endl;
    else
        output << "fin" << endl;
    output << jhg->numPlayers << endl;
    output << humanInd << endl;
    output << roundNum << endl;

    // print out the popularities
    for (int i = 0; i < jhg->numPlayers; i++) {
        for (int r = 0; r < roundNum+1; r++)
            output << jhg->P[r][i] << " ";
        output << endl;
    }

    // print out the last round's token allocations
    for (int i = 0; i < jhg->numPlayers; i++) {
        for (int j = 0; j < jhg->numPlayers; j++) {
            if (jhg->T[roundNum][i][j] < 0)
                output << (int)(jhg->T[roundNum][i][j] * jhg->numTokens - 0.01) << " ";
            else
                output << (int)(jhg->T[roundNum][i][j] * jhg->numTokens + 0.01) << " ";
        }
        output << endl;
    }

    // print out the current tornadoValues
    // for (int i = 0; i < jhg->numPlayers; i++) {
    //     for (int j = 0; j < jhg->numPlayers; j++)
    //         output << jhg->I[roundNum][j][i] << " ";
    //     output << endl;
    // }

    for (int t = 0; t <= roundNum; t++) {
        for (int i = 0; i < jhg->numPlayers; i++) {
            for (int j = 0; j < jhg->numPlayers; j++)
                output << jhg->I[t][j][i] << " ";
            output << endl;
        }
    }

    // print out the previous tornadoValues
    // for (int i = 0; i < jhg->numPlayers; i++) {
    //     for (int j = 0; j < jhg->numPlayers; j++)
    //         if (roundNum > 0)
    //             output << jhg->I[roundNum-1][j][i] << " ";
    //         else
    //             output << jhg->I[0][j][i] << " ";
    //     output << endl;
    // }

    output.close();
    system(("mv " + dirSTATE + "state.tmp " + dirSTATE + "/state.txt").c_str());
}

PopularityMetrics *playGame(AbstractAgent **agents, int numPlayers, int numRounds, double *initialPopularities,
                            double povertyLine, bool forcedRandom, const string& output_file) {
    double alpha = 0.2;
    double beta = 0.5;
    double coefs[3] = {0.95, 1.3, 1.6};

    // delete all existing contracts
//    system("rm Contracts/*");

//    for (int i = 0; i < 11; ++i) {
//        for (int j = 0; j < 1; ++j) {
//            print(agents[i][j].getString());
//        }
//    }

    // tell agents the game parameters and give each the chance to post a contract
    for (int i = 0; i < numPlayers; i++) {
        agents[i]->setGameParams(coefs, alpha, beta, povertyLine, forcedRandom);
        // printf("%s\n", ((GeneAgent *)agents[i])->getString().c_str());
        agents[i]->postContract(i);
    }

    int humanInd = -1;
    for (int i = 0; i < numPlayers; i++) {
        if (agents[i]->whoami == "human") {
            humanInd = i;
            break;
        }
    }

    int numTokens = numPlayers * 2;

    // allocate some memory for transactions
    double *received = new double[numPlayers];
    int **transactions = new int*[numPlayers];
    for (int i = 0; i < numPlayers; i++)
        transactions[i] = new int[numPlayers];

    PopularityMetrics *pmetrics = new PopularityMetrics[numPlayers];
    for (int i = 0; i < numPlayers; i++) {
        pmetrics[i].avePop = 0.0;
        pmetrics[i].endPop = 0.0;
    }

    // set up the game simulator
    JHGEngine *jhg = new JHGEngine(coefs, alpha, beta, povertyLine, numPlayers, numTokens, numRounds, initialPopularities);
    for (int r = 0; r < numRounds; r++) {
        if (humanInd >= 0)
            recordState(r, jhg, humanInd, false);

        // get each player's token allocations
        for (int i = 0; i < numPlayers; i++) {
            for (int j = 0; j < numPlayers; j++) {
                received[j] = jhg->T[r][j][i];
            }
            // vector<vector<double>>influenceMatrixVector = Algebra::arr2VecOfVec(jhg->I[r], numPlayers, numPlayers);
            // vector<vector<double>>transactionMatrixVector = Algebra::arr2VecOfVec(jhg->T[r], numPlayers, numPlayers);

            // printf("%i is %s\n", i, agents[i]->whoami.c_str());
            agents[i]->playRound(numPlayers, numTokens, i, r, received, jhg->P[r], jhg->I[r], transactions[i]);
        }

        // chrono::steady_clock::time_point antes = chrono::steady_clock::now();
        // chrono::steady_clock::time_point antes = chrono::steady_clock::now();

        // compute changes
        jhg->playRound(transactions);

        // chrono::steady_clock::time_point despues = chrono::steady_clock::now();
        // double jhgUpdateTime = chrono::duration_cast<chrono::microseconds>(despues - antes).count() / 1000000.0;
        // printf("round time: %lf\n", jhgUpdateTime);

        // record popularities
        for (int i = 0; i < numPlayers; i++) {
            pmetrics[i].avePop += jhg->P[jhg->t][i] / numRounds;
            pmetrics[i].endPop = jhg->P[jhg->t][i];
        }
    }

//    jhg->printP();

    if (humanInd >= 0)
        recordState(numRounds, jhg, humanInd, true);

    if (!output_file.empty()){
        // log game
        jhg->save(output_file);
    }

    for (int i = 0; i < numPlayers; i++)
        delete[] transactions[i];
    delete[] transactions;
    delete[] received;
    delete jhg;

    return pmetrics;
}

int selectByFitness(GeneAgent **thePopulation, int popSize, bool _rank) {
    double mag = 0.0;
    for (int i = 0; i < popSize; i++) {
        if (_rank)
            mag += thePopulation[i]->relativeFitness;
        else
            mag += thePopulation[i]->absoluteFitness;
    }

    double num = rand() / ((double)RAND_MAX);
    double sum = 0.0;
    for (int i = 0; i < popSize; i++) {
        if (_rank)
            sum += thePopulation[i]->relativeFitness / mag;
        else
            sum += thePopulation[i]->absoluteFitness / mag;

        if (num <= sum)
            return i;
    }

    printf("didn't select; num = %lf; sum = %lf\n", num, sum);
    exit(1);

    return popSize-1;
}

int mutateIt(int gene) {
    int v = rand() % 100;
    if (v >= 15)
        return gene;
    else if (v < 3)
        return rand() % 101;
    else {
        int g = gene + (rand() % 11) - 5;
        if (g < 0)
            g = 0;
        if (g > 100)
            g = 100;
        return g;
    }
}

GeneAgent **evolvePopulationPairs(GeneAgent **theGenePool_prev, int popSize, int numGeneCopies) {
    cout << "theGenePool_prev[0]->numGenes: " << theGenePool_prev[0]->numGenes << endl;
    GeneAgent **theGenePool = new GeneAgent*[popSize];
    for (int i = 0; i < popSize; i++) {
        // select 2 agents from theGenePools_prev[pool]
        int ind1, ind2;
        if (i < (popSize / 5.0)) {
            ind1 = selectByFitness(theGenePool_prev, popSize, true);
            ind2 = selectByFitness(theGenePool_prev, popSize, false);
        }
        else {
            ind1 = selectByFitness(theGenePool_prev, popSize, false);
            ind2 = selectByFitness(theGenePool_prev, popSize, false);
        }

        string geneStr = "genes_";

        for (int g = 0; g < theGenePool_prev[0]->numGenes; g++) {
            if ((rand() % 2) == 0) {
                geneStr += to_string(mutateIt(theGenePool_prev[ind1]->myGenes[g]));
                if (g < (theGenePool_prev[0]->numGenes-1))
                    geneStr += "_";
            }
            else {
                geneStr += to_string(mutateIt(theGenePool_prev[ind2]->myGenes[g]));
                if (g < (theGenePool_prev[0]->numGenes-1))
                    geneStr += "_";
            }
        }

        theGenePool[i] = new GeneAgent(geneStr, numGeneCopies);
    }


    return theGenePool;
}

int compareEm(GeneAgent *a, GeneAgent *b) {
    if(a->absoluteFitness > b->absoluteFitness)
        return 1;
    else
        return 0;
}

void writeGenerationResults(GeneAgent **theGenePools, int popSize, int gen, int agentsPerGame, int numGeneCopies, const string& varied, string folderNum) {
    for (int i = 0; i < popSize; i++) {
        if (theGenePools[i]->count > 0) {
            theGenePools[i]->relativeFitness /= theGenePools[i]->count;
            theGenePools[i]->absoluteFitness /= theGenePools[i]->count;
        }
        else {
            theGenePools[i]->relativeFitness = 0.0;
            theGenePools[i]->absoluteFitness = 0.0;
        }
    }

    vector<GeneAgent *> v;
    for (int i = 0; i < popSize; i++)
        v.push_back(theGenePools[i]);
    sort(v.begin(), v.end(), compareEm);
    // sort(theGenePools[pool], theGenePools[pool]+(numPops*n*2), compareEm);

    // print to file
    string fnombre = "../Results/theGenerations/" + folderNum + "/" + to_string(numGeneCopies) + "pool_" + varied + "pop/gen_" + to_string(gen) + ".csv";
    ofstream output(fnombre);
    double sm = 0.0;
    for (int i = 0; i < popSize; i++) {
        sm += v[i]->absoluteFitness;
        // output << theGenePools[pool][i]->getString() << "," << theGenePools[pool][i]->count << "," << theGenePools[pool][i]->relativeFitness << "," << theGenePools[pool][i]->absoluteFitness << endl;
        output << v[i]->getString() << "," << v[i]->count << "," << v[i]->relativeFitness << "," << v[i]->absoluteFitness << endl;
    }

    output.close();

    cout << "Average fitness in generation " << gen << ": " << (sm / popSize) << endl;
}


void preprocessGameFile(string &theGameFile, vector<vector<string>> & gameData, vector<double> &gameValueParameters,
                        vector<vector<double>> &gamePopularity, vector<vector<double>> &gameTransactions,
                        vector<vector<double>> &gameInfluence, vector<string> &gamePID, int &numPlayers) {
    ifstream file(theGameFile);

    if (!file.is_open()) {
        cerr << "Error opening file: " << theGameFile << endl;
        return ;
    }

    string line;
    getline(file, line);  // Read the header line
    stringstream headerStream(line);
    string headerCell;
    vector<string> headers;

    while (getline(headerStream, headerCell, ',')) {
        headers.push_back(headerCell);
    }

    // Calculate the number of players
    int playerColumnsCount = 0;
    for (const auto& header : headers) {
        if (header[0] == 'p') {
            playerColumnsCount++;
        }
        if (playerColumnsCount > 0 && header[0] != 'p') {
            break;
        }
    }
    numPlayers = playerColumnsCount;

    // segment headers acording to the number of players
    // number of game headers
    int numGameHeaders = 6;
    int popularityColumnEnd = numGameHeaders + numPlayers;
    int transactionColumnEnd = popularityColumnEnd + numPlayers * numPlayers;
    int influenceColumnEnd = transactionColumnEnd + numPlayers * numPlayers;
    int pidColumnEnd = influenceColumnEnd + numPlayers ;

    gameData.push_back(headers);

    bool first_line = true;
    while (getline(file, line)) {
        vector<string> row;
        stringstream lineStream(line);
        string cell;

        while (getline(lineStream, cell, ',')) {
            row.push_back(cell);
        }

        gameData.push_back(row);

        if(first_line) {
            // Extract columns 0 to 5 for gameValueParameters
            for (size_t i = 0; i < row.size() && i < numGameHeaders; ++i) {
                gameValueParameters.push_back(stod(row[i]));
            }
        }

        // Extract columns gamePopularity
        vector<double> popularityRow;
        for (size_t i = numGameHeaders; i < row.size() && i < popularityColumnEnd; ++i) {
            popularityRow.push_back(stod(row[i]));
        }
        gamePopularity.push_back(popularityRow);

        // Extract columns the game transaction matrix
        vector<double> transactionRow;
        for (size_t i = popularityColumnEnd; i < row.size() && i < transactionColumnEnd; ++i) {
            transactionRow.push_back(stod(row[i]));
        }
        gameTransactions.push_back(transactionRow);

        // Extract columns the game influence matrix
        vector<double> influenceRow;
        for (size_t i = transactionColumnEnd; i < row.size() && i < influenceColumnEnd; ++i) {
            influenceRow.push_back(stod(row[i]));
        }
        gameInfluence.push_back(influenceRow);

        if(first_line) {
            // Extract PIDs from the game
            for (size_t i = influenceColumnEnd; i < row.size() && i < pidColumnEnd; ++i) {
                gamePID.push_back(row[i]);
            }
        }

        first_line = false;
    }

    file.close();
}


void preprocessCABFile(string &theCABFile, vector<vector<string>> &cabData, vector<vector<int>> &cabGenes, vector<string> &geneStrs) {
    ifstream file(theCABFile);

    if (!file.is_open()) {
        cerr << "Error opening file: " << theCABFile << endl;
        return ;
    }

    string line;

    while (getline(file, line)) {
        vector<string> row;
        stringstream lineStream(line);
        string cell;

        while (getline(lineStream, cell, ',')) {
            row.push_back(cell);
        }

        cabData.push_back(row);

        // Get the first string from the vector
        string firstString = row[0];

        geneStrs.push_back(firstString);

        // Create a stringstream from the first string
        stringstream ss(firstString);
        string token;

        // Vector to store the split parts
        vector<int> splitParts;

        // Split the string by '_'
        while (getline(ss, token, '_')) {
            if (token != "gene") {
                splitParts.push_back(stoi(token));
            }
        }
        cabGenes.push_back(splitParts);
    }

}


bool isHuman(const string &playerType){
    if (playerType.size() >= 5 && playerType.substr(0,5) == "Human"){
        return true;
    }
    return false;
}

bool isNovice(const string &playerType){
    if (isHuman(playerType) && playerType.size() >= 11 && playerType.substr(0,11) == "HumanNovice"){
        return true;
    }
    return false;
}

bool isExperienced(const string &playerType){
    return isHuman(playerType) && not isNovice(playerType);
}

bool isAllClasses(double popularity, double meanPopularity){
    return true;
}

bool isRichClass(double popularity, double meanPopularity){
    if (popularity / meanPopularity > 1.25) {
        return true;
    }
    return false;
}

bool isMiddleClass(double popularity, double meanPopularity){
    if (popularity / meanPopularity > .75 && popularity / meanPopularity < 1.25) {
        return true;
    }
    return false;
}

bool isPoorClass(double popularity, double meanPopularity){
    if (popularity / meanPopularity < .75) {
        return true;
    }
    return false;
}

double score_negative_allocations(const vector<vector<int>> &cabAllocations, const  vector<double> &trueAllocations, const string& scoreType,
             const vector<vector<double>> &originalTransactionsT, const vector<vector<double>> &originalInfluenceT,
             const vector<double> &originalPopularities, const int playerIndex, double* num_tokens_categories) {
    // Compute the mean vector of cabAllocations
    vector<double> const meanCabAllocations = Algebra::computeMeanVector(cabAllocations);
    vector<double> normalizedMeanCabAllocations;
    vector<double> normalizedTrueAllocations;
    // Normalize the mean vector and trueAllocations vector
    normalizedMeanCabAllocations = Algebra::normalizeVector(meanCabAllocations, "L1");
    normalizedTrueAllocations = Algebra::normalizeVector(trueAllocations, "L1");

    for (size_t i = 0; i < normalizedTrueAllocations.size(); ++i)
    {
        if (normalizedTrueAllocations[i] > 0)
        {
            normalizedTrueAllocations[i] = 0;
            normalizedMeanCabAllocations[i] = 0;
        }
    }

    // Calculate the percent of tokens kept, given and taken
    double const cabPercentKeeping = normalizedMeanCabAllocations[playerIndex];
    double const truePercentKeeping = normalizedTrueAllocations[playerIndex];
    double const cabPercentGiving = accumulate(normalizedMeanCabAllocations.begin(), normalizedMeanCabAllocations.end(), 0.0,
                                               [](double sum, double val) {return val > 0 ? sum + val : sum;}) - cabPercentKeeping;
    double const truePercentGiving = accumulate(normalizedTrueAllocations.begin(), normalizedTrueAllocations.end(), 0.0,
                                                [](double sum, double val) {return val > 0 ? sum + val : sum;}) - truePercentKeeping;
    double const cabPercentTaking = accumulate(normalizedMeanCabAllocations.begin(), normalizedMeanCabAllocations.end(), 0.0,
                                               [](double sum, double val) {return val < 0 ? sum + val : sum;}) * -1;
    double const truePercentTaking = accumulate(normalizedTrueAllocations.begin(), normalizedTrueAllocations.end(), 0.0,
                                                [](double sum, double val) {return val < 0 ? sum + val : sum;}) * -1;
    double const cabTotalTokens = cabPercentGiving + cabPercentKeeping + cabPercentTaking;
    double const trueTotalTokens = truePercentGiving + truePercentKeeping + truePercentTaking;

    // used for global measurement later
    num_tokens_categories[0] += cabPercentGiving;
    num_tokens_categories[1] += truePercentGiving;
    num_tokens_categories[2] += cabPercentKeeping;
    num_tokens_categories[3] += truePercentKeeping;
    num_tokens_categories[4] += cabPercentTaking;
    num_tokens_categories[5] += truePercentTaking;

    double theScore = 0;

    if(scoreType=="absolute") {
        theScore = Algebra::computeAbsoluteError(normalizedMeanCabAllocations, normalizedTrueAllocations);
//        theScore = Algebra::computeAbsoluteError(cabComparisonVector, trueComparisonVector);
    }
    else if (scoreType=="mean") {
        theScore = Algebra::computeSquaredError(normalizedMeanCabAllocations, normalizedTrueAllocations);
//        theScore = Algebra::computeSquaredError(cabComparisonVector, trueComparisonVector);
    }
    else if (scoreType=="cosine") {
        theScore = 1 - Algebra::computeCosineSimilarity(normalizedMeanCabAllocations, normalizedTrueAllocations);
//        theScore = 1 - Algebra::computeCosineSimilarity(cabComparisonVector, trueComparisonVector);
    }

//    print("Finishing new stuff: ", str(normalizedMeanCabAllocations), " ||| ", str(normalizedTrueAllocations));
//    print();


    if (output2Console){
        // Print the result
        print("Normalized Mean Vector: ", Algebra::vectorToString(normalizedMeanCabAllocations));
        print("Normalized True Vector: ", Algebra::vectorToString(normalizedTrueAllocations));
        print("Score of vectors      : ",  theScore, "\n");
    }

//    print("CAB : ", cabPercentGiving, ", ", cabPercentKeeping, ", ", cabPercentTaking, ", ", cabPopularityAssociativity, ", ", cabFriendsGiving, ", ", cabEnemiesTaking);
//    print("True: ", truePercentGiving, ", ", truePercentKeeping, ", ", truePercentTaking, ", ", truePopularityAssociativity, ", ", trueFriendsGiving, ", ", trueEnemiesTaking);
//    print();

    return theScore;
}


double score(const vector<vector<int>> &cabAllocations, const  vector<double> &trueAllocations, const string& scoreType,
             const vector<vector<double>> &originalTransactionsT, const vector<vector<double>> &originalInfluenceT,
             const vector<double> &originalPopularities, const int playerIndex, double* num_tokens_categories, string loss_model) {
    // Compute the mean vector of cabAllocations
    vector<double> const meanCabAllocations = Algebra::computeMeanVector(cabAllocations);
    vector<double> normalizedMeanCabAllocations;
    vector<double> normalizedTrueAllocations;
    // Normalize the mean vector and trueAllocations vector
    normalizedMeanCabAllocations = Algebra::normalizeVector(meanCabAllocations, "L1");
    normalizedTrueAllocations = Algebra::normalizeVector(trueAllocations, "L1");
    double theScore = 0;

     // Calculate the percent of tokens kept, given and taken
     double const cabPercentKeeping = normalizedMeanCabAllocations[playerIndex];
     double const truePercentKeeping = normalizedTrueAllocations[playerIndex];
     double const cabPercentGiving = accumulate(normalizedMeanCabAllocations.begin(), normalizedMeanCabAllocations.end(), 0.0,
                                          [](double sum, double val) {return val > 0 ? sum + val : sum;}) - cabPercentKeeping;
     double const truePercentGiving = accumulate(normalizedTrueAllocations.begin(), normalizedTrueAllocations.end(), 0.0,
                                           [](double sum, double val) {return val > 0 ? sum + val : sum;}) - truePercentKeeping;
     double const cabPercentTaking = accumulate(normalizedMeanCabAllocations.begin(), normalizedMeanCabAllocations.end(), 0.0,
                                          [](double sum, double val) {return val < 0 ? sum + val : sum;}) * -1;
     double const truePercentTaking = accumulate(normalizedTrueAllocations.begin(), normalizedTrueAllocations.end(), 0.0,
                                           [](double sum, double val) {return val < 0 ? sum + val : sum;}) * -1;

     double const cabTotalTokens = cabPercentGiving + cabPercentKeeping + cabPercentTaking;
     double const trueTotalTokens = truePercentGiving + truePercentKeeping + truePercentTaking;

    // used for global measurement later
    num_tokens_categories[0] += cabPercentGiving;
    num_tokens_categories[1] += truePercentGiving;
    num_tokens_categories[2] += cabPercentKeeping;
    num_tokens_categories[3] += truePercentKeeping;
    num_tokens_categories[4] += cabPercentTaking;
    num_tokens_categories[5] += truePercentTaking;

//     /// Calculate popularity assortivity (Is the player giving to more popular or less popular people)
//     vector<double> popularityVector = originalPopularities;
//     double const playerPopularity = popularityVector[playerIndex];
//     double const maxPopularity = *max_element(popularityVector.begin(), popularityVector.end());
//     transform(popularityVector.begin(), popularityVector.end(), popularityVector.begin(),
//                    [maxPopularity, playerPopularity](double val) {return (val - playerPopularity) / maxPopularity;});
//     double cabPopularityAssociativity = 0;
//     double truePopularityAssociativity = 0;
//
//     for (size_t j = 0; j < popularityVector.size(); ++j) {
//         if(normalizedMeanCabAllocations[j] >= 0) {
//             cabPopularityAssociativity += normalizedMeanCabAllocations[j] * popularityVector[j];
//         }
//         if(normalizedTrueAllocations[j] >= 0) {
//             truePopularityAssociativity += normalizedTrueAllocations[j] * popularityVector[j];
//         }
//     }
//
//    /// Calculate percent of tokens giving to friends and percent of tokens taken from enemies (inverse of friends)
//    double cabFriendsGiving = 0;
//    double trueFriendsGiving = 0;
//    double cabEnemiesTaking = 0;
//    double trueEnemiesTaking = 0;
//    vector<double> friendVector = originalInfluenceT[playerIndex];
//    friendVector[playerIndex] = 0;
//    double row_sum = accumulate(friendVector.begin(), friendVector.end(), 0.0,[](double sum, double val) {return sum + abs(val);});
//
//    if (row_sum != 0) {
//        for (size_t j = 0; j < friendVector.size(); ++j) {
//            friendVector[j] /= row_sum;
//        }
//    }
//
//    vector<double> enemiesVector = friendVector;
//    for (int i = 0; i < enemiesVector.size(); ++i) {
//        enemiesVector[i] = 1 - enemiesVector[i];
//    }
//
//    row_sum = accumulate(friendVector.begin(), friendVector.end(), 0.0,[](double sum, double val) {return sum + abs(val);});
//
//    if (row_sum != 0) {
//        // Divide each element in the row by the row sum
//        for (size_t j = 0; j < enemiesVector.size(); ++j) {
//            enemiesVector[j] /= row_sum;
//        }
//    }
//
//    for (size_t j = 0; j < friendVector.size(); ++j) {
//        if(normalizedTrueAllocations[j] >= 0 || normalizedMeanCabAllocations[j] >= 0 ) {
//            cabFriendsGiving += normalizedMeanCabAllocations[j] * friendVector[j];
//            trueFriendsGiving += normalizedTrueAllocations[j] * friendVector[j];
//        }
//        if(normalizedTrueAllocations[j] < 0 || normalizedMeanCabAllocations[j] < 0) {
//            cabEnemiesTaking += normalizedMeanCabAllocations[j] * enemiesVector[j];
//            trueEnemiesTaking += normalizedTrueAllocations[j] * enemiesVector[j];
//        }
//    }
//
//    if (loss_model == "Micro" || loss_model == "Macro_Micro"){
//        vector<double> cabComparisonVector = {truePercentGiving * 5, truePercentKeeping * 5, truePercentTaking * 5};
//        vector<double> trueComparisonVector = {cabPercentGiving * 5, cabPercentKeeping * 5, cabPercentTaking * 5};
//
//        // Appending vector2 to vector1
//        normalizedMeanCabAllocations.insert(normalizedMeanCabAllocations.end(), cabComparisonVector.begin(), cabComparisonVector.end());
//        normalizedTrueAllocations.insert(normalizedTrueAllocations.end(), trueComparisonVector.begin(), trueComparisonVector.end());
//    }
//    else if (loss_model == "Friendship"){
//        vector<double> cabComparisonVector = {cabFriendsGiving * 5, cabEnemiesTaking * 5};
//        vector<double> trueComparisonVector = {trueFriendsGiving * 5, trueEnemiesTaking * 5};
//
//        // Appending vector2 to vector1
//        normalizedMeanCabAllocations.insert(normalizedMeanCabAllocations.end(), cabComparisonVector.begin(), cabComparisonVector.end());
//        normalizedTrueAllocations.insert(normalizedTrueAllocations.end(), trueComparisonVector.begin(), trueComparisonVector.end());
//    }


    if(scoreType=="absolute") {
        theScore = Algebra::computeAbsoluteError(normalizedMeanCabAllocations, normalizedTrueAllocations);
    }
    else if (scoreType=="mean") {
        theScore = Algebra::computeSquaredError(normalizedMeanCabAllocations, normalizedTrueAllocations);
    }
    else if (scoreType=="cosine") {
        theScore = 1 - Algebra::computeCosineSimilarity(normalizedMeanCabAllocations, normalizedTrueAllocations);
    }
    else if (scoreType=="property"){
        theScore = Algebra::computePropertyScore(normalizedMeanCabAllocations, normalizedTrueAllocations, playerIndex);
    }

    if (output2Console){
        // Print the result
        print("Normalized Mean Vector: ", Algebra::vectorToString(normalizedMeanCabAllocations));
        print("Normalized True Vector: ", Algebra::vectorToString(normalizedTrueAllocations));
        print("Score of vectors      : ",  theScore, "\n");
    }

    return theScore;
}

double scoreGame4PlayerIndex(const vector<int>& genes, vector<double> &gameValueParameters,
                vector<vector<double>> &gamePopularity, vector<vector<double>> &gameTransactions,
                vector<vector<double>> &gameInfluence, int playerIndex, int numPlayers,
                const string &scoreType, bool (*classConditionFunc)(double, double), double* num_tokens_categories,
                string agentType, string loss_model) {
    int _numGeneCopies = 1;


    AbstractAgent* cabAgent;

    if (agentType == "GeneAgentHMod") {
        auto [geneOrgs, geneMods] = splitVector(genes, predef_NUMGENES);
        cabAgent = new GeneAgentHMod(geneOrgs, _numGeneCopies, geneMods);
    } else if (agentType == "GeneAgent") {
        cabAgent = new GeneAgent(genes, _numGeneCopies);
    } else if (agentType == "TFTAgent") {
        cabAgent = new TFTAgent(genes);
    }
//    delete cabAgent;

//    GeneAgent cabAgent = GeneAgent(genes, _numGeneCopies);

    double alpha = 0.2;
    double beta = 0.5;
    double coefs[3] = {0.95, 1.3, 1.6};
    double povertyLine = 0.0;
    bool forcedRandom = false;
    cabAgent->setGameParams(coefs, alpha, beta, povertyLine, forcedRandom);

    int numTokens = numPlayers*2;
    double** gamePopularityP = Algebra::vecOfVec2Arr(gamePopularity);
    double** gameTransactionsP = Algebra::vecOfVec2Arr(gameTransactions);
    double** gameInfluenceP = Algebra::vecOfVec2Arr(gameInfluence);
    vector<double> allocationScore;

    int numRounds = gamePopularity.size() - 1;
    for (int roundNum = 0; roundNum < numRounds; ++roundNum) {
        // transactionMatrix[i][j] = number of tokens player i gave to player j in a particular round
        int* allocationArray = new int[numPlayers]();
//        print(str(gameTransactionsP[roundNum], numPlayers * numPlayers * numPlayers));
        double** transactionMatrix = Algebra::oneDArr2TwoDArray(gameTransactionsP[roundNum], numPlayers, numPlayers);
        double** transactionMatrixTransposed = Algebra::transpose(transactionMatrix, numPlayers, numPlayers);
        double** influenceMatrix = Algebra::oneDArr2TwoDArray(gameInfluenceP[roundNum], numPlayers, numPlayers);
        double** influenceMatrixTransposed = Algebra::transpose(influenceMatrix, numPlayers, numPlayers);

        vector<vector<int>> allocations;
        double* received = new double[numPlayers];

        for (int i = 0; i < numPlayers; ++i) {
            received[i] = transactionMatrixTransposed[playerIndex][i] / numTokens;
        }

        vector<double> tmp = Algebra::arr2Vec(received, numPlayers);

        if (roundNum != 0) {
            cabAgent->updatePastInteractions(numPlayers, reinterpret_cast<int*>(transactionMatrix[playerIndex]));
        }

        // vector<vector<double>>influenceMatrixVector = Algebra::arr2VecOfVec(influenceMatrix, numPlayers, numPlayers);
        // vector<vector<double>>transactionMatrixVector = Algebra::arr2VecOfVec(transactionMatrix, numPlayers, numPlayers);

        cabAgent->playRound(numPlayers, numTokens, playerIndex, roundNum, received, gamePopularityP[roundNum], influenceMatrixTransposed, allocationArray);
        allocations.push_back(Algebra::arr2Vec(allocationArray, numPlayers));
        // cabAgent->updatePastInteractions(numPlayers, allocations);


        double** trueTransactionP = Algebra::oneDArr2TwoDArray(gameTransactionsP[roundNum + 1], numPlayers, numPlayers);
        vector<double> trueTransaction = Algebra::arr2VecOfVec(trueTransactionP, numPlayers, numPlayers)[playerIndex];

        if (output2Console) {
            print("Number of Players : ", numPlayers);
            print("Players Index     : ", playerIndex);
            print("Transaction Matrix: ", "\n", Algebra::arrToString(transactionMatrix, numPlayers, numPlayers));
            print("Transaction Transposed: ", "\n", Algebra::arrToString(transactionMatrixTransposed, numPlayers, numPlayers));
            print("Influence Matrix  : ", "\n", Algebra::arrToString(influenceMatrix, numPlayers, numPlayers));
            print("Influence Transposed: ", "\n", Algebra::arrToString(influenceMatrixTransposed, numPlayers, numPlayers));
            print("Received          : ", Algebra::arrToString(transactionMatrixTransposed[playerIndex], numPlayers));
            print("True Allocation   : ", Algebra::vectorToString(trueTransaction));
            print();
        }

        // Calculate the score based on what the data says and the CAB response
        double meanPop = Algebra::computeMeanOfVector(gamePopularity[roundNum]);
        if (classConditionFunc(gamePopularity[roundNum][playerIndex], meanPop)){
            vector<vector<double>> const transactionMatrixTransposedV = Algebra::arr2VecOfVec(transactionMatrixTransposed, numPlayers, numPlayers);
//            vector<vector<double>> const transactionMatrixTransposedV(numPlayers);
            vector<vector<double>> const influenceMatrixTransposedV = Algebra::arr2VecOfVec(influenceMatrixTransposed, numPlayers, numPlayers);
//            vector<vector<double>> const influenceMatrixTransposedV(numPlayers);

             allocationScore.push_back(score(allocations, trueTransaction, scoreType, transactionMatrixTransposedV, influenceMatrixTransposedV,
                                             gamePopularity[roundNum], playerIndex, num_tokens_categories, loss_model));
//            allocationScore.push_back(score_negative_allocations(allocations, trueTransaction, scoreType, transactionMatrixTransposedV, influenceMatrixTransposedV,
//                                            gamePopularity[roundNum], playerIndex, num_tokens_categories));

        }

        // free memory so there are no leaks
        delete[] received;
        delete[] allocationArray;
        Algebra::free2DArray(transactionMatrix, numPlayers);
        Algebra::free2DArray(transactionMatrixTransposed, numPlayers);
        Algebra::free2DArray(influenceMatrix, numPlayers);
        Algebra::free2DArray(influenceMatrixTransposed, numPlayers);
        Algebra::free2DArray(trueTransactionP, numPlayers);
    }

    Algebra::free2DArray(gamePopularityP,gamePopularity.size());
    Algebra::free2DArray(gameTransactionsP, gameTransactions.size());
    Algebra::free2DArray(gameInfluenceP, gameInfluence.size());

    delete cabAgent;
    if (!allocationScore.empty()){
        return Algebra::computeMeanOfVector(allocationScore);
    }
    return 0;
}

double scoreGame(const vector<int>& all_gene, vector<double> &gameValueParameters,
                vector<vector<double>> &gamePopularity, vector<vector<double>> &gameTransactions,
                vector<vector<double>> &gameInfluence, vector<string> &gamePID,
                int numPlayers, int numAllocations, const string &scoreType, bool (*meetsConditions)(const string&),
                bool (*classConditionFunc)(double, double), double* num_tokens_categories, string agentType, string loss_model, int num_swarm_copies=1) {
    // Implement the game logic here
    if (output2Console){
        print("Running game with gene set: ", Algebra::vectorToString(all_gene));
    }

    double sum = 0;
    int num_genes = all_gene.size() / num_swarm_copies;
    for (int j =0; j < numAllocations; ++j) {
        for (int i = 0; i < gamePID.size(); ++i) {
            if (isHuman(gamePID[i])) {
                double weight = 0.2;
                if (meetsConditions(gamePID[i])) {
                    weight = 1.0;
                }
                vector<double> possible_scores;
                for (int k = 0; k < num_swarm_copies; k++) {
                    vector<int> gene;
                    for (int l = 0; l < num_genes; ++l) {
                        gene.push_back(all_gene[k * num_genes + l]);
                    }

                    possible_scores.push_back(weight * scoreGame4PlayerIndex(gene, gameValueParameters, gamePopularity,
                                                                             gameTransactions, gameInfluence, i,
                                                                             numPlayers, scoreType, classConditionFunc,
                                                                             num_tokens_categories, agentType,
                                                                             loss_model));

                }
                sum += *min_element(possible_scores.begin(), possible_scores.end());
            }
        }
    }

    return sum;
}

vector<vector<int>> getPossibleActions4PlayerIndex(const vector<int>& genes, vector<double> &gameValueParameters,
                             vector<vector<double>> &gamePopularity, vector<vector<double>> &gameTransactions,
                             vector<vector<double>> &gameInfluence, int playerIndex, int numPlayers, bool useModifiedGeneAgent) {
    int _numGeneCopies = 1;

    GeneAgent cabAgent;
    if(useModifiedGeneAgent) {
        auto [geneOrgs, geneMods] = splitVector(genes, predef_NUMGENES);
        cabAgent = GeneAgentHMod(geneOrgs, _numGeneCopies, geneMods);
    }
    else {
        cabAgent = GeneAgent(genes, _numGeneCopies);
    }


    double alpha = 0.2;
    double beta = 0.5;
    double coefs[3] = {0.95, 1.3, 1.6};
    double povertyLine = 0.0;
    bool forcedRandom = false;
    cabAgent.setGameParams(coefs, alpha, beta, povertyLine, forcedRandom);

    double** gamePopularityP = Algebra::vecOfVec2Arr(gamePopularity);
    double** gameTransactionsP = Algebra::vecOfVec2Arr(gameTransactions);
    double** gameInfluenceP = Algebra::vecOfVec2Arr(gameInfluence);
    vector<double> allocationScore;
    vector<vector<int>> allAllocations;

    int numRounds = gamePopularity.size() - 1;
    for (int currentRound = 0; currentRound < numRounds; ++currentRound) {
        // transactionMatrix[i][j] = number of tokens player i gave to player j in a particular round
        int* allocationArray = new int[numPlayers]();
        // print(str(gameTransactionsP[currentRound], numPlayers * numPlayers * numPlayers));
        double** transactionMatrix = Algebra::oneDArr2TwoDArray(gameTransactionsP[currentRound], numPlayers, numPlayers);
        double** transactionMatrixTransposed = Algebra::transpose(transactionMatrix, numPlayers, numPlayers);
        double** influenceMatrix = Algebra::oneDArr2TwoDArray(gameInfluenceP[currentRound], numPlayers, numPlayers);
        double** influenceMatrixTransposed = Algebra::transpose(influenceMatrix, numPlayers, numPlayers);

        vector<vector<int>> allocations;
        if (currentRound != 0) {
            cabAgent.updatePastInteractions(numPlayers, reinterpret_cast<int*>(transactionMatrix[playerIndex]));
        }

        cabAgent.playRound(numPlayers, numPlayers*2, playerIndex, currentRound, transactionMatrixTransposed[playerIndex], gamePopularityP[currentRound], influenceMatrix, allocationArray);
        allocations.push_back(Algebra::arr2Vec(allocationArray, numPlayers));


        double** trueTransactionP = Algebra::oneDArr2TwoDArray(gameTransactionsP[currentRound + 1], numPlayers, numPlayers);
        vector<double> trueTransaction = Algebra::arr2VecOfVec(trueTransactionP, numPlayers, numPlayers)[playerIndex];

        allAllocations.push_back(allocations[0]);

        // free memory so there are no leaks
        delete[] allocationArray;
        Algebra::free2DArray(transactionMatrix, numPlayers);
        Algebra::free2DArray(transactionMatrixTransposed, numPlayers);
        Algebra::free2DArray(influenceMatrix, numPlayers);
        Algebra::free2DArray(influenceMatrixTransposed, numPlayers);
        Algebra::free2DArray(trueTransactionP, numPlayers);
    }

    Algebra::free2DArray(gamePopularityP,gamePopularity.size());
    Algebra::free2DArray(gameTransactionsP, gameTransactions.size());
    Algebra::free2DArray(gameInfluenceP, gameInfluence.size());

    return allAllocations;
}


vector<vector<vector<int>>> getPossibleActions(const vector<int>& gene, vector<double> &gameValueParameters,
                 vector<vector<double>> &gamePopularity, vector<vector<double>> &gameTransactions,
                 vector<vector<double>> &gameInfluence, vector<string> &gamePID,
                 int numPlayers, int numAllocations, bool useModifiedGeneAgent) {
    // Implement the game logic here
    if (output2Console){
        print("Running game with gene set: ", Algebra::vectorToString(gene));
    }

    vector<vector<int>> allocations;
    vector<vector<vector<int>>> allAllocations;

    double sum = 0;
    for (int j =0; j < numAllocations; ++j) {
        for (int i = 0; i < gamePID.size(); ++i) {
            allocations = getPossibleActions4PlayerIndex(gene, gameValueParameters, gamePopularity, gameTransactions,
                                             gameInfluence, i, numPlayers, useModifiedGeneAgent);
            allAllocations.push_back(allocations);
        }
    }

    return allAllocations;
}



bool (*setConditionFunc(const string &humanCondition))(const string&){
    if (humanCondition == "human"){
        print("\thumanCondition      : human");
        return isHuman;
    }
    else if (humanCondition == "novice") {
        print("\thumanCondition      : novice");
        return isNovice;
    }
    else if (humanCondition == "experienced"){
        print("\thumanCondition      : experienced");
        return isExperienced;
    }
    else {
        throw invalid_argument("the humanCondition was entered incorrectly!");
    }
}

bool (*setClassConditionFunc(const string &humanClassCondition))(double, double){
    if (humanClassCondition == "all"){
        print("\thumanClassCondition : all");
        return isAllClasses;
    }
    else if (humanClassCondition == "rich") {
        print("\thumanClassCondition : rich");
        return isRichClass;
    }
    else if (humanClassCondition == "middle") {
        print("\thumanClassCondition : middle");
        return isMiddleClass;
    }
    else if (humanClassCondition == "poor") {
        print("\thumanClassCondition : poor");
        return isPoorClass;
    }
    else {
        throw invalid_argument("the humanCondition was entered incorrectly!");
    }
}


void loadParticlesFromCSV(const string& filename,
                          vector<vector<int>>& particles,
                          vector<vector<int>>& velocities,
                          vector<vector<int>>& pBest,
                          vector<double>& pBest_scores,
                          vector<vector<int>>& gBests,
                          vector<double>& gBest_scores,
                          int& num_particles,
                          int& num_dimensions) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    string line;
    num_particles = 0;
    num_dimensions = 0;

    while (getline(file, line)) {
        istringstream ss(line);
        vector<int> particle;
        int value;
        char comma;

        // Read values until the last one (which is irrelevant)
        while (ss >> value) {
            particle.push_back(value);
            ss >> comma;  // ignore the comma
        }
        particle.pop_back();  // remove the last irrelevant value
        particle.pop_back();  // remove the last irrelevant value

        if (num_dimensions == 0) {
            num_dimensions = particle.size();
        }

        particles.push_back(particle);
        num_particles++;
    }

    // Initialize other vectors based on the number of particles and dimensions
    velocities.resize(num_particles, vector<int>(num_dimensions));
    pBest = particles;  // Initialize pBest with the particles
    pBest_scores.resize(num_particles, numeric_limits<double>::max());
    int num_of_swarms = 1;  // Adjust this value as needed
    gBests.resize(num_of_swarms, vector<int>(num_dimensions, 0));
    gBest_scores.resize(num_of_swarms, numeric_limits<double>::max());

    file.close();
}

vector<vector<int>> parseGeneFile(const string& filename) {
    vector<vector<int>> geneData;
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Failed to open the file!" << filename << endl;
        return geneData;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string firstCell;
        if (getline(ss, firstCell, ',')) {
            // Only process lines that start with "gene"
            if (firstCell.rfind("gene", 0) == 0) {
                vector<int> geneNumbers;
                stringstream geneStream(firstCell.substr(5)); // Skip "gene_"
                string number;

                // Extract the numbers delimited by underscores
                while (getline(geneStream, number, '_')) {
                    geneNumbers.push_back(stoi(number));
                }

                // Add the vector of numbers to the main data vector
                geneData.push_back(geneNumbers);
            }
        }
    }

    file.close();
    return geneData;
}

// To compile: g++ main.cpp -o jhgsim
//
// To evolve genes, run the program as follows:
//      ./jhgsim evolve [generationFolder] [popSize] [numGeneCopies] [startGen] [numGens] [gamesPerGen] [agentsPerGame] [roundsPerGame] [povertyLine] [config] [equal/varied]
//
// To run a game using gene-strings from a particular generation:
//      ./jhgsim play [generationFolder] [popSize] [numGeneCopies] [gen] [numAgents] [numRounds] [best_agents/rnd_agents] [initPopType] [povertyLine] [deterministic/nondeterministic] [config] [equal/varied] [folderNum]
//
// To run a game using gene-strings from a particular generation:
//      ./jhgsim compare [theCABFile] [theGameFile]
//
// Example: ./jhgsim play ../Results/theGenerations 70 3 49 4 30 best_agents equal 30 addHuman basicConfig varied 0 0
int main(int argc, char *argv[]) {
//    // Test the print function
//    print("Testing print function with a single string: ", "Hello, World!");
//    print("Testing print function with multiple arguments: ", "The number is ", 42, ", and the character is ", 'A');
//
////    print(str(11));
//
//    // Test int Arrays
//    int intArray[] = {1, 2, 3, 4, 5};
//    string intArrayStr = str(intArray, 5);
//    print("Array of ints: ", intArrayStr);
//
//    // Test double Arrays
//    double doubleArray[] = {1.1, 2.2, 3.3};
//    string doubleArrayStr = str(doubleArray, 3);
//    print("Array of doubles: ", doubleArrayStr);
//
//    // Test char Arrays
//    char charArray[] = {'a', 'b', 'c'};
//    string charArrayStr = str(charArray, 3);
//    print("Array of chars: ", charArrayStr);
//
//    // Test the vector to string conversion function
//    vector<int> intVec = {1, 2, 3, 4, 5};
//    print("Testing vector to string conversion with integers: ", str(intVec));
//
//    vector<double> doubleVec = {1.234, 5.678, 9.1011, 12.1314};
//    print("Testing vector to string conversion with doubles: ", str(doubleVec, 2));
//
//    // Test the set to string conversion function
//    set<int> intSet = {10, 20, 30, 40, 50};
//    print("Testing set to string conversion: ", str(intSet));
//
//    // Test the map to string conversion function
//    map<string, int> stringIntMap = {{"apple", 1}, {"banana", 2}, {"cherry", 3}};
//    print("Testing map to string conversion: ", str(stringIntMap));
//
//
//    return 0;

    bool useModifiedGeneAgent = false;
    // string agentType = 'GeneAgent';
    // string agentType = 'GeneAgentHMod';
//    string agentType = "TFTAgent";
//    if (agentType == "GeneAgentHMod") {
//        useModifiedGeneAgent = true;
//    }

    if (argc < 2) {
        printf("don't know what mode to run the program in\n");
        return -1;
    }
    if (!strcmp(argv[1], "play")) {
        if (argc != 20) {
            printf("wrong number of parameters to specify how to *play*: %i\n", argc);
            return -1;
        }

        srand(time(nullptr) + 10000 * atoi(argv[19]));
        print("randSeed: ", time(nullptr) + 10000 * atoi(argv[19]));


        // srand(1);

        //        srand(100 * atoi(argv[15]));

        // store the command-line parameters in the appropriate format
//        string theFolder = argv[2];
//        int popSize = atoi(argv[3]);
//        int numGeneCopies = atoi(argv[4]);
//        int theGen = atoi(argv[5]);
        string eCabFile = argv[2];
        string hCabFile = argv[3];
        string pTftFile = argv[4];
        print("eCabFile: ", eCabFile);
        print("hCabFile: ", hCabFile);
        print("pTftFile: ", pTftFile);

        int numECab = atoi(argv[5]);
        int numHCab = atoi(argv[6]);
        int numRand = atoi(argv[7]);
        int numPTft = atoi(argv[8]);
        print("numECab: ", numECab);
        print("numHCab: ", numHCab);
        print("numRand: ", numRand);
        print("numPTft: ", numPTft);

        int eCABPoolSize = atoi(argv[16]);
        print("eCABPoolSize: ", eCABPoolSize);
        int hCABPoolSize = atoi(argv[16]);
        print("hCABPoolSize: ", hCABPoolSize);
        int pTFTPoolSize = atoi(argv[16]);
        print("pTFTPoolSize: ", pTFTPoolSize);
        int randPoolSize = atoi(argv[16]);
        print("randPoolSize: ", randPoolSize);

        string theFolder = "";
        int popSize = numECab + numHCab + numRand + numPTft;
        int numGeneCopies = atoi(argv[9]);
        print("numGeneCopies: ", numGeneCopies);


        int numAgents = numECab + numHCab + numRand + numPTft;
        int numRounds = atoi(argv[10]);
        print("numRounds: ", numRounds);

        string agentSelections = argv[11];
        print("agentSelections: ", agentSelections);

//        string varied = argv[13];
//        string folderNum = argv[14];
        string output_folder = argv[17];
        print("output_folder: ", output_folder);


        string output_file =
                output_folder + "log_ecab-" + to_string(numECab) + "_hcab-" + to_string(numHCab) + "_game-" + argv[19] +
                ".csv";
        print("game_num: ", argv[19]);

        if ((agentSelections != "best_agents") && (agentSelections != "rnd_agents")) {
            printf("don't understand agentSelection: %s; Must be best_agents or rnd_agents\n", agentSelections.c_str());
            return -1;
        }
        string initPopType = argv[12];
        if ((initPopType != "equal") && (initPopType != "random") && (initPopType != "step") &&
            (initPopType != "power") && (initPopType != "highlow")) {
            printf("don't understand initPopType: %s\n", initPopType.c_str());
            return -1;
        }
        print("initPopType: ", initPopType);

        double povertyLine = (double) (atoi(argv[13]));
        print("povertyLine: ", povertyLine);

        bool forcedRandom = false;
        if (!strcmp(argv[14], "deterministic"))
            forcedRandom = true;
        print(forcedRandom ? "deterministic" : "nondeterministic");

        // load extra players specified in the configuration file
        vector<AbstractAgent *> configuredPlayers;

        string fnombre = "ScenarioIndicator/";
        fnombre += argv[15];
        fnombre += ".txt";
        print("configFile: ", fnombre);
        ifstream in(fnombre);
        if (!in) {
            cout << "config file not found: " << fnombre << endl;
        } else {
            string line;
            while (!in.eof()) {
                getline(in, line);
                if (line == "Human")
                    configuredPlayers.push_back(new HumanAgent());
                else if (line == "Assassin")
                    configuredPlayers.push_back(new assassinAgent());
                else if ((line.length() >= 4) && (line.substr(0, 4) == "CoOp"))
                    configuredPlayers.push_back(new CoOpAgent(line));
            }
            in.close();
        }

        string agentType = argv[18];
        print("agentType: ", agentType);
        if (agentType == "GeneAgentHMod") {
            useModifiedGeneAgent = true;
        }
        else if(agentType == "GeneAgent") {
            useModifiedGeneAgent = false;
        }
        else {
            throw invalid_argument( agentType.append(" is not a valid agentType!"));
        }

//        cout << "num configured players: " << configuredPlayers.size() << endl;

        // load in the population(s) of generation "theGen"
        GeneAgent **theECabGenePools ;
        GeneAgent **theHCabGenePools;
        RandomAgent **theRandomAgentPools;
        TFTAgent **theTftAgentPools;

        if (numECab > 0) {
            theECabGenePools = loadPopulationsFromFile(eCabFile, eCABPoolSize, numGeneCopies, useModifiedGeneAgent);
        }
        if (numHCab > 0) {
            theHCabGenePools = loadPopulationsFromFile(hCabFile, hCABPoolSize, numGeneCopies, useModifiedGeneAgent);
        }
        if (numRand > 0) {
            theRandomAgentPools = loadRandomAgents(numRand);
        }
        if (numPTft > 0) {
            theTftAgentPools = loadTftAgents(pTftFile, pTFTPoolSize);
        }

        int numPlayers = numECab + numHCab + numRand + numPTft + configuredPlayers.size();
        int *plyrIdxs = new int[numPlayers];

        // determine which GeneAgents will participate
        if (agentSelections == "best_agents") {
            for (int i = 0; i < numECab; i++) {
                plyrIdxs[i] = i;
            }
            for (int i = numECab; i < numECab + numHCab; i++) {
                plyrIdxs[i] = i - numECab;
            }
            for (int i = numECab + numHCab; i < numECab + numHCab + numPTft; i++) {
                plyrIdxs[i] = i - numECab - numHCab;
            }
        } else {
            for (int i = 0; i < numECab; i++) {
                plyrIdxs[i] = rand() % eCABPoolSize;
            }
            for (int i = numECab; i < numECab + numHCab; i++) {
                plyrIdxs[i] = rand() % hCABPoolSize;
            }
            for (int i = numECab + numHCab; i < numECab + numHCab + numPTft; i++) {
                plyrIdxs[i] = rand() % pTFTPoolSize;
            }
        }

        // add in the configured players
        for (int i = 0; i < configuredPlayers.size(); i++) {
            plyrIdxs[numAgents + i] = i;
        }

        // // set up population pool delimiters
        // int poolDelims[3];
        // if (numAgentPops == 1)
        //     poolDelims[0] = poolDelims[1] = poolDelims[2]= 99999;
        // else if (numAgentPops == 2) {
        //     poolDelims[0] = 100;
        //     poolDelims[1] = poolDelims[2]= 99999;
        // }
        // else if (numAgentPops == 3) {
        //     poolDelims[0] = 75;
        //     poolDelims[1] = 125;
        //     poolDelims[2]= 99999;
        // }

        // now get the initial popularities
        double *initialPopularities = new double[numPlayers];
        defineInitialPopularities(initPopType, numPlayers, initialPopularities);

        // assign each player to a pool based on their assigned initial popularity
        // int *poolAssignments = new int[numPlayers];
        // for (int i = 0; i < numPlayers; i++) {
        //     poolAssignments[i] = -1;
        //     for (int j = 0; j < 3; j++) {
        //         if (initialPopularities[i] < poolDelims[j]) {
        //             poolAssignments[i] = j;
        //             break;
        //         }
        //     }
        // }

        // printf("The starting popularities are:\n");
        // for (int i = 0; i < numPlayers; i++) {
        //     printf("\t%i: %.1lf (%i)\n", plyrIdxs[i], initialPopularities[i], poolAssignments[i]);
        // }
        // printf("\n");

//        print(str(plyrIdxs, numPlayers));
//        for (int i = 0; i < 10; ++i) {
//            for (int j = 0; j < 1; ++j) {
//                print(theECabGenePools[i][j].getString());
//            }
//        }
        int k = 0;
        AbstractAgent **agents = new AbstractAgent *[numPlayers];
        for (int i = 0; i < numPlayers; i++) {
            if (i >= numECab + numHCab + numRand + numPTft) {
                agents[i] = configuredPlayers[plyrIdxs[i - numECab - numHCab - numRand - numPTft]];
                k++;
            } else if (i >= numECab + numHCab + numRand) {
                agents[i] = theTftAgentPools[plyrIdxs[i - numECab - numHCab - numRand]];
                k++;
            } else if (i >= numECab + numHCab) {
                agents[i] = theRandomAgentPools[plyrIdxs[i - numECab - numHCab]];
                k++;
            } else if (i >= numECab) {
                agents[i] = theHCabGenePools[plyrIdxs[i - numECab]];
                k++;
            } else {
                agents[i] = theECabGenePools[plyrIdxs[i]];
                k++;
            }
            // agents[i] = theGenePools[poolAssignments[i]][plyrIdxs[i]];
        }

        PopularityMetrics *pmetrics = playGame(agents, numPlayers, numRounds, initialPopularities, povertyLine,
                                               forcedRandom, output_file);

        delete[] pmetrics;
        delete[] plyrIdxs;
        delete[] initialPopularities;
        // delete[] poolAssignments;
        deleteGenePool(theECabGenePools, numECab);
        deleteGenePool(theHCabGenePools, numHCab);

        // delete extra players specified by the configuration file
        for (int i = 0; i < configuredPlayers.size(); i++) {
            // cout << configuredPlayers[i]->whoami << endl;
            if (configuredPlayers[i]->whoami == "human")
                delete ((HumanAgent *) configuredPlayers[i]);
            else if (configuredPlayers[i]->whoami == "assassin")
                delete ((assassinAgent *) configuredPlayers[i]);
            else if ((configuredPlayers[i]->whoami.length() >= 4) &&
                     (configuredPlayers[i]->whoami.substr(0, 4) == "CoOp"))
                delete ((CoOpAgent *) configuredPlayers[i]);
            else {
                cout << "don't know how to delete " << configuredPlayers[i]->whoami << " player " << i << endl;
            }
        }
    }
    else if (!strcmp(argv[1], "score")) { // used to score cab agents on one game
        if (argc != 11 && argc != 11) {
            printf("wrong number of parameters to specify how to *play*: %i\n", argc);
            return -1;
        }

        // srand(time(nullptr) + 100 * atoi(argv[15]));

        // store the command-line parameters in the appropriate format
//        string theCABFile = argv[2];
        print("Score Parameters:");
        string theGamesDir = argv[2];
        print("\ttheGamesDir         : ", theGamesDir);
        string theInputDir = argv[3];
        print("\ttheInputDir      : ", theInputDir);
        string fileName = argv[4];
        print("\tfileName      : ", fileName);
        int numAllocations = stoi(argv[5]); // 10
        print("\tnumAllocations      : ", numAllocations);
        string scoreType = argv[6]; // absolute, mean, cosine
        print("\tscoreType           : ", scoreType);

        string humanCondition = argv[7]; // human, novice, experienced
        string humanClassCondition = argv[8]; // all, rich, middle, poor

        // set up conditions of the experiment
        bool (*conditionFunc)(const string &);
        conditionFunc = setConditionFunc(humanCondition);
        bool (*classConditionFunc)(double, double);
        classConditionFunc = setClassConditionFunc(humanClassCondition);


        // PSO parameters
//        int num_particles = 128;
//        const int num_particles = 1;

        int num_dimensions;
        string agentType = argv[9];
        if (agentType == "GeneAgentHMod") {
            num_dimensions = predef_NUMGENES + predef_NUMGENEHMODS; // Length of the input vector
        } else if (agentType == "GeneAgent") {
            num_dimensions = predef_NUMGENES; // Length of the input vector
        } else if (agentType == "TFTAgent") {
            num_dimensions = predef_NUMGENES_TFT; // Length of the input vector
        }
        else {
            throw invalid_argument( agentType.append(" is not a valid agentType!"));
        }

        string loss_model = argv[10];

//        const int max_iterations = 45;
//        const int num_of_swarms = 5;
//        const double inertia_weight = 0.7;
//        const double cognitive_weight = 1.5;
//        const double social_weight = 1.5;
        const int min_bound = 0;
        const int max_bound = 100;

        ifstream inputFile("input.txt");

        vector<vector<int>> parameterizations = parseGeneFile(theInputDir + fileName);

        vector<string> files = FileReader::listFilesInDirectory(theGamesDir);

        // variables to get out of preprocessing
        vector<vector<vector<string>>> gamesData(files.size());
        vector<vector<double>> gamesValueParameters(files.size());
        vector<vector<vector<double>>> gamesPopularity(files.size());
        vector<vector<vector<double>>> gamesTransactions(files.size());
        vector<vector<vector<double>>> gamesInfluence(files.size());
        vector<vector<string>> gamesPID(files.size());

        vector<vector<string>> cabData;
        vector<vector<int>> cabGenes;
        vector<int> gamesNumPlayers(files.size(), 0);

        print("\nPreprocessing Data:");
        for (int i = 0; i < files.size(); ++i) {
            print("\t file: ", files[i]);
            // preprocess data from files
            preprocessGameFile(files[i], gamesData[i], gamesValueParameters[i], gamesPopularity[i],
                               gamesTransactions[i], gamesInfluence[i], gamesPID[i], gamesNumPlayers[i]);
        }

        cout << "\nParameterization Testing" << endl;
        ofstream outFile(theInputDir + "Scored_" + fileName);

        for (int i = 0; i < parameterizations.size(); ++i) {
            double score = 0;
            double* num_tokens_categories = new double[6];
            for (int j = 0; j < 6; ++j) {
                num_tokens_categories[j] = 0;
            }
            for (int j = 0; j < files.size(); ++j) {
                score += scoreGame(parameterizations[i], gamesValueParameters[j], gamesPopularity[j],gamesTransactions[j],
                                   gamesInfluence[j], gamesPID[j], gamesNumPlayers[j], numAllocations, scoreType,
                                   conditionFunc, classConditionFunc, num_tokens_categories, agentType, loss_model);

            }
//            double loss = .033333333 * (abs(num_tokens_categories[0] - num_tokens_categories[1])
//                                        + abs(num_tokens_categories[2] - num_tokens_categories[3])
//                                        + abs(num_tokens_categories[4] - num_tokens_categories[5]));
//
//            cout << "loss : " << loss << " | " << abs(num_tokens_categories[0] - num_tokens_categories[1])
//                 << " | " << abs(num_tokens_categories[2] - num_tokens_categories[3])
//                 << " | " << abs(num_tokens_categories[4] - num_tokens_categories[5]) << endl;
//
//            score += loss;

            delete[] num_tokens_categories;
            print(str(parameterizations[i]), " Score: ", score);
            outFile << "gene";
            for (int num: parameterizations[i]) {
                outFile << "_" << num;
            }
            outFile << "," << score << "," << score << "," << score << '\n';

        }
        outFile.close();
        cout << "Scores have been written to file successfully." << endl;

    }
    else if (!strcmp(argv[1], "swarm")) {
        if (argc != 10 && argc != 11) {
            printf("wrong number of parameters to specify how to *play*: %i\n", argc);
            return -1;
        }

        // srand(time(nullptr) + 100 * atoi(argv[15]));

        // store the command-line parameters in the appropriate format
//        string theCABFile = argv[2];
        print("Swarm Optimization Parameters:");
        string theGamesDir = argv[2];
        print("\ttheGamesDir         : ", theGamesDir);
        string theOutputDir = argv[3];
        int numAllocations = stoi(argv[4]); // 10
        print("\tnumAllocations      : ", numAllocations);
        string scoreType = argv[5]; // absolute, mean, cosine
        print("\tscoreType           : ", scoreType);

        string humanCondition = argv[6]; // human, novice, experienced
        string humanClassCondition = argv[7]; // all, rich, middle, poor

        // set up conditions of the experiment
        bool (*conditionFunc)(const string&);
        conditionFunc = setConditionFunc(humanCondition);
        bool (*classConditionFunc)(double, double);
        classConditionFunc = setClassConditionFunc(humanClassCondition);

        int num_dimensions;
        string agentType = argv[8];
        if (agentType == "GeneAgentHMod") {
            num_dimensions = predef_NUMGENES + predef_NUMGENEHMODS; // Length of the input vector
        } else if (agentType == "GeneAgent") {
            num_dimensions = predef_NUMGENES; // Length of the input vector
        } else if (agentType == "TFTAgent") {
            num_dimensions = predef_NUMGENES_TFT; // Length of the input vector
        }
        else {
            throw invalid_argument( agentType.append(" is not a valid agentType!"));
        }

        string loss_model = argv[9];
        const int num_swarm_copies = stoi(argv[10]);
        num_dimensions *= num_swarm_copies;


        // PSO parameters
        int num_particles = 128;
        // const int num_particles = 1;
        const int max_iterations = 40;
        // const int max_iterations = 1;

        const int num_of_swarms = 2;
        double inertia_weight = 0.7;
        const double cognitive_weight = 1.5;
        const double social_weight = 1.5;
        const int min_bound = 0;
        const int max_bound = 100;

        // Initialize particles
        vector<vector<int>> particles(num_particles, vector<int>(num_dimensions));
        vector<vector<int>> velocities(num_particles, vector<int>(num_dimensions));
        vector<vector<int>> pBest = particles;
        vector<double> pBest_scores(num_particles, numeric_limits<double>::max());
//        vector<int> gBest(num_dimensions);
        vector<vector<int>> gBests(num_of_swarms, vector<int>(num_dimensions, 0));
//        double gBest_score = numeric_limits<double>::max();
        vector<double> gBest_scores(num_of_swarms, numeric_limits<double>::max());

        vector<string> files = FileReader::listFilesInDirectory(theGamesDir);

        // variables to get out of preprocessing
        vector<vector<vector<string>>> gamesData(files.size());
        vector<vector<double>> gamesValueParameters(files.size());
        vector<vector<vector<double>>> gamesPopularity(files.size());
        vector<vector<vector<double>>> gamesTransactions(files.size());
        vector<vector<vector<double>>> gamesInfluence(files.size());
        vector<vector<string>> gamesPID(files.size());

        vector<vector<string>> cabData;
        vector<vector<int>> cabGenes;
        vector<int> gamesNumPlayers(files.size(), 0);

        print("\nPreprocessing Data:");
        for (int i=0; i < files.size(); ++i) {
            print("\t file: ", files[i]);


            // preprocess data from files
            preprocessGameFile(files[i], gamesData[i], gamesValueParameters[i], gamesPopularity[i],
                               gamesTransactions[i], gamesInfluence[i], gamesPID[i], gamesNumPlayers[i]);
        }

        for (int k=0; k < num_of_swarms; ++k) {

            cout << "\nParticle Initialization: " << endl;

            vector<future<void>> init_futures(num_particles);

            for (int i = 0; i < num_particles; ++i) {
                init_futures[i] = async(launch::async, [&](int particle_index) {
                    double* num_tokens_categories = new double[6];
                    for (int j = 0; j < 6; ++j) {
                        num_tokens_categories[j] = 0;
                    }
                    for (int j = 0; j < num_dimensions; ++j) {
                        particles[particle_index][j] = min_bound + rand() % (max_bound - min_bound + 1);
                        velocities[particle_index][j] = min_bound + rand() % (max_bound - min_bound + 1);
                    }
                    double score = 0;
                    for (int j = 0; j < files.size(); ++j) {
                        score += scoreGame(particles[particle_index], gamesValueParameters[j], gamesPopularity[j], gamesTransactions[j],
                                           gamesInfluence[j], gamesPID[j], gamesNumPlayers[j], numAllocations, scoreType,
                                           conditionFunc, classConditionFunc, num_tokens_categories, agentType, loss_model, num_swarm_copies);
                    }
                    if(loss_model == "Macro" || loss_model == "Macro_Micro") {
                        double loss = .33333333 * (abs(num_tokens_categories[0] - num_tokens_categories[1])
                                                   + abs(num_tokens_categories[2] - num_tokens_categories[3])
                                                   + abs(num_tokens_categories[4] - num_tokens_categories[5]));

//                    cout << "loss : " << loss << " | " << num_tokens_categories[0] << " | " << num_tokens_categories[1]
//                         << " | " << num_tokens_categories[2] << " | " << num_tokens_categories[3]
//                         << " | " << num_tokens_categories[4] << " | " << num_tokens_categories[5] << endl;

                        score += loss;
                    }

                    pBest[particle_index] = particles[particle_index];
                    pBest_scores[particle_index] = score;
                    if (score < gBest_scores[k]) {
                        lock_guard<std::mutex> lock(gBest_mutex); // Ensure exclusive access
                        gBests[k] = particles[particle_index];
                        gBest_scores[k] = score;
                    }
                    delete[] num_tokens_categories;
                }, i);
            }

            for (auto &f : init_futures) {
                f.get();
            }

//            for (int i = 0; i < particles.size(); ++i) {
//                for (int j = 0; j < particles[i].size(); ++j) {
//                    cout << particles[i][j] << ", ";
//                }
//                cout << "\n";
//            }
//            cout << "\n";

            cout << "\nParticle Optimization Loop: " << endl;

            for (int iteration = 0; iteration < max_iterations; ++iteration) {
//                inertia_weight = 0.9 - (0.9 - 0.4) * (iteration / max_iterations);
                vector<future<double>> futures(num_particles);

                for (int i = 0; i < num_particles; ++i) {
                    futures[i] = async(launch::async, [&](int particle_index) {

                        double* num_tokens_categories = new double[6];
                        for (int j = 0; j < 6; ++j) {
                            num_tokens_categories[j] = 0;
                        }

                        for (int j = 0; j < num_dimensions; ++j) {
                            double r1 = static_cast<double>(rand()) / RAND_MAX;
                            double r2 = static_cast<double>(rand()) / RAND_MAX;
                            int new_velocity = static_cast<int>(inertia_weight * velocities[particle_index][j]
                                                                + cognitive_weight * r1 * (pBest[particle_index][j] - particles[particle_index][j])
                                                                + social_weight * r2 * (gBests[k][j] - particles[particle_index][j]));
                            velocities[particle_index][j] = new_velocity;
                            int new_position = particles[particle_index][j] + velocities[particle_index][j];
                            if (new_position < min_bound) new_position = min_bound;
                            if (new_position > max_bound) new_position = max_bound;
                            particles[particle_index][j] = new_position;
                        }

                        double score = 0;
                        for (int j = 0; j < files.size(); ++j) {
                            score += scoreGame(particles[particle_index], gamesValueParameters[j], gamesPopularity[j], gamesTransactions[j],
                                               gamesInfluence[j], gamesPID[j], gamesNumPlayers[j], numAllocations, scoreType,
                                               conditionFunc, classConditionFunc, num_tokens_categories, agentType, loss_model, num_swarm_copies);
                        }
                        if(loss_model == "Macro" || loss_model == "Macro_Micro") {
                            double loss = .33333333 * (abs(num_tokens_categories[0] - num_tokens_categories[1])
                                    + abs(num_tokens_categories[2] - num_tokens_categories[3])
                                    + abs(num_tokens_categories[4] - num_tokens_categories[5]));
                            score += loss;
                        }

                        delete[] num_tokens_categories;
                        return score;
                    }, i);
                }

                for (int i = 0; i < num_particles; ++i) {
                    double score = futures[i].get();
                    if (score < pBest_scores[i]) {
                        pBest[i] = particles[i];
                        pBest_scores[i] = score;
                        if (score < gBest_scores[k]) {
                            lock_guard<std::mutex> lock(gBest_mutex); // Ensure exclusive access
                            gBests[k] = particles[i];
                            gBest_scores[k] = score;
                        }
                    }
                }

//                print("Particles: ");
//                for (int i = 0; i < particles.size(); ++i) {
//                    for (int j = 0; j < particles[i].size(); ++j) {
//                        cout << particles[i][j] << ", ";
//                    }
//                    cout << "\n";
//                }
//                cout << "\n";
//
//                double* num_tokens_categories = new double[6];
//                for (int j = 0; j < 6; ++j) {
//                    num_tokens_categories[j] = 0;
//                }
//
//                for (int i = 0; i < num_particles; ++i) {
//                    double score = scoreGame(particles[i], gamesValueParameters[0], gamesPopularity[0], gamesTransactions[0],
//                              gamesInfluence[0], gamesPID[0], gamesNumPlayers[0], numAllocations, scoreType,
//                              conditionFunc, classConditionFunc, num_tokens_categories, agentType, loss_model, num_swarm_copies);
//
//                    print(score);
//                }
//
//                delete[] num_tokens_categories;


                cout << "Iteration " << iteration + 1 << "/" << max_iterations << ", Best Score: " << gBest_scores[k] << endl;
                cout << "Best Parameters: ";
                for (double param : gBests[k]) {
                    cout << param << ",";
                }
                cout << endl << endl;
            }

            cout << "Best Parameters: ";
            for (double param : gBests[k]) {
                cout << param << " ";
            }
            cout << endl;
            cout << "Best Score: " << gBest_scores[k] << endl;
        }

        int num_genes = num_dimensions / num_swarm_copies;
        vector<vector<double>> setOfBestGenes;
        for (int i = 0; i < gBests.size(); ++i) {
            for (int k = 0; k < num_swarm_copies; k++) {
                vector<double> gene;
                for (int l = 0; l < num_genes; ++l) {
                    gene.push_back(gBests[i][k * num_genes + l]);
                }
                setOfBestGenes.push_back(gene);
            }
        }

        // Open a file in write mode
        ofstream outFile(theOutputDir + scoreType + "_" + humanCondition + "_" + humanClassCondition + "_output.csv");
        // Check if the file is open
        if (outFile.is_open()) {
            // Write the vector elements to the file
            for (int k=0; k < setOfBestGenes.size(); ++k) {
                for (int num: setOfBestGenes[k]) {
                    outFile << num << ",";
                }
                outFile << gBest_scores[k/num_swarm_copies] << '\n';
            }

            // Close the file
            outFile.close();
            cout << "Vector written to file successfully." << endl;
        } else {
            cerr << "Unable to open file for writing." << endl;
        }
        ofstream outFile2(theOutputDir + scoreType + "_" + humanCondition + "_" + humanClassCondition + ".csv");
        // Check if the file is open
        if (outFile2.is_open()) {
            // Write the vector elements to the file
            for (int k=0; k < setOfBestGenes.size(); ++k) {

                outFile2 << "gene";
                for (int num: setOfBestGenes[k]) {
                    outFile2 << "_" << num;
                }
                outFile2 << "," << gBest_scores[k/num_swarm_copies] ;
                outFile2 << "," << gBest_scores[k/num_swarm_copies];
                outFile2 << "," << gBest_scores[k/num_swarm_copies] << '\n';
            }

            // Close the file
            outFile2.close();
            cout << "Vector written to file successfully." << endl;
        } else {
            cerr << "Unable to open file for writing." << endl;
        }

    }
    else if (!strcmp(argv[1], "evolve")) {
        if (argc != 14) {
            printf("wrong number of parameters to specify how to evolve the population(s)\n");
            return -1;
        }

        srand(time(nullptr));

        // store the command-line parameters in the appropriate format
        string theFolder = argv[2];
        int popSize = atoi(argv[3]);
        int numGeneCopies = atoi(argv[4]);
        int startIndex = atoi(argv[5]);
        int numGens = atoi(argv[6]);
        int gamesPerGen = atoi(argv[7]);
        int agentsPerGame = atoi(argv[8]);
        int roundsPerGame = atoi(argv[9]);
        double povertyLine = atof(argv[10]);
        string varied = argv[12];
        string folderNum = argv[13];
        // bool addGovment = false;
        // if (!strcmp(argv[11], "addGovment"))
        //     addGovment = true;

        // load extra players specified in the configuration file
        vector<AbstractAgent *> configuredPlayers;

        string fnombre = "ScenarioIndicator/";
        fnombre += argv[11];
        fnombre += ".txt";
        ifstream in(fnombre);
        if (!in) {
            cout << "config file not found: " << fnombre << endl;
        }
        else {
            string line;
            while (!in.eof()) {
                getline(in, line);
                if (line == "Human")
                    configuredPlayers.push_back(new HumanAgent());
                else if (line == "Assassin")
                    configuredPlayers.push_back(new assassinAgent());
                if ((line.length() >= 4) && (line.substr(0,4) == "CoOp"))
                    configuredPlayers.push_back(new CoOpAgent(line));
            }
            in.close();
        }

//        cout << "num configured players: " << configuredPlayers.size() << endl;

        // set up population pool delimiters
        // int poolDelims[3];
        // if (numAgentPops == 1)
        //     poolDelims[0] = poolDelims[1] = poolDelims[2]= 99999;
        // else if (numAgentPops == 2) {
        //     poolDelims[0] = 100;
        //     poolDelims[1] = poolDelims[2]= 99999;
        // }
        // else if (numAgentPops == 3) {
        //     poolDelims[0] = 75;
        //     poolDelims[1] = 125;
        //     poolDelims[2]= 99999;
        // }

        GeneAgent **theGenePools, **theGenePools_old;
        if (startIndex != 0) {
            theGenePools_old = loadPopulationsFromFile(theFolder, startIndex-1, popSize, numGeneCopies, varied, folderNum);
            theGenePools = evolvePopulationPairs(theGenePools_old, popSize, numGeneCopies);

            // delete theGenePools_old
            deleteGenePool(theGenePools_old, popSize);
        }
        else {
            theGenePools = new GeneAgent*[popSize];
            for (int j = 0; j < popSize; j++) {
                theGenePools[j] = new GeneAgent("", numGeneCopies);
            }
        }
        int numPlayers = agentsPerGame + configuredPlayers.size();

        string possibleInitPops[5] = {"equal", "random", "step", "power", "highlow"};
        double *initialPopularities = new double[numPlayers];
        double *initialRelativePopularities = new double[numPlayers];
//        int *poolAssignments = new int[numPlayers];
        int *plyrIdxs = new int[numPlayers];
        AbstractAgent **agents = new AbstractAgent*[numPlayers];

        int sel;
        for (int gen = startIndex; gen < numGens; gen++) {  // let's do this for each generationzz
            for (int game = 0; game < gamesPerGen; game++) {  // let's do this for each generation
                printf("\n%i-%i\n", gen, game);
                if (!strcmp("varied", argv[12]))
                    sel = rand() % 5;
                else
                    sel = 0;
                cout << possibleInitPops[sel] << endl;
                defineInitialPopularities(possibleInitPops[sel], numPlayers, initialPopularities);

                printf("i_pops: ");
                double s = 0.0;
                for (int i = 0; i < numPlayers; i++) {
                    printf("%.1lf ", initialPopularities[i]);
                    s += initialPopularities[i];
                }
                printf("\n");

                for (int i = 0; i < numPlayers; i++)
                    initialRelativePopularities[i] = initialPopularities[i] / s;

                // assign each player to a pool based on their assigned initial popularity
                // for (int i = 0; i < numPlayers; i++) {
                //     poolAssignments[i] = -1;
                //     for (int j = 0; j < 3; j++) {
                //         if (initialPopularities[i] < poolDelims[j]) {
                //             poolAssignments[i] = j;
                //             break;
                //         }
                //     }
                // }

                // time to pick individuals from the gene pools
                for (int i = 0; i < agentsPerGame; i++) {
                    plyrIdxs[i] = rand() % popSize;
                    agents[i] = theGenePools[plyrIdxs[i]];
                }

                // add in the configured players
                for (int i = agentsPerGame; i < numPlayers; i++) {
                    plyrIdxs[i] = popSize + i;
                    agents[i] = configuredPlayers[i-agentsPerGame];
                }

                // record who the players were
                ofstream f("../Results/thePlayers/players_" + to_string(gen) + "_" + to_string(game) + ".txt");
                for (int i = 0; i < numPlayers; i++)
                    f << plyrIdxs[i] << " " << initialPopularities[i] << endl;
                f.close();

                // play the game
                PopularityMetrics *pmetrics = playGame(agents, numPlayers, roundsPerGame, initialPopularities, povertyLine, false, "");

                // compute relative popularity
                s = 0.0;
                for (int i = 0; i < numPlayers; i++)
                    s += pmetrics[i].avePop;
                for (int i = 0; i < numPlayers; i++)
                    pmetrics[i].relPop = pmetrics[i].avePop / s;

                // print to terminal
                printf("Indices: ");
                for (int i = 0; i < numPlayers; i++) {
                    printf("%i ", plyrIdxs[i]);
                }
                printf("\n");
                printf("avePop: ");
                for (int i = 0; i < numPlayers; i++) {
                    printf("%.2lf ", pmetrics[i].avePop);
                }
                printf("\n");
                printf("\n");
                printf("relPop: ");
                for (int i = 0; i < numPlayers; i++) {
                    printf("%.3lf ", pmetrics[i].relPop);
                }
                printf("\n");
                printf("average popularity: %lf\n\n", s / agentsPerGame);

                // update the fitness of the agents the played in the game
                for (int i = 0; i < agentsPerGame; i++) {
                    if (theGenePools[plyrIdxs[i]]->playedGenes) {
                        theGenePools[plyrIdxs[i]]->count ++;
                        theGenePools[plyrIdxs[i]]->absoluteFitness += ((pmetrics[i].avePop + pmetrics[i].endPop) / 2.0);// / initialPopularities[i];
                        theGenePools[plyrIdxs[i]]->relativeFitness += pmetrics[i].relPop;// / initialRelativePopularities[i];
                    }
                }

                delete[] pmetrics;
            }

            writeGenerationResults(theGenePools, popSize, gen, agentsPerGame, numGeneCopies, varied, folderNum); // HERE!!

            // evolve population
            theGenePools_old = theGenePools;
            theGenePools = evolvePopulationPairs(theGenePools_old, popSize, numGeneCopies);
            deleteGenePool(theGenePools_old, popSize);
        }

        deleteGenePool(theGenePools, popSize);
        delete[] initialPopularities;
        delete[] initialRelativePopularities;
        // delete[] poolAssignments;
        delete[] plyrIdxs;
        delete[] agents;

        // delete extra players specified by the configuration file
        for (int i = 0; i < configuredPlayers.size(); i++) {
            if (configuredPlayers[i]->whoami == "human")
                delete ((HumanAgent *)configuredPlayers[i]);
            else if (configuredPlayers[i]->whoami == "assassin")
                delete ((assassinAgent *)configuredPlayers[i]);
            else if ((configuredPlayers[i]->whoami.length() >= 4) && (configuredPlayers[i]->whoami.substr(0,4) == "CoOp"))
                delete ((CoOpAgent *)configuredPlayers[i]);
            else {
                cout << "don't know how to delete " << configuredPlayers[i]->whoami << endl;
            }
        }
    }
    else if (!strcmp(argv[1], "example")) {
        if (argc != 8 && argc != 9) {
            printf("wrong number of parameters to specify how to *play*: %i\n", argc);
            return -1;
        }

        // srand(time(nullptr) + 100 * atoi(argv[15]));

        // store the command-line parameters in the appropriate format
//        string theCABFile = argv[2];
        print("Example Game Parameters:");
        string theGamesDir = argv[2];
        print("\ttheGamesDir         : ", theGamesDir);
        string gameFile = argv[3];
        print("\ttheGameFile         : ", gameFile);
        int numAllocations = stoi(argv[4]); // 10
        print("\tnumAllocations      : ", numAllocations);
        string scoreType = argv[5]; // absolute, mean, cosine
        print("\tscoreType           : ", scoreType);
        string playerType = argv[6]; // default, experienced, novice, class
        string genestring;
        if(playerType == "default_mean") {
            genestring = "gene_100_78_100_0_100_24_0_75_100_16_8_0_18_0_0_0_0_0_100_100_7_0_80_0_100_100_85_3_52_99_34_0_2";
        }
        else if(playerType == "default_absolute") {
            genestring = "gene_3_38_100_0_100_0_45_58_41_100_9_8_0_7_0_38_3_1_51_0_59_0_0_0_100_100_53_100_0_100_41_0_100";
        }
        else if (playerType == "experienced_mean") {
            // genestring = "gene_0_7_97_100_79_25_17_0_0_100_0_67_20_95_0_0_74_20_0_100_0_100_18_100_59_0_86_48_52_100_41_33_100";
            // genestring = "gene_0_85_100_100_100_26_2_13_15_25_0_0_17_0_0_0_1_0_100_96_100_55_85_100_16_76_4_100_100_100_36_0_100";
            // genestring = "gene_100_100_100_100_100_23_100_63_65_100_100_100_17_100_0_0_100_36_66_99_8_100_0_99_24_100_100_0_100_55_39_100_0";
            genestring = "gene_48_5_42_100_100_23_4_50_46_100_0_99_16_42_0_0_100_26_100_100_0_0_0_0_0_0_83_16_60_74_38_0_0";
            // genestring = "gene_21_100_100_0_100_23_100_45_47_100_1_100_16_100_0_0_100_27_13_100_100_24_79_0_100_100_100_100_100_100_39_0_0";
        }
        else if (playerType == "experienced_absolute") {
            // genestring = "gene_69_0_100_100_78_0_16_46_3_100_0_100_10_95_1_0_0_62_55_0_94_89_0_58_0_0_23_0_1_99_41_79_4";
            // genestring = "gene_100_0_100_100_100_0_3_72_48_100_100_1_10_100_0_3_100_0_100_22_0_0_100_58_0_99_100_100_100_0_41_0_0";
            // genestring = "gene_99_53_100_99_100_0_61_57_40_100_21_11_10_0_48_0_96_93_73_0_68_100_73_94_99_9_100_100_96_73_41_37_99";
            // genestring = "gene_100_100_100_98_100_0_100_100_64_100_100_0_10_100_1_0_100_1_100_100_100_100_77_98_0_100_1_100_100_100_41_14_100";
            genestring = "gene_100_98_100_100_79_0_100_58_48_100_41_100_10_99_1_0_100_42_86_100_97_0_100_0_0_92_63_100_86_1_41_71_87";
        }
        else if(playerType == "novice_mean") {
            genestring = "gene_100_99_100_0_79_42_41_52_58_61_3_0_34_48_0_0_0_0_100_1_0_67_0_19_30_95_0_60_100_0_26_30_4";
        }
        else if(playerType == "novice_absolute") {
            genestring = "gene_0_55_100_99_78_0_100_35_1_100_57_99_28_1_0_3_2_39_20_17_100_100_95_0_0_100_100_87_9_100_32_100_100";
        }
        else{
            throw invalid_argument("not a valid player type");
        }
        print("\tgene                : ", genestring);
        vector<int> gene = Algebra::arr2Vec(GeneAgent(genestring,1).myGenes, predef_NUMGENES);

        int round = stoi(argv[7]);
        print("\tRound               : ", round);

        vector<vector<string>> gamesData;
        vector<double> gamesValueParameters;
        vector<vector<double>> gamesPopularity;
        vector<vector<double>> gamesTransactions;
        vector<vector<double>> gamesInfluence;
        vector<string> gamesPID;
        int gamesNumPlayers = 0;

        preprocessGameFile(theGamesDir.append(gameFile), gamesData, gamesValueParameters, gamesPopularity,
                           gamesTransactions, gamesInfluence, gamesPID, gamesNumPlayers);

        vector<vector<vector<int>>> allAllocations = getPossibleActions(gene, gamesValueParameters, gamesPopularity, gamesTransactions,
                  gamesInfluence, gamesPID, gamesNumPlayers, numAllocations, useModifiedGeneAgent);


        for (int i = 0; i < allAllocations[0].size(); i++) {
            for (int j = 0; j < allAllocations.size(); j++) {
                for (int k = 0; k < allAllocations[0][0].size(); k++) {
                    cout << allAllocations[j][i][k] << "\t";
                }
            }
            cout << endl;
        }

    }
    else if (!strcmp(argv[1], "playMixed")) {
        if (argc != 6) {
            cout << "wrong number of parameters" << endl;
        }
        int gameNumber = atoi(argv[5]);
        srand(time(nullptr) + 100 * gameNumber);
        string agentMix = argv[2];
        int numPlayers = agentMix.length();
        int numRounds = atoi(argv[3]);
        string initPopType = argv[4];

        // load in all the agents
        int numPerPool = 60;     // number of agents specified in each gene pool (mine is 10, yours is probably 60)
        GeneAgent **CAB_e1 = loadPopulationsFromFile("../Results/theGenerations/BestBots/CAB-e1.csv", numPerPool, 1, useModifiedGeneAgent);
        GeneAgent **CAB_v1 = loadPopulationsFromFile("../Results/theGenerations/BestBots/CAB-v1.csv", numPerPool, 1, useModifiedGeneAgent);
        GeneAgent **CAB_e3 = loadPopulationsFromFile("../Results/theGenerations/BestBots/CAB-e3.csv", numPerPool, 3, useModifiedGeneAgent);
        GeneAgent **CAB_v3 = loadPopulationsFromFile("../Results/theGenerations/BestBots/CAB-v3.csv", numPerPool, 3, useModifiedGeneAgent);

        AbstractAgent **agents = new AbstractAgent*[numPlayers];
        cout << "numAgents: " << numPlayers << endl;
        for (int i = 0; i < agentMix.length(); i++) {
            switch (agentMix[i]) {
                case '0':
                    // cout << "CAB-e1" << endl;
                    agents[i] = CAB_e1[rand() % numPerPool];
                    break;
                case '1':
                    // cout << "CAB-v1" << endl;
                    agents[i] = CAB_v1[rand() % numPerPool];
                    break;
                case '2':
                    // cout << "CAB-e3" << endl;
                    agents[i] = CAB_e3[rand() % numPerPool];
                    break;
                case '3':
                    // cout << "CAB-v3" << endl;
                    agents[i] = CAB_v3[rand() % numPerPool];
                    break;
                default: cout << "agent type not found" << endl;
            }
        }

        double *initialPopularities = new double[numPlayers];
        defineInitialPopularities(initPopType, numPlayers, initialPopularities);

        PopularityMetrics *pmetrics = playGame(agents, numPlayers, numRounds, initialPopularities, 0.0, false, "");

        // delete stuff
        deleteGenePool(CAB_e1, numPerPool);
        deleteGenePool(CAB_v1, numPerPool);
        deleteGenePool(CAB_e3, numPerPool);
        deleteGenePool(CAB_v3, numPerPool);

        delete[] agents;
        delete[] pmetrics;
        delete[] initialPopularities;
    }
    else if (!strcmp(argv[1], "testGeneAgentMod")) {
        string geneStr = "gene_100_100_84_92_100_78_95_90_100_100_100_97_0_8_9_0_8_87_1_100_0_100_100_97_100_91_100_100_100_59_100_0_100";
        string geneModStr = "geneMod_100_100_100_100_100_100_100_100_100_100_100_100_100_100_100_100_100_100";
        int _numGeneCopies = 1;
        int playerIndex = 0;
        int numPlayers = 8;
        int roundNum = 10;
        int numTokens = numPlayers*2;

        int attackPlayerIndex = 6;

        double alpha = 0.2;
        double beta = 0.5;
        double coefs[3] = {0.95, 1.3, 1.6};
        double povertyLine = (double) (atoi(argv[10]));
        bool forcedRandom = false;

        // Initialize the popularities with specific values
        double *popularities = new double[numPlayers];
        popularities[0] = 173; popularities[1] = 237; popularities[2] = 173; popularities[3] = 135;
        popularities[4] = 258; popularities[5] = 261; popularities[6] = 171; popularities[7] = 177;
        // Initialize the influence matrix with specific values
        double **influence = new double *[numPlayers];
        for (int i = 0; i < numPlayers; ++i) {
            influence[i] = new double[numPlayers];
        }

        influence[0][0] = 35; influence[0][1] = 00; influence[0][2] = 71; influence[0][3] = 00; influence[0][4] = 70; influence[0][5] = 01; influence[0][6] = 00; influence[0][7] = 01;
        influence[1][0] = 00; influence[1][1] = 77; influence[1][2] = 00; influence[1][3] = 30; influence[1][4] = 55; influence[1][5] = 01; influence[1][6] = 64; influence[1][7] = 01;
        influence[2][0] = 70; influence[2][1] = 00; influence[2][2] = 34; influence[2][3] = 00; influence[2][4] = 70; influence[2][5] = 00; influence[2][6] = 00; influence[2][7] = 00;
        influence[3][0] = 00; influence[3][1] = 40; influence[3][2] = 00; influence[3][3] = 29; influence[3][4] = 01; influence[3][5] = 80; influence[3][6] = 01; influence[3][7] = 00;
        influence[4][0] = 65; influence[4][1] = 49; influence[4][2] = 65; influence[4][3] = 00; influence[4][4] = 59; influence[4][5] = 00; influence[4][6] = 00; influence[4][7] = 00;
        influence[5][0] = 00; influence[5][1] = 01; influence[5][2] = 00; influence[5][3] = 72; influence[5][4] = 00; influence[5][5] = 103; influence[5][6] = 01; influence[5][7] = 72;
        influence[6][0] = 00; influence[6][1] = 68; influence[6][2] = 00; influence[6][3] = 01; influence[6][4] = 00; influence[6][5] = 01; influence[6][6] = 33; influence[6][7] = 67;
        influence[7][0] = 01; influence[7][1] = 01; influence[7][2] = 00; influence[7][3] = 00; influence[7][4] = 00; influence[7][5] = 74; influence[7][6] = 70; influence[7][7] = 35;


        GeneAgentMod geneAgent = GeneAgentMod(geneStr, _numGeneCopies, geneModStr);
        geneAgent.setGameParams(coefs, alpha, beta, povertyLine, forcedRandom);

        int* allocations = new int[numPlayers];
        double* received = new double [numPlayers];
        for (int i = 0; i < roundNum; ++i) {
            for (int i = 0; i < numPlayers; i++) {
                allocations[i] = 0;
            }
            for (int i = 0; i < numPlayers; i++) {
                received[i] = 0;
            }
            geneAgent.playRound(numPlayers, numTokens, playerIndex, i, received, popularities, influence, allocations);
        }
        influence[attackPlayerIndex][2] = -60; influence[2][attackPlayerIndex] = -60;
        received[attackPlayerIndex] = -16;
        // Calculate percolation centrality using priority queue
        vector<double> centralitypq = geneAgent.calculatePercolationCentrality(playerIndex, numPlayers, influence);

        // Output results
        cout << "Percolation Centrality from node " << playerIndex << " to other nodes:\n";
        for (int i = 0; i < numPlayers; ++i) {
            cout << "Node " << i << ": " << centralitypq[i] << "\n";
        }
        cout << endl;

        geneAgent.playRound(numPlayers, numTokens, playerIndex, roundNum, received, popularities, influence, allocations);

        // Output results
        cout << "Allocation of Tokens of Player: " << playerIndex << " to other players:\n";
        for (int i = 0; i < numPlayers; ++i) {
            cout << "Node " << i << ": " << allocations[i] << "\n";
        }
        cout << endl;

        // Memory management
        for (int i = 0; i < numPlayers; ++i) {
            delete influence[i];
        }
        delete influence;
    }
    else {
        printf("Command %s not found\n", argv[1]);
    }

    return 0;
}
