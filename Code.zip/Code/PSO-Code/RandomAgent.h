#ifndef RANDOMAGENT_H
#define RANDOMAGENT_H

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <sstream>
#include <fstream>

#include <chrono>

#include "defs.h"
#include "AbstractAgent.h"
#include "ToString.h"
#include "CommunityEvaluation.h"

#include <iostream>
#include <unistd.h>
#include <climits>


using namespace std;
using namespace ToString;

class RandomAgent : public AbstractAgent {
public:
//    int count;
//    double relativeFitness, absoluteFitness;
//
//    int *myGenes, numGenes;
//    bool playedGenes;
//    string dirSTATE;

    RandomAgent() {

    }

    ~RandomAgent() {

    }

//    virtual void playRound(int numPlayers, int numTokens, int playerIdx, int roundNum, double *received, double *popularities, double **influence, int *allocations) {
//        for (int i = 0; i < numPlayers; i++) {
//            allocations[i] = 0;
//        }
//
//        for (int i = 0; i < numTokens; i++) {
//            allocations[rand() % (numPlayers)] += 1;
//        }
//
//        for (int i = 0; i < numPlayers; i++) {
//            if (i != playerIdx && rand() % 2 != 1) {
//                allocations[i] *= -1;
//            }
//        }
//
//    }

    virtual void updatePastInteractions(int numPlayers, int *allocations) {

    }

    virtual void playRound(int numPlayers, int numTokens, int playerIdx, int roundNum, double *received, double *popularities, double **influence, int *allocations) {
        // Initialize allocations to zero
        for (int i = 0; i < numPlayers; i++) {
            allocations[i] = 0;
        }

        // Define probabilities
        const double GIVE_PROB = 0.72;
        const double KEEP_PROB = 0.24;
        const double STEAL_PROB = 0.04;

        for (int i = 0; i < numTokens; i++) {
            double randValue = static_cast<double>(rand()) / RAND_MAX; // Generate a random number in [0, 1)

            if (randValue < GIVE_PROB) {
                // Gives a token to another player
                int recipient;
                do {
                    recipient = rand() % numPlayers;
                } while (recipient == playerIdx); // Ensure not giving to self
                if (allocations[recipient] < -0.1){
                    allocations[recipient] -= 1;
                } else {
                    allocations[recipient] += 1;
                }
            } else if (randValue < GIVE_PROB + KEEP_PROB) {
                // Keeps a token
                allocations[playerIdx] += 1;
            } else {
                // Steals a token from another player
                int victim;
                do {
                    victim = rand() % numPlayers;
                } while (victim == playerIdx); // Ensure not stealing from self
                if (allocations[victim] > 0.1){
                    allocations[victim] += 1;
                } else {
                    allocations[victim] -= 1;
                }
            }
        }
    }

    virtual void postContract(int playerIdx) {}

};

#endif