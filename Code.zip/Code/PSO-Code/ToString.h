#ifndef TOSTRING_H
#define TOSTRING_H

#include <iostream>
#include <iomanip>
#include <fstream>

#include <string>
#include <cstring>
#include <sstream>

#include <vector>
#include <list>
#include <map>
#include <set>

#include <cmath>
#include <algorithm>
#include <functional>
#include <numeric>
#include <limits>

#include <cstdlib>
#include <ctime>
#include <thread>
#include <future>
#include <chrono>

using namespace std;

namespace ToString {
    // Base case: no arguments left to process
    static void print();

    // Variadic template function to print multiple arguments
    template<typename T, typename... Args>
    static void print(const T& first, const Args&... args);

//    template<typename string, typename... Args>
//    static string str(string first, const Args&... args);

    template <typename T>
    static string str(T* array, int size);

    template <typename T>
    static string str(T** array, int row_size, int col_size);

    template<typename T>
    static string str(int *array, int size);

    template <typename T>
    static string str(const vector<T>& vec, int precision = 2);

    template <typename T>
    static string str(const set<T>& s, int precision = 2);

    template <typename K, typename V>
    static string str(const map<K, V>& m, int precision = 2);


};

#include "ToString.tpp" // Include the implementation for the template functions

#endif // TOSTRING_H
