#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <functional>
#include <cstring>
#include <numeric>
#include <limits>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <future>
#include <chrono>
#include <sstream>

using namespace std;

int main(int argc, char *argv[]){
    stringstream arg_ss;
    for (int i = 1; i < argc-1; ++i) {
         arg_ss << argv[i] << " ";
    }

//    cout << argc-1;
//    cout << argv[argc-1]

    // The command you want to run, for example, listing files in the current directory
    for (int i = 0; i < stoi(argv[argc-1]); ++i) {
        string command = "./main " + arg_ss.str() + to_string(i);
        // Execute the command
        int result = std::system(command.c_str());

        // Check the result
        if (result == 0) {
            std::cout << "Iteration " + to_string(i) + " executed successfully." << std::endl;
//            cout << command.c_str() << "\n";
        } else {
            std::cerr << "Iteration " + to_string(i) + "execution failed with code: " << result << std::endl;
            cout << command.c_str() << "\n";
            exit(-1);
        }
    }

    return 0;
}
