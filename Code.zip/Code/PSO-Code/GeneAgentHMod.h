#ifndef GENEAGENTHMOD_H
#define GENEAGENTHMOD_H

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <sstream>
#include <fstream>
#include <chrono>
#include <unistd.h>
#include <climits>
#include <queue>
#include <cmath>

#include "defs.h"
#include "AbstractAgent.h"
#include "ToString.h"
#include "CommunityEvaluation.h"
#include "GeneAgent.h"
#include "Algebra.h"


using namespace std;
using namespace ToString;


class GeneAgentHMod : public GeneAgent {

protected:
    int *myGeneMods, numGeneMods;
    string dirSTATE;
    vector<double**> pastInfluences;
    vector<double**> pastFriendships;

    double alphaOriginal;
    double alphaPrime;

public:
    using GeneAgent::GeneAgent;

    struct Node {
        int index;
        double influence;

        // Custom comparator for priority queue (max-heap behavior)
        bool operator<(const Node& other) const {
            return influence < other.influence; // Max heap based on influence
        }
    };

    // Constructor for the child class
    GeneAgentHMod(string geneStr, int _numGeneCopies, string geneModStr) : GeneAgent(geneStr, _numGeneCopies){
        if (geneModStr == "") {
            numGeneMods = predef_NUMGENEHMODS * numGeneCopies;
            myGeneMods = new int[numGeneMods];
            for (int i = 0; i < numGeneMods; i++) {
                myGeneMods[i] = rand() % 101;
            }
        }
        else {
            // printf("%s\n", geneStr.c_str());
            vector<string> words = parse(geneModStr);
            numGeneMods = words.size()-1;

            if (numGeneMods != (predef_NUMGENEHMODS * numGeneCopies)) {
                printf("much confusion about the number of genes I should have; %i vs %i\n", predef_NUMGENEHMODS, numGeneMods);
                exit(1);
            }

            myGeneMods = new int[numGeneMods];
            for (int i = 1; i < numGeneMods+1; i++)    // // // put +1 back once generate it
                myGeneMods[i-1] = stoi(words[i]);
        }
    }

    GeneAgentHMod(const vector<int> &genes, int _numGeneCopies, const vector<int> &genesMods) : GeneAgent(genes, _numGeneCopies) {
        numGeneMods = predef_NUMGENEHMODS * _numGeneCopies;
        if (genesMods.size() != numGeneMods) {
            printf("a lot of confusion about the number of genes I should have; %i vs %i\n",
                   predef_NUMGENEHMODS * _numGeneCopies, numGeneMods);
            exit(1);
        }

        myGeneMods = new int[numGeneMods];
        for (int i = 0; i < numGeneMods; i++) {
            myGeneMods[i] = genesMods[i];
        }

    }

    ~GeneAgentHMod(){
        delete[] myGeneMods;
        for (int i = 0; i < pastInfluences.size(); ++i) {
            for (int j = 0; j < nPlayers; ++j) {
                delete[] pastInfluences[i][j];
                delete[] pastFriendships[i][j];
            }
            delete[] pastInfluences[i];
            delete[] pastFriendships[i];
        }
    }


    void setGameParams(double _coefs[3], double _alpha, double _beta, double _povertyLine, bool _forcedRandom) override {
        alphaOriginal = _alpha;
        alphaPrime = double(myGeneMods[GENEMOD_FRIENDSHIP_ALPHA]) / 100;
        GeneAgent::setGameParams(_coefs, alphaPrime, _beta, _povertyLine, _forcedRandom);
    }

    double** createIdentityMatrix(int size) {
        // Allocate memory for the double pointer array (rows)
        double** identityMatrix = new double*[size];

        for (int i = 0; i < size; ++i) {
            // Allocate memory for each row (columns)
            identityMatrix[i] = new double[size];

            for (int j = 0; j < size; ++j) {
                // Set 1.0 for diagonal elements, 0.0 otherwise
                identityMatrix[i][j] = (i == j) ? 1.0 : 0.0;
            }
        }

        return identityMatrix;
    }

    double** deepCopyMatrix(double** originalMatrix, int rows, int cols) {
        // Allocate memory for the new matrix
        double** newMatrix = new double*[rows];
        for (int i = 0; i < rows; ++i) {
            newMatrix[i] = new double[cols];
            for (int j = 0; j < cols; ++j) {
                // Copy each element
                newMatrix[i][j] = originalMatrix[i][j];
            }
        }
        return newMatrix;
    }

    double** calculateFriendship(double **friendship, double **pastFriendship, double **influence, double **pastInfluence, int numPlayers) {
        double **changeInInfluence = new double*[numPlayers];
        for (int i = 0; i < numPlayers; i++) {
            changeInInfluence[i] = new double[numPlayers];
        }
        for (int i = 0; i < numPlayers; ++i) {
            for (int j = 0; j < numPlayers; ++j) {
                changeInInfluence[i][j] = (influence[i][j] - pastInfluence[i][j] * (1 - alphaOriginal)) / alphaOriginal;
            }
        }

        for (int i = 0; i < numPlayers; ++i) {
            for (int j = 0; j < numPlayers; ++j) {
                friendship[i][j] = alphaPrime * changeInInfluence[i][j] + (1 - alphaPrime) * pastFriendship[i][j];
            }
        }

        // clear memory used
        for (int j = 0; j < numPlayers; ++j) {
            delete[] changeInInfluence[j];
        }
        delete[] changeInInfluence;

        return friendship;
    }


    virtual void playRound(int numPlayers, int numTokens, int playerIdx, int roundNum, double *received, double *popularities, double **influence, int *allocations) override {
        double **friendship = new double*[numPlayers];
        for (int i = 0; i < numPlayers; i++) {
            friendship[i] = new double[numPlayers];
        }

        if(roundNum == 0) {
            pastFriendships.push_back(createIdentityMatrix(numPlayers));
            pastInfluences.push_back(createIdentityMatrix(numPlayers));
        }

        calculateFriendship(friendship, pastFriendships[pastFriendships.size()-1], influence, pastInfluences[pastInfluences.size()-1], numPlayers);

        pastFriendships.push_back(friendship);
        pastInfluences.push_back(deepCopyMatrix(influence, numPlayers, numPlayers));

        GeneAgent::playRound(numPlayers, numTokens, playerIdx, roundNum, received, popularities, friendship, allocations);
    }

};


#endif




















