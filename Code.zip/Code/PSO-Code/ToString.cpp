#include "ToString.h"

namespace ToString {

//    string toStr(char c){
//        return to_string(c);
//    }
//
//    string toStr(int i){
//        return to_string(i);
//    }
//
//    string toStr(double d){
//        return to_string(d);
//    }
//
//    string toStr(long l){
//        return to_string(l);
//    }
//
//    string toStr(string s){
//        return s;
//    }

}