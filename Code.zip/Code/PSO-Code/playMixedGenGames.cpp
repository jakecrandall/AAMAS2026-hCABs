#include <iostream>
#include <stdio.h>
#include <thread>
#include <cstring>
#include <string>

using namespace std;


// g++ playGamesFromGen.cpp -o genGames

// ./jhgsim [generationFolder] [popSize] [number_of_gene_pools] [gen] [numAgents] [numRounds] [best_agents/rnd_agents]
// [initPopType] [povertyLine] [deterministic/nondeterministic] [config] [varied/equal] [num_rounds]


int main(int argc, char *argv[]) {

    char cmd[1024], cmd2[1024];

    // create the directory
//    snprintf(cmd2, 1024, "mkdir %s", theDir);
//    system(cmd2);

    snprintf(cmd, 1024, "./main playMixed 1111133333 30 equal");

    for (int g = 0; g < 50; g++) {
        string str = string();
        str.assign(cmd).append(" ").append(to_string(g));
        system(str.c_str());
        snprintf(cmd2, 1024, "mv ../Results/theGameLogs/%s/log_1000_1000.csv %s/game_%i.csv", "BestBots", "../Results/theGameLogs/BestBots", g);
        system(cmd2);
    }

    return 0;
}

