#include <iostream>
#include <stdio.h>
#include <thread>
#include <cstring>
#include <string>

using namespace std;


// g++ playGamesFromGen.cpp -o genGames

// ./jhgsim [generationFolder] [popSize] [number_of_gene_pools] [gen] [numAgents] [numRounds] [best_agents/rnd_agents]
// [initPopType] [povertyLine] [deterministic/nondeterministic] [config] [varied/equal] [num_rounds]

void run_thread(char *argv[], string folderNum){
    char cmd[1024], cmd2[1024], theDir[1024];

    // create the directory
    if (strcmp(argv[11], "assassins2Config") == 0){
        snprintf(theDir, 1024, "../Results/simulated_games/%s/AssGames_%s_%s_%s_%s", folderNum.c_str(), argv[3], argv[12], argv[4], argv[8]);
    }
    else {
        snprintf(theDir, 1024, "../Results/simulated_games/%s/RndGames_%s_%s_%s_%s", folderNum.c_str(), argv[3], argv[12], argv[4], argv[8]);
    }
    snprintf(cmd2, 1024, "mkdir %s", theDir);
    system(cmd2);

    snprintf(cmd, 1024, "./main play %s %s %s %s %s %s %s %s %s %s %s %s %s",
             argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12], folderNum.c_str());
//    ./jhgsim play [generationFolder] [popSize] [numGeneCopies] [gen] [numAgents] [numRounds] [best_agents/rnd_agents] [initPopType] [povertyLine] [deterministic/nondeterministic] [config]


    for (int g = 0; g < atoi(argv[13]); g++) {
        string str = string();
        str.assign(cmd).append(" ").append(to_string(g));
        system(str.c_str());
        snprintf(cmd2, 1024, "mv ../Results/theGameLogs/%s/log_1000_1000.csv %s/game_%i.csv", folderNum.c_str(), theDir, g);
        system(cmd2);
    }

}


int main(int argc, char *argv[]) {
    if (argc != 14) {
        cout << "not the right number of parameters" << endl;
    }
    thread basic[6];
    for(int i = 0; i < 6; i++){
        basic[i] = thread(run_thread, argv, to_string(i));
    }

    for (auto & i : basic){
        i.join();
    }

    return 0;
}



