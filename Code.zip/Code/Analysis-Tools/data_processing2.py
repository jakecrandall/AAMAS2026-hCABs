from numpy.ma.core import array

import configuration as config
import networkx as nx
import numpy as np
import pandas as pd
import json
from polarization import *


class DataProcessing:
    def __init__(self, filename):
        # Pre-processing
        data = pd.read_csv(filename)

        self.round = np.array(data['round'])
        self.alpha = np.array(data['alpha'])
        self.beta = np.array(data['beta'])
        self.give = np.array(data['give'])
        self.keep = np.array(data['keep'])
        self.steal = np.array(data['steal'])

        num_players = data.columns.get_loc("0-T-0") - 6


        data = np.array(data)
        self.popularities = data[:, 6:6 + num_players]
        data = data[:, 6 + num_players:]

        self.transactions = np.reshape(data[:, :num_players * num_players], (data.shape[0], num_players,
                                                                             num_players)) * 2 * num_players
        self.influences = np.reshape(data[:, num_players * num_players:2 * num_players * num_players], (data.shape[0], num_players,
                                                                           num_players))

        if data.shape[1] > 2 * num_players * num_players:
            self.humans = data[0, 2 * num_players * num_players:]
        else:
            self.humans = []
            for i in range(num_players):
                self.humans += ['Bot']

    def get_transactions(self):
        return self.transactions

    def get_influences(self):
        return self.influences

    def get_popularities(self):
        return self.popularities

    def get_lobby(self):
        return None

    def get_game_params(self):
        return None

    def get_groups(self):
        return None

    def get_human(self):
        return self.humans

    def get_player_round_info(self):
        return None

    def get_players(self):
        return None

    def get_chat_info(self):
        return None

    def get_government_round_info(self):
        return None

    def get_transaction_graphs(self, non_negative=False):
        graphs = []
        for i in range(self.transactions.shape[0]):
            transaction = self.transactions[i]
            if non_negative:
                transaction = transaction.copy()
                transaction[transaction < 0] = 0
            graphs += [nx.from_numpy_array(transaction.astype(int), create_using=nx.DiGraph)]
        return graphs[1:]

    def get_influence_graphs(self, non_negative=False):
        graphs = []
        for i in range(self.influences.shape[0]):
            influences = self.influences[i]
            if non_negative:
                influences = influences.copy()
                influences[influences < 0] = 0
            infl = influences.astype(int)
            if infl.shape[1] > infl.shape[0]:
                infl = infl[:, :-1]
            graphs += [nx.from_numpy_array(infl, create_using=nx.DiGraph)]
        return graphs[1:]

    def get_polarization_metrics(self, transpose_influence=False):
        polarizationCoefs = []
        for r, popul, trans, influ in zip(self.round, self.popularities, self.transactions, self.influences):
            if r != 0:
                r_info = RoundInfo()
                r_info.numPlayers = trans.shape[0]
                r_info.alpha = self.alpha[0]
                r_info.beta = self.beta[0]
                r_info.give = self.give[0]
                r_info.keep = self.keep[0]
                r_info.steal = self.steal[0]

                r_info.popularities = popul
                r_info.transactions = trans
                if transpose_influence:
                    r_info.influences = influ.T
                else:
                    r_info.influences = influ

                polarizationCoefs += [computePolarization(r_info)]

        return polarizationCoefs


# DataProcessing('RndGames_9_10_30_equal/game_0.csv')
