import configuration as config
import data_processing2 as data_processing
from metric_manager import *
import networkx as nx
import networkx.algorithms.community as nx_comm
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.use('tkagg')
# mpl.use('module://backend_interagg')
import numpy as np
import seaborn
import re
import json

# font = {'family': 'normal',
#         'weight': 'bold',
#         'size': 15}

# plt.rc('font', **font)
# plt.rc('axes', **font)
# plt.rcParams.update({'font.size':15, 'weight': 'bold'})
plt.rcParams.update({'font.size': 14})
plt.rc('axes', labelweight='bold')
plt.rcParams['figure.figsize'] = [6, 5]

def gini(x):
    # (Warning: This is a concise implementation, but it is O(n**2)
    # in time and memory, where n = len(x).  *Don't* pass in huge
    # samples!)

    # Mean absolute difference
    mad = np.abs(np.subtract.outer(x, x)).mean()
    # Relative mean absolute difference
    rmad = mad / np.mean(x)
    # Gini coefficient
    g = 0.5 * rmad
    return g


def gini_coefficient(x):
    """Compute Gini coefficient of array of values"""
    diffsum = 0
    for i, xi in enumerate(x[:-1], 1):
        diffsum += np.sum(np.abs(xi - x[i:]), axis=0)
    return diffsum / (len(x) ** 2 * np.mean(x, axis=0))


# mode = ['mean', 'var', 'gini']
# mode1 = ['mean', 'var']
def pop_graph(transaction, metric, num_gen, mode1, mode2, things, assassins=False):
    plt.figure()
    for thing in things:
        avg_pop = []
        for name0, name1 in zip(names0, names1):
            for j in range(num_gen):
                for i in range(num_games):
                    file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                    if assassins:
                        data = np.load(file_path + 'Ass' + name0 + thing + name1 + str(i) + "_" + transaction + "_" + metric + ".npy")
                    else:
                        data = np.load(file_path + 'Rnd' + name0 + thing + name1 + str(i) + "_" + transaction + "_" + metric + ".npy")
                    if assassins:
                        data = data[:, :-2]
                    if mode2 == 'mean':
                        avg_pop += [np.mean(data, axis=1)]
                    elif mode2 == 'var':
                        avg_pop += [np.var(data, axis=1)]
                    elif mode2 == 'gini':
                        avg_pop += [gini_coefficient(data.T)]
                    else:
                        Exception('invalid mode option')
        mean_pop = np.array(avg_pop)

        x = np.arange(np.size(mean_pop, axis=1))

        if mode1 == 'mean':
            plt.plot(x, np.mean(mean_pop, axis=0), label=thing)
        elif mode1 == 'var':
            plt.plot(x, np.var(mean_pop, axis=0), label=thing)
        elif mode1 == 'err':
            plt.plot(x, np.std(mean_pop, axis=0) / np.sqrt(num_games), label=thing)
        elif mode1 == 'quart':  # interquartile range
            plt.plot(x, np.percentile(mean_pop, 75, axis=0) - np.percentile(mean_pop, 25, axis=0), label=thing)
    plt.title(testing + " " + transaction + " " + metric)
    plt.xlabel('Round')
    plt.ylabel(transaction + ' ' + metric)
    plt.legend()
    plt.show()


def pop_growth_graph(transaction, metric, num_gen, mode1, mode2, things, assassins=False):
    plt.figure()
    for thing in things:
        avg_pop, avg_pop_25, avg_pop_75, = [], [], []
        for name0, name1 in zip(names0, names1):
            for j in range(num_gen):
                for i in range(num_games):
                    file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                    if assassins:
                        data = np.load(file_path + 'Ass' + name0 + thing + name1 + str(i) + "_" + transaction + "_" + metric + ".npy")
                    else:
                        data = np.load(file_path + 'Rnd' + name0 + thing + name1 + str(i) + "_" + transaction + "_" + metric + ".npy")
                    if assassins:
                        data = data[:, :-2]
                    avg_pop += [np.mean(data, axis=1)]
                    avg_pop_25 += [np.percentile(data, 25, axis=1)]
                    avg_pop_75 += [np.percentile(data, 75, axis=1)]

        mean_pop = np.array(avg_pop)
        mean_pop_25 = np.array(avg_pop_25)
        mean_pop_75 = np.array(avg_pop_75)

        x = np.arange(np.size(mean_pop, axis=1))

        plt.plot(x, np.mean(mean_pop_25, axis=0), label=thing)
        plt.plot(x, np.mean(mean_pop_75, axis=0), label=thing)
        plt.plot(x, np.mean(mean_pop, axis=0), label=thing)
    plt.title(testing + " " + transaction + " " + metric)
    plt.xlabel('Round')
    plt.ylabel(transaction + ' ' + metric)
    plt.legend()
    plt.show()


def pop_gen_graph(transaction, metric, num_gen, mode1, mode2, things, assassins=False, colors=None):
    plt.figure()
    for j in range(num_gen):
        mean_pop, mean_err_pop = [], []
        for thing in things:
            avg_pop = []
            for name0, name1 in zip(names0, names1):
                for i in range(num_games):
                    file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                    if assassins:
                        data = np.load(file_path + 'Ass' + name0 + thing + name1 + str(i) + "_" + transaction + "_" + metric + ".npy")
                    else:
                        data = np.load(file_path + 'Rnd' + name0 + thing + name1 + str(i) + "_" + transaction + "_" + metric + ".npy")
                    if assassins:
                        data = data[:, :-2]
                    if mode2 == 'mean':
                        avg_pop += [np.mean(data[-1])]
                    elif mode2 == 'gini':
                        avg_pop += [gini_coefficient(data.T)[-1]]
            mean_pop += [np.mean(np.array(avg_pop))]
            mean_err_pop += [np.std(np.array(avg_pop)) / np.sqrt(len(avg_pop))]

        x = np.arange(len(things)) * 10 + 10

        plt.errorbar(x, np.array(mean_pop), yerr=np.array(mean_err_pop), label=j, ecolor='k', color=colors[j])
    # plt.title('Convergence of Social Welfare')
    plt.xlabel('Generation of Genetic Algorithm')
    if mode2 == 'mean':
        plt.ylabel("Average Ending Popularities")
    elif mode2 == 'gini':
        plt.ylabel("Average Ending Gini Index")
        x1, x2, y1, y2 = plt.axis()
        plt.axis((x1, x2, 0, 1))
    plt.legend()
    plt.show()


def pop_init_graph(transaction, metric, num_gen, mode1, mode2, things, assassins=False, colors=None):
    plt.figure()
    barWidth = 0.45

    agents = ['CAB-1', 'CAB-3']

    for m in range(len(things)):
        mean_pop, mean_err_pop = [], []
        for n in range(len(game_type)):
            avg_pop = []
            # for name0, name1, name2 in zip(names0, names1, names2):
            for j in range(num_gen):
                for i in range(num_games):
                    file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                    # a_data = np.load(file_path + 'Ass' + name0 + things[m] + name1 + game_type[n] + name2 + str(
                    #     i) + "_" + transaction + "_" + metric + ".npy")
                    # a_data = a_data[:, :-2]
                    # avg_a_pop += [np.mean(a_data[-1])]
                    data = np.load(file_path + 'Rnd' + names0[0] + things[m] + names1[0] + game_type[n] + names2[0] + str(
                        i) + "_" + transaction + "_" + metric + ".npy")
                    if mode2 == 'mean':
                        avg_pop += [np.mean(data[-1])]
                    elif mode2 == 'gini':
                        avg_pop += [gini_coefficient(data.T)[-1]]

            mean_pop += [np.mean(np.array(avg_pop))]
            mean_err_pop += [np.std(np.array(avg_pop)) / np.sqrt(len(avg_pop))]
        x = np.arange(len(game_type))
        # print(game_type[m], things[n], mean_pop)
        plt.bar(x + barWidth * m, mean_pop, yerr=mean_err_pop, ecolor='k', capsize=3, width=barWidth, edgecolor='grey', label=agents[m], color=colors[m])
        # plt.bar(x + barWidth * n, mean_a_pop, width=barWidth, edgecolor='grey')

    # plt.title("Social Welfare with Training Conditions")
    plt.xticks([r + barWidth * .5 for r in range(len(game_type))],
               game_type)
    plt.xlabel('Game Type')
    if mode2 == 'mean':
        plt.ylabel("Average Ending Popularities")
    elif mode2 == 'gini':
        plt.ylabel("Average Ending Gini Index")
        x1, x2, y1, y2 = plt.axis()
        plt.axis((x1, x2, 0, 1))
    plt.legend()
    plt.show()


def get_per_of_survivors(data):
    survivors = 0
    for i in range(len(data)):
        if data[i] > 50:
            survivors += 1
    return survivors / len(data)


def pop_assassin_graph(transaction, metric, num_gen, mode1, mode2, things, assassins=False, colors=None):
    plt.figure()
    barWidth = 0.75

    for n in range(len(game_type)):
        mean_pop, mean_err_pop = [], []
        mean_survival_rate = []
        for m in range(len(things)):
            avg_pop = []
            # for name0, name1, name2 in zip(names0, names1, names2):
            survival_rate = []
            for j in range(num_gen):
                for i in range(num_games):
                    file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                    # a_data = np.load(file_path + 'Ass' + name0 + things[m] + name1 + game_type[n] + name2 + str(
                    #     i) + "_" + transaction + "_" + metric + ".npy")
                    # a_data = a_data[:, :-2]
                    # avg_a_pop += [np.mean(a_data[-1])]
                    data = np.load(file_path + 'Ass' + names0[0] + things[m] + names1[0] + game_type[n] + names2[0] + str(
                        i) + "_" + transaction + "_" + metric + ".npy")
                    data = data[-1, -2:]
                    if mode2 == 'mean':
                        avg_pop += [np.mean(data)]
                        survival_rate += [get_per_of_survivors(data)]

                    elif mode2 == 'gini':
                        avg_pop += [gini_coefficient(data.T)[-1]]

            mean_pop += [np.mean(np.array(avg_pop))]
            mean_err_pop += [np.std(np.array(avg_pop)) / np.sqrt(len(avg_pop))]
            mean_survival_rate += [np.mean(np.array(survival_rate))]
        x = np.arange(len(things))
        # print(game_type[m], things[n], mean_pop)
        plt.bar(x + barWidth * n, mean_pop, yerr=mean_err_pop, ecolor='k', capsize=3, width=barWidth, edgecolor='grey', label=game_type[n], color=colors[n])
        # plt.bar(x + barWidth * n, mean_a_pop, width=barWidth, edgecolor='grey')

    # plt.title("Social Welfare with Assassin Agents")
    plt.xticks([r for r in range(len(things))],
               things)
    plt.xlabel('Initial Conditions')
    if mode2 == 'mean':
        plt.ylabel("Average Ending Popularities")
    elif mode2 == 'gini':
        plt.ylabel("Average Ending Gini Index")
        x1, x2, y1, y2 = plt.axis()
        plt.axis((x1, x2, 0, 1))
    # plt.legend()
    plt.show()


def metric_graph(transaction, metric, num_gen, mode1, mode2, things):
    plt.figure()
    for thing in things:
        avg_pop = []
        for name0, name1 in zip(names0, names1):
            for j in range(num_gen):
                for i in range(num_games):
                    file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                    data = np.load(file_path + 'Rnd' + name0 + thing + name1 + str(i) + "_" + transaction + "_" + metric + ".npy")
                    avg_pop += [data]
        mean_pop = np.array(avg_pop)

        x = np.arange(np.size(mean_pop, axis=1))

        if mode1 == 'mean':
            plt.plot(x, np.mean(mean_pop, axis=0), label=thing)
        elif mode1 == 'var':
            plt.plot(x, np.var(mean_pop, axis=0), label=thing)
        elif mode1 == 'err':
            plt.plot(x, np.std(mean_pop, axis=0) / np.sqrt(num_games), label=thing)
        elif mode1 == 'quart':  # interquartile range
            plt.plot(x, np.percentile(mean_pop, 75, axis=0) - np.percentile(mean_pop, 25, axis=0), label=thing)
    plt.title(testing + " " + transaction + " " + metric)
    plt.xlabel('Round')
    plt.ylabel(transaction + ' ' + metric)
    plt.legend()
    plt.show()


def friendship_graph(transaction, metric, num_gen, mode1, mode2, things, colors=None):
    plt.figure()
    barWidth = 0.45

    agents = ['CAB-1', 'CAB-3']

    for n, thing in enumerate(['1_varied', '3_varied']):
        avg_metric = []
        for j in range(num_gen):
            for i in range(num_games):
                file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                data = np.load(file_path + 'Rnd' + names0[0] + thing + names1[0] + "equal" + names2[0] + str(i) + "_" + transaction + "_" + 'Reciprocity' + ".npy")

                avg_metric += [np.mean(data[10:21])]
        mean_rec = np.mean(avg_metric)
        mean_rec_err = np.std(np.array(avg_metric)) / np.sqrt(len(avg_metric))

        avg_metric = []
        for j in range(num_gen):
            for i in range(num_games):
                file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                data = np.load(file_path + 'Rnd' + names0[0] + thing + names1[0] + "equal" + names2[0] + str(i) + "_" + transaction + "_" + 'Clustering' + ".npy")
                avg_metric += [np.mean(data[10:21])]
        mean_clu = np.mean(avg_metric)
        mean_clu_err = np.std(np.array(avg_metric)) / np.sqrt(len(avg_metric))

        avg_metric = []
        for j in range(num_gen):
            for i in range(num_games):
                file_path = config.DATAPATH_SIMULATED + "networkAnalysis/" + str(j) + '/'
                data = np.load(file_path + 'Rnd' + names0[0] + thing + names1[0] + "equal" + names2[0] + str(i) + "_" + transaction + "_" + 'Signed Louvain Modularity Custom' + ".npy")
                avg_metric += [np.mean(data[10:21])]
        mean_mod = np.mean(avg_metric)
        mean_mod_err = np.std(np.array(avg_metric)) / np.sqrt(len(avg_metric))

        mean_metric = np.array([mean_rec, mean_clu, mean_mod])
        mean_metric_err = np.array([mean_rec_err, mean_clu_err, mean_mod_err])
        x = np.arange(np.size(mean_metric))
        plt.bar(x + barWidth * n, mean_metric, yerr=mean_metric_err, ecolor='k', capsize=3, width=barWidth,
                edgecolor='grey', label=agents[n], color=colors[n])

    plt.xticks([r + barWidth * .5 for r in range(3)],
               ['Reciprocity', 'Clustering', 'Modularity'])
    # plt.title('Mixing Patterns: Simulated Results')
    plt.xlabel('Metric')
    x1, x2, y1, y2 = plt.axis()
    plt.axis((x1, x2, 0, 1))
    plt.ylabel('Mean Value of Round 10-20')
    plt.legend()
    plt.show()


num_games = 50
num_rounds = 30

# gen = 50

# Generation Test:
# testing = 'gen'  # [gene_pools, type, gen, var]
# inits = ['3_varied']
# game_type = ['equal']
# generation = ['9', '19', '29', '39', '49', '59', '69', '79', '89', '99', '109', '119', '129', '139', '149', '159', '169', '179', '189', '199']
# varied = ['varied']
# pop_func = pop_gen_graph

# # Initial Conditions Test 1:
# testing = 'init'  # [type, gen, init]
# inits = ['1_varied', '3_varied']
# game_type = ['equal']
# generation = ['199']
# pop_func = pop_graph

# # Game Type Test:
# testing = 'type'  # [type, gen, init]
# inits = ['3_varied']
# game_type = ['equal', 'highlow', 'power', 'step', 'random']
# generation = ['199']
# pop_func = pop_graph

# Initial Conditions Test 1:
testing = 'init'  # [type, gen, init]
inits = ['3_varied']
game_type = ['equal']
generation = ['199']
# pop_func = pop_growth_graph


# Summery Metric: amount giving, stealing, keeping


num_gen = 6

names0 = []
names1 = []

for init in inits:
    for type in game_type:
        for gen in generation:
            if testing == 'init':
                things = inits
                names0 += ["Games_"]
                names1 += ["_" + gen + "_" + type + "/game_"]
            elif testing == 'gen':
                things = generation
                names0 += ["Games_" + init + "_"]
                names1 += ["_" + type + "/game_"]
            elif testing == 'type':
                things = game_type
                names0 += ["Games_" + init + "_" + gen + "_"]
                names1 += ["/game_"]


print('Transaction Metrics Available: ', ["Absolute Popularities"] + config.transaction_metrics)
print('Influence Metrics Available: ', config.influence_metrics)

# Social Standing - Social Welfare
# pop_func("Transaction", "Absolute Popularities", num_gen, 'mean', 'mean', things)
# pop_func("Transaction", "Absolute Popularities", num_gen, 'mean', 'gini', things)
# metric_graph("Transaction", "Degree", num_gen, 'mean', 'mean', things)
# metric_graph("Transaction", "Reciprocity", num_gen, 'mean', 'mean', things)
# metric_graph("Transaction", "Clustering", num_gen, 'mean', 'mean', things)
# metric_graph("Transaction", "Signed Louvain Modularity Custom", num_gen, 'mean', 'mean', things)

# # Mixing Patterns
# metric_graph("Transaction", "Reciprocity", num_gen, 'mean', 'mean', things)
# metric_graph("Transaction", "Clustering", num_gen, 'mean', 'mean', things)
# metric_graph("Transaction", "Signed Louvain Modularity Custom", num_gen, 'mean', 'mean', things)
# metric_graph("Transaction", "Popularity Assortativity", num_gen, 'mean', 'mean', things)
#
# # # Persistence
# metric_graph("Transaction", "Modularity Persistence", num_gen, 'mean', 'mean', things)
# pop_func("Transaction", "Absolute Popularities", num_gen, 'mean', 'mean', things, True)
# pop_func("Transaction", "Absolute Popularities", num_gen, 'mean', 'gini', things, True)




bot_color = '#F47C6F'



# Generation Test:
testing = 'gen'  # [gene_pools, type, gen, var]
inits = ['3_varied']
game_type = ['equal']
generation = ['9', '19', '29', '39', '49', '59', '69', '79', '89', '99', '109', '119', '129', '139', '149', '159', '169', '179', '189', '199']
varied = ['varied']
pop_func = pop_gen_graph

num_gen = 6

names0 = []
names1 = []

for init in inits:
    for type in game_type:
        for gen in generation:
            if testing == 'init':
                things = inits
                names0 += ["Games_"]
                names1 += ["_" + gen + "_" + type + "/game_"]
            elif testing == 'gen':
                things = generation
                names0 += ["Games_" + init + "_"]
                names1 += ["_" + type + "/game_"]
            elif testing == 'type':
                things = game_type
                names0 += ["Games_" + init + "_" + gen + "_"]
                names1 += ["/game_"]


# Social Standing - Social Welfare
generation_colors = ['#70AE98', '#E6B655', '#5D96AE', '#AF6E4E', bot_color, '#6FFF6F']
# pop_gen_graph("Transaction", "Absolute Popularities", num_gen, 'mean', 'mean', things, colors=generation_colors)
# pop_gen_graph("Transaction", "Absolute Popularities", num_gen, 'mean', 'gini', things, colors=generation_colors)



# Initial Conditions Test 1:
testing = 'init'  # [type, gen, init]
inits = ['1_varied', '3_varied']
game_type = ['equal', 'highlow', 'step', 'power', 'random']
generation = ['199']
pop_func = pop_graph

num_gen = 6

names0 = []
names1 = []
names2 = []

for init in inits:
    for type in game_type:
        for gen in generation:
            if testing == 'init':
                things = inits
                names0 += ["Games_"]
                names1 += ["_" + gen + "_"]
                names2 += ["/game_"]


# Social Standing - Social Welfare
# bot_colors = [bot_color, '#70AE98', '#E6B655', '#5D96AE','#AF6E4E']
bot_colors = ['#E6B655', bot_color]
pop_init_graph("Transaction", "Absolute Popularities", num_gen, 'mean', 'mean', things, colors=bot_colors)
pop_init_graph("Transaction", "Absolute Popularities", num_gen, 'mean', 'gini', things, colors=bot_colors)


def mixed_pop_init_graph(transaction, metric, num_gen, mode1, mode2, things, assassins=False, colors=None):
    plt.figure()
    barWidth = 0.45

    game_type = ['equal', 'highlow', 'power', 'step', 'random']
    agents = ['CAB-1', 'CAB-3']

    for m in range(len(agents)):
        mean_pop, mean_err_pop = [], []
        for n in range(len(game_type)):

            avg_pop = []
            # for name0, name1, name2 in zip(names0, names1, names2):
            for i in range(num_games):
                file_path = config.DATAPATH_SIMULATED + 'networkAnalysis/0/BestBots/'
                # a_data = np.load(file_path + 'Ass' + name0 + things[m] + name1 + game_type[n] + name2 + str(
                #     i) + "_" + transaction + "_" + metric + ".npy")
                # a_data = a_data[:, :-2]
                # avg_a_pop += [np.mean(a_data[-1])]
                data = np.load(file_path + game_type[n] + '/game_' + str(i) + "_" + transaction + "_" + metric + ".npy")

                avg_pop += [np.mean(data[-1][m*5:(m+1)*5])]

            mean_pop += [np.mean(np.array(avg_pop))]
            mean_err_pop += [np.std(np.array(avg_pop)) / np.sqrt(len(avg_pop))]
        x = np.arange(len(game_type))
        # print(game_type[m], things[n], mean_pop)
        plt.bar(x + barWidth * m, mean_pop, yerr=mean_err_pop, ecolor='k', capsize=3, width=barWidth, edgecolor='grey', label=agents[m], color=colors[m])
        # plt.bar(x + barWidth * n, mean_a_pop, width=barWidth, edgecolor='grey')

    # plt.title("Social Welfare with Training Conditions")
    plt.xticks([r + barWidth * .5 for r in range(len(game_type))],
               game_type)
    plt.xlabel('Game Type')
    if mode2 == 'mean':
        plt.ylabel("Average Ending Popularities")
    elif mode2 == 'gini':
        plt.ylabel("Average Ending Gini Index")
        x1, x2, y1, y2 = plt.axis()
        plt.axis((x1, x2, 0, 1))
    plt.legend()
    plt.show()


mixed_pop_init_graph("Transaction", "Absolute Popularities", 1, 'mean', 'mean', things, colors=bot_colors)


# bot_colors = ['#70AE98', '#E6B655', '#5D96AE', bot_color]
friendship_graph("Transaction", "Reciprocity", num_gen, 'mean', 'mean', things, colors=bot_colors)

game_type = ['equal']
# pop_assassin_graph("Transaction", "Absolute Popularities", num_gen, 'mean', 'mean', things, colors=[bot_color])
# pop_assassin_graph("Transaction", "Absolute Popularities", num_gen, 'mean', 'gini', things, colors=[bot_color])


# # # Game Type Test:
# testing = 'type'  # [type, gen, init]
# inits = ['3_varied']
# game_type = ['equal', 'highlow', 'power', 'step', 'random']
# generation = ['199']
# pop_func = pop_graph



