from typing import List, Dict
import numpy as np

MAX_PLAYERS = 20

class GroupPrefs:

    def __init__(self, i, j, numPlayers, G, mag):
        self.G = np.array(G)

        self.i = i
        self.j = j
        self.numPlayers = numPlayers
        self.mag = mag
        self.total = 0.0
        self.samesame = 0.0
        self.polarization = 0.0
        self.groupWeight_i  = 0.0
        self.groupWeight_j = 0.0
        self.groupWeight_neutral = 0.0
        self.minWeightScale = 0.0

        self.for_i = set()
        self.for_j = set()
        self.neutral = set()
        # double G[MAX_PLAYERS][MAX_PLAYERS], polarization;

        self.getPrefs()


    def getPrefs(self):
        for k in range(self.numPlayers):
            if k == self.i:
                self.for_i.add(k)
            elif k == self.j:
                self.for_j.add(k)
            else:
                threshold = 0.04 * self.mag[k]
                if self.G[self.i][k] > (self.G[self.j][k] + threshold):
                    self.for_i.add(k)
                elif self.G[self.j][k] > (self.G[self.i][k] + threshold):
                    self.for_j.add(k)
                else:
                    self.neutral.add(k)

    
    def compare(self, other, i, j, w):
        # print("\t****************", other.to_string())
        totalEste = 0
        samesameEste = 0.0
        for player in self.for_i:
            totalEste += w[player]
            if i < j:
                if player in other.for_i:
                    samesameEste += 1.0 * w[player]
                elif player in other.neutral:
                    samesameEste += 0.5 * w[player]
            else:
                if player in other.for_j:
                    samesameEste += 1.0 * w[player]
                elif player in other.neutral:
                    samesameEste += 0.5 * w[player]

        for player in self.for_j:
            totalEste += w[player]
            if i < j:
                if player in other.for_j:
                    samesameEste += 1.0 * w[player]
                elif player in other.neutral:
                    samesameEste += 0.5 * w[player]
            else:
                if player in other.for_i:
                    samesameEste += 1.0 * w[player]
                elif player in other.neutral:
                    samesameEste += 0.5 * w[player]

        for player in self.neutral:
            totalEste += w[player]

        # print("    " + str(i) + "," + str(j) + ": " + str(samesameEste) + " / " + str(totalEste))

        self.total += totalEste
        self.samesame += samesameEste

        # print("    " + str(i) + "," + str(j) + ": " + str(self.samesame) + " / " + str(self.total))

        self.polarization = (((self.samesame * self.minWeightScale) / self.total) - 0.5) / 0.5

        # print("\t", self.minWeightScale)
        # print("\t", self.polarization)


    def computeWeights(self, w):
        for player in self.for_i:
            self.groupWeight_i += w[player]
        for player in self.for_j:
            self.groupWeight_j += w[player]
        for player in self.neutral:
            self.groupWeight_neutral += w[player]

        minWeight = self.groupWeight_i
        if self.groupWeight_j < self.groupWeight_i:
            minWeight = self.groupWeight_j
        if minWeight < 0.2:
            self.minWeightScale = minWeight / 0.2
        else:
            self.minWeightScale = 1.0


    def to_string(self):
        s = "for_" + str(self.i) + ": "
        for player in self.for_i:
            s += str(player) + ", "
        s += " (" + str(self.groupWeight_i) + "); for_" + str(self.j) + ": "
        for player in self.for_j:
            s += str(player) + ", "
        s += " (" + str(self.groupWeight_j) + "); neutral: "
        for player in self.neutral:
            s += str(player) + ", "
        s += " (" + str(self.groupWeight_neutral) + ") -> " + str(self.polarization) + "\n"
        return s


class EconAction:
    def __init__(self):
        self.giveCount = 0
        self.takeCount = 0
        self.keepCount = 0
        self.givePerc = None
        self.takePerc = None
        self.keepPerc = None



class RoundInfo:
    def __init__(self):
        self.numPlayers = 0
        self.round = 0
        self.alpha, self.beta, self.give, self.keep, self.steal = 0.0, 0.0, 0.0, 0.0, 0.0
        self.popularities = np.zeros(MAX_PLAYERS)
        self.transactions = np.zeros([MAX_PLAYERS, MAX_PLAYERS])
        self.influences = np.zeros([MAX_PLAYERS, MAX_PLAYERS])
        # self.playerTypes = np.zeros(MAX_PLAYERS, dtype=object)


def parse(s: str) -> list[str]:
    return s.split(',')


def readRound(line, numPlayers, flip):
    rnd = RoundInfo()
    words = parse(line)

    rnd.numPlayers = numPlayers
    rnd.round = int(words[0])
    rnd.alpha = float(words[1])
    rnd.beta = float(words[2])
    rnd.give = float(words[3])
    rnd.keep = float(words[4])
    rnd.steal = float(words[5])

    rnd.popularities = np.zeros(numPlayers)
    for i in range(numPlayers):
        rnd.popularities[i] = float(words[i+6])

    rnd.transactions = np.zeros([numPlayers, numPlayers])
    ind = 6 + numPlayers
    for i in range(numPlayers):
        for j in range(numPlayers):
            rnd.transactions[i][j] = float(words[ind])
            ind += 1

    rnd.influences = np.zeros([numPlayers, numPlayers])
    for i in range(numPlayers):
        for j in range(numPlayers):
            if not flip:
                rnd.influences[i][j] = float(words[ind])
            else:
                rnd.influences[j][i] = float(words[ind])
            ind += 1

    # bring this back in if it is for the human-bot studies todo: figure out what to do with this
    # for (int i = 0; i < numPlayers; i++) {
    #     rnd.playerTypes[i] = words[ind];
    #     ind ++;
    # }

    return rnd

def getNumPlayers(line):
    words = parse(line)
    i = 6
    while words[i][0] == 'p':
        i += 1

    return i - 6

def readGame(fnombre, flip):
    print(fnombre)
    try:
        with open(fnombre, 'r') as input_file:
            lines = input_file.readlines()
    except FileNotFoundError:
        print(f"Could not read file {fnombre}")
        exit(-1)

    if not lines:
        return []

    v = []
    numPlayers = getNumPlayers(lines[0])  # Read header to get number of players

    for line in lines[1:]:  # Skip header
        if len(line.strip()) > 2:  # Check if the line is not empty
            v.append(readRound(line.strip(), numPlayers, flip))

    return v

def getAveReciprocity(esto):
    numEdges = 0
    both = 0

    for r in range(1, len(esto)):
        for i in range(esto[0].numPlayers):
            for j in range(i, esto[0].numPlayers):
                if (i == j):
                    continue
                if esto[r].transactions[j][i] > 0 and esto[r].transactions[i][j] > 0:
                    both += 1
                if esto[r].transactions[i][j] > 0:
                    numEdges += 1
                if esto[r].transactions[j][i] > 0:
                    numEdges += 1

    # cout << "numEdges: " << numEdges << endl;
    # cout << "numReciprocations: " << both << endl;

    return (2.0 * both) / numEdges


def getAveDegree(esto):
    if len(esto) < 2:
        return 0.0  # Avoid division by zero

    overallAverage = 0.0
    for r in range(1, len(esto)):
        aveDegree = 0.0
        for i in range(esto[0].numPlayers):
            numConnections = 0
            for j in range(esto[0].numPlayers):
                # cout << (int)(esto[r].transactions[i][j]*numTokens) << ", ";
                if i == j:
                    continue
                if esto[r].transactions[i][j] > 0 and esto[r].transactions[j][i] > 0:
                    numConnections += 1
            aveDegree += numConnections / float(esto[0].numPlayers-1)
        aveDegree /= esto[0].numPlayers
        # cout << "Degree in round " << r << " is " << aveDegree << endl;
        overallAverage += aveDegree

    return overallAverage / (len(esto)-1)


def getEconomicActionPercentages(esto):
    econ = EconAction()
    numTokens = 2 * esto[0].numPlayers
    for r in range(1, len(esto)):
        for i in range(esto[0].numPlayers):
            for j in range(esto[0].numPlayers):
                if i == j:
                    econ.keepCount += int(esto[r].transactions[i][j] * numTokens)
                elif esto[r].transactions[i][j] > 0:
                    econ.giveCount += int(esto[r].transactions[i][j] * numTokens)
                else:
                    econ.takeCount -= int(esto[r].transactions[i][j] * numTokens)

    total = econ.takeCount + econ.keepCount + econ.giveCount
    econ.takePerc = econ.takeCount / float(total)
    econ.keepPerc = econ.keepCount / float(total)
    econ.givePerc = econ.giveCount / float(total)

    return econ


def getClusterCoef(esto):
    numPlayers = esto[0].numPlayers

    # create the friend graph
    amigos = np.zeros([numPlayers, numPlayers])

    numPossible = 0
    numFound = 0
    for r in range(len(esto)):
        # # get the amigo graph
        nuevoPossible = 0
        nuevoFound = 0
        for i in range(numPlayers):
            for j in range(numPlayers):
                if esto[r].transactions[i][j] > 0 and i != j:
                    for k in range(numPlayers):
                        if j == k or i == k:
                            continue
                        if esto[r].transactions[i][k] > 0:
                            nuevoPossible += 1
                            if esto[r].transactions[j][k]:
                                nuevoFound += 1

        # print(nuevoFound / float(nuevoPossible))
        # cout << "nuevoPossibe after " << r << ": " << nuevoPossible << endl;

        numFound += nuevoFound
        numPossible += nuevoPossible

        # cout << "T:" << endl;
        # for (int i = 0; i < numPlayers; i++) {
        #     for (int j = 0; j < numPlayers; j++) {
        #         cout << (int)(esto[r].transactions[i][j]*2*numPlayers) << ", ";
        #     }
        #     cout << endl;
        # }

        # cout << endl << "Amigos: " << endl;
        # for (int i = 0; i < numPlayers; i++) {
        #     for (int j = 0; j < numPlayers; j++) {
        #         cout << amigos[i][j] << ", ";
        #     }
        #     cout << endl;
        # }


        # see how many of my friends are connected to each other

        # for (int i = 0; i < numPlayers; i++) {
        #     for (int j = 0; j < numPlayers; j++) {
        #         if (amigos[i][j] == 1) {
        #             for (int k = j+1; k < numPlayers; k++) {
        #                 if (amigos[i][k] == 1) {
        #                     numPossible ++;
        #                     if (amigos[j][k] == 1)
        #                         numFound ++;
        #                 }
        #             }
        #         }
        #     }
        # }

    print("numFound: ", numFound)
    print("numPossible: ", numPossible)

    return numFound / float(numPossible)


def computePolarization(theRound):
    # print(theRound.transactions)
    mag = []
    weights1, weights2 = [], []
    totalWeight = 0.0

    for k in range(theRound.numPlayers):
        s = 0.0
        for m in range(theRound.numPlayers):
            s += np.abs(theRound.influences[m][k])
        mag += [s]
        totalWeight += s

    # cout << "totalWeight: " << totalWeight << " -> ";
    for k in range(theRound.numPlayers):
        weights1 += [1.0]
        weights2 += [mag[k] / totalWeight]
        # cout << weights2[k] << ", ";
    # cout << endl;

    # map<int, GroupPrefs *> groupings;
    groupings = {}
    for i in range(theRound.numPlayers):
        for j in range(i + 1, theRound.numPlayers):
            # determine sets specifying preferences for i or j (indifferent, for_i, for_j)
            group = GroupPrefs(i, j, theRound.numPlayers, theRound.influences, mag)
            group.computeWeights(weights2)
            index = i * theRound.numPlayers + j
            # cout << index << endl;
            groupings[index] = group

    # cout << "now compute polarization" << endl;

    maxPolarization = 0.0
    for i in range(theRound.numPlayers):
        for j in range(i + 1, theRound.numPlayers):
            indexOrig = i * theRound.numPlayers + j
            # print(groupings[indexOrig].to_string())

            # compute polarization here
            for player_i in groupings[indexOrig].for_i:
                for player_j in groupings[indexOrig].for_j:
                    # index = np.min([player_i, player_j]) * theRound.numPlayers + np.max([player_i, player_j])
                    if player_i > player_j:
                        index = player_j * theRound.numPlayers + player_i
                    else:
                        index = player_i * theRound.numPlayers + player_j
                    # cout << *itr_i << " and " << *itr_j << " compare: " << index << endl;
                    groupings[indexOrig].compare(groupings[index], player_i, player_j, weights1)

            # print(groupings[indexOrig].to_string())
            # if (((groupings[indexOrig]->for_i.size() + groupings[indexOrig]->for_j.size()) > numPlayers * 0.7) &&
            # (groupings[indexOrig]->for_i.size() > 1) && (groupings[indexOrig]->for_j.size() > 1)) {
            # if ((groupings[indexOrig]->groupWeight_i > 0.2) && (groupings[indexOrig]->groupWeight_j > 0.2)) {
            if groupings[indexOrig].polarization > maxPolarization:
                maxPolarization = groupings[indexOrig].polarization
            # }

    # print("Polarization: ", maxPolarization)
    return maxPolarization


def getPolarizationCoef(esto):
    polarizationCoef = 0.0
    for r in range(1, len(esto)):
        polarizationCoef += computePolarization(esto[r])

    return polarizationCoef / len(esto)


def main():

    testing_set_dir = "/home/watchtower/Datasets/JuniorHighNetwork/BehaviorStudy/JHG_DataSets/study_games/testing_set_experienced/"
    # vector<RoundInfo> esto = readGame("../Results/theGameLogs/log_1000_1000.csv", false);

    # Human test set (experienced)
    estos = []
    print("game:")
    estos += [readGame(testing_set_dir + "jhg_NZKH.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_SNCR.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_ZQXV.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_TDRP.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_MCQF.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_LWRB.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_WTMR.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_CHLN.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_RWFL.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_KRJP.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_BKFV.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_MQCK.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_VWJH.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_NMDQ.csv", True)]
    estos += [readGame(testing_set_dir + "jhg_DWMG.csv", True)]

    # Human training set (experienced)
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BPMQ.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BQKP.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_BZQK.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_CXJR.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_CZWN.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DKRV.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DNQX.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DTHW.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_DZJR.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_FVSP.csv", true);

    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GCLQ.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GHBK.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GJDV.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GJFD.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GSCW.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GSDH.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_GXVS.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_HLCK.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_HNCQ.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KBRW.csv", true);

    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KCSF.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KWMG.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_KXRJ.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_LZFC.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MCDL.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MCZG.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MDJS.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_MXGN.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_NRFS.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_NTLM.csv", true);

    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_QLHS.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_RPLW.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_RSGK.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_SHFC.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_SMBD.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TDGM.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TKRW.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_TSJW.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VBLN.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VCNK.csv", true);

    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VSJQ.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_VSKR.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WBHQ.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WCJQ.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WQDS.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_WQJR.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XQRT.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XTWS.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_XWHK.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_ZRHK.csv", true);
    # vector<RoundInfo> esto = readGame("../TheHumanData/training_set_experienced/jhg_ZSLG.csv", true);


    # cout << esto.size() << endl;

    # double degree = getAveDegree(esto);
    # cout << "Average degree was " << degree << endl;

    # EconAction econ = getEconomicActionPercentages(esto);

    # cout << "Percent keep: " << (econ.keepPerc * 100.0) << endl;
    # cout << "Percent take: " << (econ.takePerc * 100.0) << endl;
    # cout << "Percent give: " << (econ.givePerc * 100.0) << endl;

    # double recip = getAveReciprocity(esto);

    # cout << "Reciprocity: " << recip << endl;

    # double clusterCoef = getClusterCoef(esto);

    # cout << "clusterCoef: " << clusterCoef << endl;

    polarizationCoefs = []
    games = ["jhg_NZKH.csv", "jhg_SNCR.csv", "jhg_ZQXV.csv", "jhg_TDRP.csv", "jhg_MCQF.csv",
             "jhg_LWRB.csv", "jhg_WTMR.csv", "jhg_CHLN.csv", "jhg_RWFL.csv", "jhg_KRJP.csv",
             "jhg_BKFV.csv", "jhg_MQCK.csv", "jhg_VWJH.csv", "jhg_NMDQ.csv", "jhg_DWMG.csv"]

    for game, esto in zip(games, estos):
        print("\ngame: " + game)
        pc = getPolarizationCoef(esto)
        print("polarizationCoefs: " + str(pc))
        polarizationCoefs += [pc]

    print("Average polarizationCoef: ", np.mean(polarizationCoefs))
    print("Std Dev polarizationCoef: ", np.std(polarizationCoefs))
    print("Std Err polarizationCoef: ", np.std(polarizationCoefs, ddof=1) / np.sqrt(len(polarizationCoefs)))

    return 0


if __name__ == "__main__":
    main()

