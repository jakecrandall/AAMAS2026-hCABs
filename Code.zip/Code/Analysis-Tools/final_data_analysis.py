from tkinter.ttk import Label

from networkx.algorithms.bipartite.cluster import average_clustering
from numpy.f2py.auxfuncs import throw_error

from configuration import DATAPATH
from data_analysis2 import *


plt.rcParams['font.size'] = 18  # applies to all default text
# plt.rcParams['axes.titlesize'] = 18      # Title
plt.rcParams['axes.labelsize'] = 18      # X and Y labels
plt.rcParams['xtick.labelsize'] = 18     # X tick labels
plt.rcParams['ytick.labelsize'] = 18     # Y tick labels
plt.rcParams['legend.fontsize'] = 18     # Legend
# plt.rcParams['figure.titlesize'] = 20    # Figure title (suptitle)
label_fontsize = 18

#############################################################################
'''This section loads all of the file handlers'''
#############################################################################

# all_humans_file_handler = FileHandler('all_humans', False, [0, 0, 0, 0, 8], 'all\nhumans')
training_humans_file_handler = FileHandler('training_set_experienced', False, [0, 0, 0, 0, 8], 'training\nhumans', color='k')
testing_humans_file_handler = FileHandler('testing_set_experienced', False, [0, 0, 0, 0, 8], 'Humans', color='#1f77b4')


user_study_file_handler = FileHandler('hCABs', False, [0, 0, 0, 0, 8], 'UserStudy', color='k')


random_file_handler = FileHandler('29-random_agents', True, [0, 0, 8, 0, 0], 'Random', color='#2ca02c')
ecab_cab_file_handler = FileHandler('29-ecab', True, [8, 0, 0, 0, 0], 'eCAB', color='#ff00ff')

tft1_mean_file_handler = FileHandler('29-tit_for_tat_1/hcab_mean_human_all', True, [0, 0, 8, 0, 0], 'hTFT-PSO-MSE', color='#5c4033')
tft1_property_file_handler = FileHandler('29-tit_for_tat_1/hcab_property_human_all', True, [0, 0, 8, 0, 0], 'hTFT-PSO', color='#5c4033')

gen_pop_tft_mean_file_handler = FileHandler('29-genetic_tit_for_tat/hcab_mean_human_all', True, [0, 0, 8, 0, 0], 'hTFT-EPDM-MSE', color='#c49c94')
gen_pop_tft_property_file_handler = FileHandler('29-genetic_tit_for_tat/hcab_property_human_all', True, [0, 0, 8, 0, 0], 'hTFT-EPDM', color='#c49c94')

society1_mean_file_handler = FileHandler('29-society_1/hcab_mean_human_all', True, [0, 8, 0, 0, 0], 'hCAB-PSO-MSE', color='#d62728')
society1_property_file_handler = FileHandler('29-society_1/hcab_property_human_all', True, [0, 8, 0, 0, 0], 'hCAB-PSO', color='#d62728')

gen_pop_sum_mean_file_handler = FileHandler('29-genetic_population_summarization/hcab_mean_human_all', True, [0, 8, 0, 0, 0], 'hCAB-EPDM-MSE', color='#ff7f0e')
gen_pop_sum_property_file_handler = FileHandler('29-genetic_population_summarization/hcab_property_human_all', True, [0, 8, 0, 0, 0], 'hCAB-EPDM', color='#ff7f0e')



# onefile_file_handler = FileHandler('28-testing', True, [0, 8, 0, 0, 0], 'onefile')


mean = 'mean'

def plot_all_charts(fileHandlers, plot=display_graph, experiment_name='default'):
    giving, keeping, taking = [], [], []

    metric = "Popularity Centrality"
    for fileHandler in fileHandlers:
        metric_list = mean_popularity_over_time(fileHandler)
        std_error = compute_sem(metric_list)
        # plot_line_graph(mean_popularity_over_time(fileHandler), label_name=fileHandler.label_name.replace('\n',' '))
        plot_bar_graph(np.mean(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title=metric, filename=metric + ' ' + experiment_name + ' ' + mean)

    metric = "Gini Index"
    for fileHandler in fileHandlers:
        metric_list = gini_index_over_time(fileHandler)
        std_error = compute_sem(metric_list)
        # plot_line_graph(gini_index_over_time(fileHandler), label_name=fileHandler.label_name.replace('\n',' '))
        plot_bar_graph(np.mean(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title=metric, filename=metric + ' ' + experiment_name + ' ' + mean)

    metric = 'Degree'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data(fileHandler, graph="Transaction", metric=metric)
        std_error = compute_sem(metric_list)
        print(compute_confidence_interval(metric_list))
        # average_degree += [np.average(metric_list)]
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
        # plot_line_graph(combined_metric_data(fileHandler, graph="Transaction", metric=metric), label_name=fileHandler.label_name)
    plot(title="Degree of Agents in Self-Play", xlabel='', ylabel='average degree', ylim=None, filename=metric + ' ' + experiment_name + ' ' + mean)

    metric = 'In-Degree'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data(fileHandler, graph="Transaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
        # plot_line_graph(combined_metric_data(fileHandler, graph="Transaction", metric=metric), label_name=fileHandler.label_name)
    plot(title="In-Degree of Agents in Self-Play", xlabel='', ylabel='average in-degree', ylim=None, filename=metric + ' ' + experiment_name + ' ' + mean)

    metric = 'Out-Degree'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data(fileHandler, graph="Transaction", metric=metric)
        std_error = compute_sem(metric_list)
        # average_degree += [np.average(metric_list)]
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
        # plot_line_graph(combined_metric_data(fileHandler, graph="Transaction", metric=metric), label_name=fileHandler.label_name)
    plot(title="Out-Degree of Agents in Self-Play", xlabel='', ylabel='average out-degree', ylim=None, filename=metric + ' ' + experiment_name + ' ' + mean)

    # metric = 'Popularity Assortativity'
    # for fileHandler in fileHandlers:
    #     metric_list = combined_metric_data(fileHandler, graph="Transaction", metric=metric)
    #     std_error = compute_sem(metric_list)
    #     # average_degree += [np.average(metric_list)]
    #     plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    #     # plot_line_graph(combined_metric_data(fileHandler, graph="Transaction", metric=metric), label_name=fileHandler.label_name)
    # plot(title="Popularity Assortativity of Agents in Self-Play", xlabel='', ylabel='average popularity assortativity', ylim=None,
    #      filename=metric + ' ' + experiment_name + ' ' + mean)

    metric = 'Reciprocity'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data(fileHandler, graph="Transaction", metric=metric)
        std_error = compute_sem(metric_list)
        # average_reciprocity += [np.average(metric_list)]
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Reciprocity of Agents in Self-Play", xlabel='', ylabel='average reciprocity', ylim=None, filename=metric + ' ' + experiment_name + ' ' + mean)

    metric = 'Reciprocity'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Reciprocity of Agents in Self-Play", xlabel='', ylabel='average reciprocity', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Reciprocity2'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Reciprocity of Agents in Self-Play", xlabel='', ylabel='average reciprocity', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Transitivity'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data(fileHandler, graph="Transaction", metric=metric)
        std_error = compute_sem(metric_list)
        # average_clustering += [np.average(metric_list)]
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Clustering of Agents in Self-Play", xlabel='', ylabel='average clustering coefficient', ylim=None, filename=metric + ' ' + experiment_name + ' ' + mean)

    metric = 'Transitivity'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        # average_clustering += [np.average(metric_list)]
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Clustering of Agents in Self-Play", xlabel='', ylabel='average clustering coefficient', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Clustering'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Clustering of Agents in Self-Play", xlabel='', ylabel='average clustering', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Density'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data(fileHandler, graph="Transaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Density of Agents in Self-Play", xlabel='', ylabel='average density coefficient', ylim=None,
         filename=metric + ' ' + experiment_name + ' ' + mean)

    # metric = 'Polarization'
    # for fileHandler in fileHandlers:
    #     metric_list = combined_metric_data(fileHandler, graph="Influence", metric=metric)
    #     std_error = compute_sem(metric_list)
    #     # plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    #     plot_line_graph(metric_list, label_name=fileHandler.label_name.replace('\n',' '))
    # plot(title="Polarization of Agents in Self-Play", xlabel='', ylabel='polarization coefficient', ylim=None,
    #      filename=metric + ' ' + experiment_name + ' ' + mean)

    metric = 'Density'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Density of Agents in Self-Play", xlabel='', ylabel='average density', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Entropy Short Term'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Short Term Entropy of Agents in Self-Play", xlabel='', ylabel='average entropy', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Entropy'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Entropy of Agents in Self-Play", xlabel='', ylabel='average entropy', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Evolution Coefficient1'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Evolution Coefficient of Agents in Self-Play", xlabel='', ylabel='average evolution coefficient', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Evolution Coefficient2'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Evolution Coefficient of Agents in Self-Play", xlabel='', ylabel='average evolution coefficient', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    metric = 'Reciprocations Coefficient'
    for fileHandler in fileHandlers:
        metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
        std_error = compute_sem(metric_list)
        plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    plot(title="Reciprocations Coefficient of Agents in Self-Play", xlabel='', ylabel='average reciprocations coefficient', ylim=None,
         filename=metric + 'Summary ' + experiment_name + ' ' + mean)

    for fileHandler in fileHandlers:
        g = economic_actions_data(fileHandler, graph="Transaction", metric='Giving')
        g_error = compute_sem(g)
        k = economic_actions_data(fileHandler, graph="Transaction", metric='Keeping')
        k_error = compute_sem(k)
        t = economic_actions_data(fileHandler, graph="Transaction", metric='Taking')
        t_error = compute_sem(t)
        giving += [np.average(g)]
        keeping += [np.average(k)]
        taking += [np.average(t)]
        print("values:", giving[-1], keeping[-1], taking[-1])
        print("errors:", g_error, k_error, t_error)
        print()

        plot_bar_graph(giving[-1], std_error=g_error, color='g', show_numbers=True)
        plot_bar_graph(keeping[-1], std_error=k_error, label_name=fileHandler.label_name, color='b', show_numbers=True)
        plot_bar_graph(taking[-1], std_error=t_error, color='r', show_numbers=True)
    plot(title='Economic Actions', xlabel='', filename='Economic Actions' + ' ' + experiment_name + ' ' + mean)

    # plot(title="Summary Value", xlabel='', ylabel='summary value', ylim=None, filename='Summary Value ' + experiment_name)
    # print()

def compute_average_metric_for_games(fileHandler, round_lengths, graph='Transaction', metric='Absolute Popularities'):
    filelist = fileHandler.get_graph_metric_file_list(graph, metric)
    average_metric_for_games = []
    for i, file in enumerate(filelist):
        if graph == 'Transaction':
            data, _ = load_data(file)
            data = data[:round_lengths[i]]
        elif graph == 'Influence':
            data, _ = load_data(file)
            data = data[:round_lengths[i]]
        elif graph == 'SummaryTransaction':
            data = np.load(file, allow_pickle=True)
        else:
            raise Exception('Graph must be Transaction, Influence or Summary')
        average_metric_for_games += [np.average(data)]
    return average_metric_for_games


def compute_average_gini_index_for_games(fileHandler, round_lengths, graph='Transaction', metric='Absolute Popularities'):
    def calculate_gini(array):
        """Helper function to calculate the Gini index of a 1D array."""
        array = np.sort(array)  # Sort the array for Gini calculation
        n = len(array)
        index = np.arange(1, n + 1)  # Indexes from 1 to n
        return (2 * np.sum(index * array) / np.sum(array) - (n + 1)) / n
    filelist = fileHandler.get_graph_metric_file_list(graph, metric)
    average_metric_for_games = []
    for i, file in enumerate(filelist):
        data, _ = load_data(file)  # Load data for all rounds up to LAST_ROUND
        data = data[:round_lengths[i]]
        data = [np.nan_to_num(calculate_gini(pop)) for pop in data]  # Calculate Gini index for each round
        data = data[:round_lengths[i]]
        average_metric_for_games += [np.average(data)]
    return average_metric_for_games


def summary_metric(botFileHandler, humanFileHandler):
    round_lengths = get_round_lengths(humanFileHandler)
    round_lengths = round_lengths + round_lengths + round_lengths + round_lengths + round_lengths + round_lengths + round_lengths + round_lengths

    h_givings = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="Transaction", metric='Giving')
    h_keepings = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="Transaction", metric='Keeping')
    h_takings = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="Transaction", metric='Taking')
    h_popularities = compute_average_metric_for_games(humanFileHandler, round_lengths)
    h_gini_indexes = compute_average_gini_index_for_games(humanFileHandler, round_lengths)
    h_average_degrees = compute_average_metric_for_games(humanFileHandler, round_lengths, metric='Density')
    h_average_entropy = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="SummaryTransaction", metric='Entropy Short Term')
    h_average_reciprocities = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="SummaryTransaction", metric='Reciprocity')
    h_average_reciprocities2 = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="SummaryTransaction", metric='Reciprocity2')
    h_average_polarization = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="Influence", metric='Polarization')
    h_evolution1 = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="SummaryTransaction", metric='Evolution Coefficient1')
    h_evolution2 = compute_average_metric_for_games(humanFileHandler, round_lengths, graph="SummaryTransaction", metric='Evolution Coefficient2')

    b_givings = compute_average_metric_for_games(botFileHandler, round_lengths, graph="Transaction", metric='Giving')
    b_keepings = compute_average_metric_for_games(botFileHandler, round_lengths, graph="Transaction", metric='Keeping')
    b_takings = compute_average_metric_for_games(botFileHandler, round_lengths, graph="Transaction", metric='Taking')
    b_popularities = compute_average_metric_for_games(botFileHandler, round_lengths)
    b_gini_indexes = compute_average_gini_index_for_games(botFileHandler, round_lengths)
    b_average_degrees = compute_average_metric_for_games(botFileHandler, round_lengths, metric='Density')
    b_average_entropy = compute_average_metric_for_games(botFileHandler, round_lengths, graph="SummaryTransaction", metric='Entropy Short Term')
    b_average_reciprocities = compute_average_metric_for_games(botFileHandler, round_lengths, graph="SummaryTransaction", metric='Reciprocity')
    b_average_reciprocities2 = compute_average_metric_for_games(botFileHandler, round_lengths, graph="SummaryTransaction", metric='Reciprocity2')
    b_average_polarization = compute_average_metric_for_games(botFileHandler, round_lengths, graph="Influence", metric='Polarization')
    b_evolution1 = compute_average_metric_for_games(botFileHandler, round_lengths, graph="SummaryTransaction", metric='Evolution Coefficient1')
    b_evolution2 = compute_average_metric_for_games(botFileHandler, round_lengths, graph="SummaryTransaction", metric='Evolution Coefficient2')

    # print()
    # print("h_average_reciprocities2:", h_average_reciprocities2)
    # print("b_average_reciprocities2:", b_average_reciprocities2)

    h_data_points = []
    for i in range(len(h_popularities)):
        h_data_points += [[h_givings[i], h_keepings[i], h_takings[i],
                           h_popularities[i], h_gini_indexes[i],
                           h_average_degrees[i], h_average_entropy[i],
                           h_average_reciprocities[i], h_average_reciprocities2[i],
                           h_average_polarization[i],
                           h_evolution1[i], h_evolution2[i],
                           ]]
    h_data_points = np.array(h_data_points)

    b_data_points = []
    for i in range(len(b_popularities)):
        b_data_points += [[b_givings[i], b_keepings[i], b_takings[i],
                           b_popularities[i], b_gini_indexes[i],
                           b_average_degrees[i], b_average_entropy[i],
                           b_average_reciprocities[i], b_average_reciprocities2[i],
                           b_average_polarization[i],
                           b_evolution1[i], b_evolution2[i],
                           ]]
    b_data_points = np.array(b_data_points)

    distance = mahalanobis_distance_between_classes(h_data_points, b_data_points)
    p_value = mahalanobis_probability(distance, h_data_points.shape[1])

    return distance, p_value


def get_metric_list(fileHandler, metric, graph):
    if metric == 'Popularity Centrality' and graph == 'Transaction':
        return mean_popularity_over_time(fileHandler)
    elif metric == 'Gini Index' and graph == 'Transaction':
        return gini_index_over_time(fileHandler)
    elif (metric == 'Giving' or metric == 'Keeping' or metric == 'Taking') and graph == 'Transaction':
        return economic_actions_data(fileHandler, graph="Transaction", metric=metric)
    elif graph == 'Transaction':
        return combined_metric_data(fileHandler, graph="Transaction", metric=metric)
    elif graph == 'SummaryTransaction':
        return combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
    else:
        Exception("Invalid graph and/or metric")


def plot_scatter(fileHandlers, metric1, metric2, graph1, graph2, title=None, filename=None, label_placement=None,
                 scale=None, metric1_name=None, metric2_name=None):
    if title is None:
        title = metric1 + ' ' + metric2

    if metric1_name is None:
        metric1_name = metric1
    if metric2_name is None:
        metric2_name = metric2

    metric1_values, metric1_sem = [], []
    metric2_values, metric2_sem = [], []
    label_names, colors = [], []

    for fileHandler in fileHandlers:
        metric_list = get_metric_list(fileHandler, metric1, graph1)
        metric_list = [i for i in metric_list if i > -100]  # remove games where there was no stealing
        metric1_values += [np.mean(metric_list)]
        metric1_sem += [compute_sem(metric_list)]
        label_names += [fileHandler.label_name.replace('\n',' ')]
        colors += [fileHandler.color]

    for fileHandler in fileHandlers:
        metric_list = get_metric_list(fileHandler, metric2, graph2)
        metric_list = [i for i in metric_list if i > -100]  # remove games where there was no stealing
        metric2_values += [np.mean(metric_list)]
        metric2_sem += [compute_sem(metric_list)]
        # label_names += [fileHandler.label_name]

    plot_scatter_graph(x_data=metric1_values, y_data=metric2_values, x_label=metric1_name, y_label=metric2_name,
                       x_errors=metric1_sem, y_errors=metric2_sem, labels=label_names, label_fontsize=label_fontsize,
                       label_placement=label_placement, title=title, filename=filename, colors=colors, scale=scale)


def plot_evolution_coefficient(fileHandlers, plot=display_graph, experiment_name='default'):
    # plot_bar_graph(np.mean(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    average_ecs, std_errors = [], []
    for r in range(1, 11):
        average_ec, std_error = [], []
        metric = 'Evolution Coefficient' + str(r)
        for fileHandler in fileHandlers:
            metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric) / 2
            std_error += [compute_sem(metric_list)]
            average_ec += [np.average(metric_list)]
        average_ecs += [average_ec]
        std_errors += [std_error]
    average_ecs = np.array(average_ecs).T
    std_errors = np.array(std_errors).T
    for i, fileHandler in enumerate(fileHandlers):
        x_values = np.arange(average_ecs[i].shape[0]) + 1
        y_values = average_ecs[i]
        y_error = std_errors[i]

        # Plot the main line
        plt.plot(x_values, y_values, label=fileHandler.label_name.replace('\n', ' '), color=fileHandler.color)

        # Add the error ribbon
        plt.fill_between(x_values, y_values - y_error, y_values + y_error, alpha=0.3, color=fileHandler.color)

        # plt.errorbar(np.arange(average_ecs[i].shape[0]) + 1, average_ecs[i], yerr=std_errors[i], fmt='-o', label=fileHandler.label_name.replace('\n',' '))
    plot(title="", filename="Evolution Coefficient", xlabel="Rounds Elapsed", ylabel="Evolution Coefficient")
    # plot(title="Evolution Coefficient of Agents in Self-Play", xlabel='', ylabel='average evolution coefficient', ylim=None,
    #      filename=metric + 'Summary ' + experiment_name + ' ' + mean)

def plot_polarization_coefficient(fileHandlers, plot=display_graph, experiment_name='default'):
    # plot_bar_graph(np.mean(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')
    metric_lists, std_errors = [], []
    metric = 'Polarization'
    for fileHandler in fileHandlers:
        metric_lists += [combined_metric_data(fileHandler, graph="Influence", metric=metric)]
        std_errors += [compute_sem(metric_lists[-1])]
        # plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=fileHandler.label_name, color='#1582b3')

    for i, fileHandler in enumerate(fileHandlers):
        x_values = np.arange(metric_lists[i].shape[0]) + 1
        y_values = metric_lists[i]
        y_error = std_errors[i]

        # Plot the main line
        plt.plot(x_values, y_values, label=fileHandler.label_name.replace('\n', ' '), color=fileHandler.color)

        # Add the error ribbon
        plt.fill_between(x_values, y_values - y_error, y_values + y_error, alpha=0.3, color=fileHandler.color)

    plot(xlabel='Round', ylabel='Polarization Coefficient', ylim=None, filename=metric + ' ' + experiment_name + ' ' + mean)


plot = display_graph


# fileHandlers = [testing_humans_file_handler, random_file_handler, ecab_cab_file_handler, tft1_mean_file_handler, tft1_property_file_handler, gen_pop_tft_mean_file_handler, gen_pop_tft_property_file_handler, society1_mean_file_handler, society1_property_file_handler, gen_pop_sum_mean_file_handler, gen_pop_sum_property_file_handler]
fileHandlers = [testing_humans_file_handler, random_file_handler, ecab_cab_file_handler, tft1_property_file_handler, gen_pop_tft_property_file_handler, society1_property_file_handler, gen_pop_sum_property_file_handler]
experiment_name = 'testing'
plot_evolution_coefficient(fileHandlers, plot=save_graph, experiment_name=experiment_name)
plot_polarization_coefficient(fileHandlers, plot=save_graph, experiment_name=experiment_name)

plot_all_charts(fileHandlers, plot=save_graph, experiment_name=experiment_name)

scale = [120, 200, 0, 0.2]
label_placement = [['left', 'top'], ['left', 'bottom'], ['right', 'top'], ['left', 'bottom'], ['left', 'bottom'], ['right', 'top'], ['left', 'bottom']]
plot_scatter(fileHandlers, "Popularity Centrality", "Gini Index", label_placement=label_placement, scale=scale,
             graph1='Transaction', graph2='Transaction', filename='Popularity-Gini-Index ' + experiment_name + ' scatter',
             metric1_name="Popularity", metric2_name="Gini Index")

scale = [0.3, 1, 0.3, 1]
label_placement = [['left', 'top'], ['right', 'top'], ['right', 'bottom'], ['left', 'bottom'], ['left', 'top'], ['right', 'bottom'], ['right', 'bottom']]
plot_scatter(fileHandlers, "Density", "Entropy Short Term", label_placement=label_placement, scale=scale,
             graph1='Transaction', graph2='SummaryTransaction', filename='Entropy-Density ' + experiment_name + ' scatter',
             metric1_name="Density", metric2_name="Entropy")

scale = [.45, 1.02, .45, 1.02]
label_placement = [['right', 'top'], ['left', 'center'], ['right', 'top'], ['right', 'top'], ['right', 'bottom'], ['right', 'bottom'], ['right', 'bottom']]
plot_scatter(fileHandlers, "Reciprocity2", "Reciprocity", label_placement=label_placement, scale=scale,
             graph1='SummaryTransaction', graph2='SummaryTransaction', filename='Reciprocity ' + experiment_name + ' scatter',
             metric1_name="Immediate Reciprocity", metric2_name="Overall Reciprocity")

# plot_scatter(fileHandlers, "Degree", "In-Degree", graph1='Transaction', graph2='Transaction', filename='Degree-In-Degree ' + experiment_name + ' scatter')
# plot_scatter(fileHandlers, "Clustering", "Reciprocity", graph1='SummaryTransaction', graph2='SummaryTransaction', filename='Reciprocity-Clustering ' + experiment_name + ' scatter')
# plot_scatter(fileHandlers, "Taking", "Giving", graph1='Transaction', graph2='Transaction', filename='Giving-Taking ' + experiment_name + ' scatter')

fileHandler = user_study_file_handler

# plt.clf()  # Clears the current figure
# plt.cla()  # Clears the current axes (optional)
# plt.close()  # Closes the figure (optional)

metrics = ["human", "bot"]
number_of_rounds = 16
for metric in metrics:
    metric_list = mean_popularity_over_time(fileHandler, metric)[:number_of_rounds]
    std_error = compute_sem(metric_list)
    if metric == "bot":
        plot_line_graph(metric_list, label_name="hCAB", color=gen_pop_sum_property_file_handler.color)
        # Add the error ribbon
        plt.fill_between(np.arange(number_of_rounds), metric_list - std_error, metric_list + std_error, alpha=0.3,
                         color=gen_pop_sum_property_file_handler.color)
    else:
        plot_line_graph(metric_list, label_name=metric, color=testing_humans_file_handler.color)
        # Add the error ribbon
        plt.fill_between(np.arange(number_of_rounds), metric_list - std_error, metric_list + std_error, alpha=0.3,
                         color=testing_humans_file_handler.color)
    # plot_bar_graph(np.mean(metric_list), std_error=std_error, label_name=metric, color='#1582b3')
save_graph(filename="UserStudy Popularity Comparison", xlabel="Round", ylabel="Popularity")


metrics = ['humanReciprocity', 'botReciprocity', 'humanBotReciprocity']
for metric in metrics:
    metric_list = combined_metric_data_for_summary_graph(fileHandler, graph="SummaryTransaction", metric=metric)
    std_error = compute_sem(metric_list)
    # average_reciprocity += [np.average(metric_list)]
    plot_bar_graph(np.average(metric_list), std_error=std_error, label_name=metric, color='#1582b3')
save_graph(title="Reciprocity of Agents in User-Study", xlabel='', ylabel='average reciprocity', ylim=None, filename="UserStudy Reciprocity Comparison")


metrics = ["human", "bot"]
for metric in metrics:
    giving, keeping, taking = [], [], []
    g = economic_actions_data(fileHandler, graph="Transaction", metric=metric+'Giving')
    g_error = compute_sem(g)
    k = economic_actions_data(fileHandler, graph="Transaction", metric=metric+'Keeping')
    k_error = compute_sem(k)
    t = economic_actions_data(fileHandler, graph="Transaction", metric=metric+'Taking')
    t_error = compute_sem(t)
    giving += [np.average(g) / 2]
    keeping += [np.average(k) / 2]
    taking += [np.average(t) / 2]
    plot_bar_graph(giving[-1], std_error=g_error, color='g', show_numbers=True)
    plot_bar_graph(keeping[-1], std_error=k_error, label_name=metric, color='b', show_numbers=True)
    plot_bar_graph(taking[-1], std_error=t_error, color='r', show_numbers=True)
save_graph(title='Economic Actions', xlabel='', filename='UserStudy Economic Actions Comparison')


print("Mahalanobis Distance Humans     : ", summary_metric(testing_humans_file_handler, testing_humans_file_handler)[0])
print("P-Value              Humans     : ", summary_metric(testing_humans_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance UserStudy       : ", summary_metric(user_study_file_handler, testing_humans_file_handler)[0])
print("P-Value              UserStudy       : ", summary_metric(user_study_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance RAND       : ", summary_metric(random_file_handler, testing_humans_file_handler)[0])
print("P-Value              RAND       : ", summary_metric(random_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance pTFT PSO MSE   : ", summary_metric(tft1_mean_file_handler, testing_humans_file_handler)[0])
print("P-Value              pTFT PSO MSE   : ", summary_metric(tft1_mean_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance pTFT PSO PRP   : ", summary_metric(tft1_property_file_handler, testing_humans_file_handler)[0])
print("P-Value              pTFT PSO PRP   : ", summary_metric(tft1_property_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance pTFT EPDM MSE   : ", summary_metric(gen_pop_tft_mean_file_handler, testing_humans_file_handler)[0])
print("P-Value              pTFT EPDM MSE   : ", summary_metric(gen_pop_tft_mean_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance pTFT EPDM PRP: ", summary_metric(gen_pop_tft_property_file_handler, testing_humans_file_handler)[0])
print("P-Value              pTFT EPDM PRP: ", summary_metric(gen_pop_tft_property_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance eCAB        : ", summary_metric(ecab_cab_file_handler, testing_humans_file_handler)[0])
print("P-Value              eCAB        : ", summary_metric(ecab_cab_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance hCAB PSO MSE : ", summary_metric(society1_mean_file_handler, testing_humans_file_handler)[0])
print("P-Value              hCAB PSO MSE : ", summary_metric(society1_mean_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance hCAB PSO PRP : ", summary_metric(society1_property_file_handler, testing_humans_file_handler)[0])
print("P-Value              hCAB PSO PRP : ", summary_metric(society1_property_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance hCAB EPDM MSE: ", summary_metric(gen_pop_sum_mean_file_handler, testing_humans_file_handler)[0])
print("P-Value              hCAB EPDM MSE: ", summary_metric(gen_pop_sum_mean_file_handler, testing_humans_file_handler)[1])
print()
print("Mahalanobis Distance hCAB EPDM PRP: ", summary_metric(gen_pop_sum_property_file_handler, testing_humans_file_handler)[0])
print("P-Value              hCAB EPDM PRP: ", summary_metric(gen_pop_sum_property_file_handler, testing_humans_file_handler)[1])
print()
