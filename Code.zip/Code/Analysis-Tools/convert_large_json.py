import configuration as config
import data_processing
from configuration import DATAPATH
from metric_manager import *
import networkx as nx
import networkx.algorithms.community as nx_comm
import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.use('tkagg')
# mpl.use('module://backend_interagg')
import numpy as np
import seaborn
import re
import json
import pandas as pd


# chat = 'study/no_chat/'
# name = 'jhg_HFZJ'

# chat = 'study/half_human_bot/'
# name = 'jhg_KCLT'
# name = 'jhg_MQHR'

# chat = 'pre_study/no_chat/'
# name = 'jhg_KWMG'
# name = 'jhg_QLHS'
# name = 'jhg_TSJW'
# name = 'jhg_XQRT'
# name = 'jhg_ZRHK'

# chat = 'pre_study/chat/'
# name = 'jhg_HLCK'
# name = 'jhg_KRJP'
# name = 'jhg_PXWT'
# name = 'jhg_SNCR'
# name = 'jhg_VWJH'

# num_rounds = 11

data = []
gameFolder = "hCAB_games/study_games/jsons/"

def save_game(game):
    game_code = game["publicInfo"]["gameCode"]
    alpha = game["publicInfo"]["gameParams"]['popularityFunctionParams']['alpha']
    beta = game["publicInfo"]["gameParams"]['popularityFunctionParams']['beta']
    cGive = game["publicInfo"]["gameParams"]['popularityFunctionParams']['cGive']
    cKeep = game["publicInfo"]["gameParams"]['popularityFunctionParams']['cKeep']
    cSteal = game["publicInfo"]["gameParams"]['popularityFunctionParams']['cSteal']

    players_pids = {}
    for player in game["playerInfo"]:
        if (game["playerInfo"][player]["gameName"] != '' and game["playerInfo"][player]["botType"] == ''):
            pid = "Human"
            name = game["playerInfo"][player]["gameName"]
            players_pids[name] = pid
        elif (game["playerInfo"][player]["gameName"] != ''):
            pid = game["playerInfo"][player]["botType"]
            name = game["playerInfo"][player]["gameName"]
            players_pids[name] = pid

    _, players_pids = zip(*sorted(zip(list(players_pids.keys()), list(players_pids.values()))))
    numPlayers = len(players_pids)

    popularities = game["privateInfo"]["masterPopularities"]
    tmp = []
    for i in range(len(popularities)):
        tmp += [list(popularities['round_' + str(i + 1)].values())]
    popularities = np.array(tmp[:])

    transactions = game["privateInfo"]["masterTransactions"]
    tmp = []
    tmp += [list(np.zeros((numPlayers, numPlayers)))]
    for i in range(len(transactions)):
        if len(transactions['round_' + str(i + 1)]) == numPlayers:
            tmp1 = list(transactions['round_' + str(i + 1)].values())
            tmp2 = []
            for j in range(len(tmp1)):
                tmp2 += [list(tmp1[j].values())]
            tmp += [tmp2]
    transactions = np.array(tmp)

    influences = game["privateInfo"]["masterInfluences"]
    tmp = []
    for i in range(len(influences)):
        if len(influences['round_' + str(i + 1)]) == numPlayers:
            tmp1 = list(influences['round_' + str(i + 1)].values())
            tmp2 = []
            for j in range(len(tmp1)):
                tmp2 += [list(tmp1[j].values())]
            tmp += [tmp2]
    influences = np.array([np.identity(numPlayers)] + list(
        np.array(tmp)[1:, :, :numPlayers]))  # the first influence matrix is always all zeros

    lines = []
    # Dynamically create headers based on the number of players
    headers = 'round,alpha,beta,give,keep,steal,'
    for p_num in range(numPlayers):
        headers += 'p' + str(p_num) + ','

    for i in range(numPlayers):
        for j in range(numPlayers):
            headers += str(i) + '-T-' + str(j) + ','

    for i in range(numPlayers):
        for j in range(numPlayers):
            headers += str(i) + '-I-' + str(j) + ','

    for p_num in range(numPlayers):
        headers += 'pid' + str(p_num) + ','

    lines += [headers[:-1] + '\n']
    for round in range(popularities.shape[0]):
        line = str(round) + "," + str(alpha) + "," + str(beta) + "," + str(cGive) + "," + str(cKeep) + "," + str(
            cSteal) + ","
        for popularity in popularities[round]:
            line += str(popularity) + ","
        for transaction in transactions[round]:
            for trans in transaction:
                line += str(trans) + ","
        for influence in influences[round]:
            for influ in influence:
                line += str(influ) + ","
        for player in players_pids:
            line += str(player) + ","
        lines += [line[:-1] + '\n']

    f = open(DATAPATH + gameFolder + "jhg_" + game_code + ".csv", "w")
    for line in lines:
        f.write(line)
    f.close()
    pass

def createGames(filename):
    f = open(config.DATAPATH + filename)
    data = json.load(f)
    gameCodes = data['publicInfo']['gameCode']
    gameCodesValues = np.array(list(gameCodes.values()))
    gameCodesKeys = np.array(list(gameCodes.keys()))
    games = data['games']
    # initialSetup = data['initialSetup']

    validGamesValues, validGamesKeys = [], []
    for i in range(len(gameCodesValues)):
        if(games[gameCodesValues[i]]["publicInfo"]["gameStarted"] and
                games[gameCodesValues[i]]["publicInfo"]["gameStatus"] == 'finished' and
                games[gameCodesValues[i]]["publicInfo"]["roundNum"] > 10 and
                len(games[gameCodesValues[i]]["playerInfo"]) > 5):
            validGamesValues += [gameCodesValues[i]]
            validGamesKeys += [gameCodesKeys[i]]

    for validGamesKey, validGamesValue in zip(validGamesKeys, validGamesValues):
        game = games[validGamesValue]
        save_game(game)


# filename = gameFolder + "jhg-2-preprod-default-rtdb-fa806d50-5fc9-1318-a671-1db8683fa24b-export.json"
filenames = []

filenames += [gameFolder + "jhg-2-preprod-default-rtdb-1dd13e30-b2df-132b-a71c-e32918927e54-export.json"]
filenames += [gameFolder + "jhg-2-preprod-default-rtdb-4e6156f0-b359-132b-a71c-e32918927e54-export.json"]
filenames += [gameFolder + "jhg-2-preprod-default-rtdb-7c3872c0-c01f-132b-a71c-e32918927e54-export.json"]
filenames += [gameFolder + "jhg-2-preprod-default-rtdb-8d173a00-a56b-132b-a71c-e32918927e54-export.json"]
filenames += [gameFolder + "jhg-2-preprod-default-rtdb-9c037180-a5bd-132b-a71c-e32918927e54-export.json"]
filenames += [gameFolder + "jhg-2-preprod-default-rtdb-705b1190-c080-132b-a71c-e32918927e54-export.json"]
filenames += [gameFolder + "jhg-2-preprod-default-rtdb-b66cd5d0-9086-132b-a71c-e32918927e54-export.json"]
filenames += [gameFolder + "jhg-2-preprod-default-rtdb-e24ef9d0-8f32-132b-a71c-e32918927e54-export.json"]

for filename in filenames:
    f = open(config.DATAPATH + filename)
    data = json.load(f)
    save_game(data)

# createGames("Lab Games/jhg-2-prod-default-rtdb-export.json")

# dp = data_processing.DataProcessing("")
# print(chat + 'jsons/jhg_' + name + '.json')
#
# num_players = len(dp.players)
#
# # Dynamically create headers based on the number of players
# headers = ['round', 'alpha', 'beta', 'give', 'keep', 'steal']
# for p_num in range(num_players):
#     headers += ['p' + str(p_num)]
#
# for i in range(num_players):
#     for j in range(num_players):
#         headers += [str(i) + '-T-' + str(j)]
#
# for i in range(num_players):
#     for j in range(num_players):
#         headers += [str(i) + '-I-' + str(j)]
#
# for p_num in range(num_players):
#     headers += ['pid' + str(p_num)]
#
# humans = dp.get_human()
#
# for i, (popul, trans, influ) in enumerate(zip(dp.get_popularities(), dp.get_transactions(), dp.get_influences())):
#     line = [i, dp.get_alpha(), dp.get_beta(), dp.get_give(), dp.get_keep(), dp.get_steal()]
#     line += list(popul)
#     line += list(np.array(trans).flatten())
#     line += list(np.array(influ).flatten())
#     line += list(humans)
#     data += [line]
#
# # num_humans = 0
# # for i in range(len(humans)):
# #     if humans[i][:3] == 'Hum':
# #         num_humans += 1
#
# dataframe = pd.DataFrame(data, columns=headers)
# dataframe.to_csv(config.DATAPATH + chat + 'csvs/jhg_' + name + '.csv', index=False)
# x = 0
# trans_gs = dp.get_transaction_graphs()
# influ_gs = dp.get_influence_graphs()
# pop = dp.get_popularities()


# chat_game_codes = ['jhg_HLCK',  'jhg_KRJP', 'jhg_PXWT', 'jhg_SNCR', 'jhg_VWJH']
# transaction_metrics_data_chat, influence_metrics_data_chat = [], []
# for name in chat_game_codes:  # pre_study/chat
#     dp = data_processing.DataProcessing(chat + name + '.json')
#
#     # print(dp.get_transactions())
#     # print(dp.get_influence_graphs())
#
#     trans_gs = dp.get_transaction_graphs()
#     influ_gs = dp.get_influence_graphs()
#     pop = dp.get_popularities()
#
#     transaction_mm = MetricManager('Transaction', graphs=trans_gs, included_metrics=config.transaction_metrics, popularities=pop[:-1])
#     influence_mm = MetricManager('Influence', graphs=influ_gs, included_metrics=config.influence_metrics, popularities=pop[1:])
#     # Draw Graphs
#     # transaction_mm.draw_graphs(name+'_Transaction')
#     # influence_mm.draw_graphs(name+'_Influence')
#
#     # Plot Popularity
#     # transaction_mm.print_abs_popularity_plot(name)
#     # transaction_mm.print_popularity_plot(name)
#
#     # Plot Metrics
#     # transaction_mm.print_metric_plots(name+'_Transaction')
#     # influence_mm.print_metric_plots(name+'_Influence')
#
#     transaction_metrics_data_chat += [transaction_mm.get_metrics()]
#     influence_metrics_data_chat += [influence_mm.get_metrics()]
#
#     # transaction_mm.print_metrics()
#
# # Transaction Matrix Graphs
# for i, m in enumerate(config.transaction_metrics):
#     no_chat_xs = []
#     no_chat_transaction_metrics_data = []
#     for j, game in enumerate(no_chat_game_codes):
#         no_chat_xs += [np.arange(len(transaction_metrics_data_no_chat[j][i][1][:num_rounds]))]
#         no_chat_transaction_metrics_data += [transaction_metrics_data_no_chat[j][i][1][:num_rounds]]
#
#     xs, metrics_data, std_error = np.average(no_chat_xs, axis=0), np.average(no_chat_transaction_metrics_data, axis=0), \
#         np.std(no_chat_transaction_metrics_data, axis=0)
#     plt.plot(xs, metrics_data, color='c', label='no chat')
#     plt.plot(xs, metrics_data + std_error, color='c', linestyle=(0, (1, 1)))
#     plt.plot(xs, metrics_data - std_error, color='c', linestyle=(0, (1, 1)))
#
#     chat_xs = []
#     chat_transaction_metrics_data = []
#     for j, game in enumerate(chat_game_codes):
#         chat_xs += [np.arange(len(transaction_metrics_data_chat[j][i][1][:num_rounds]))]
#         chat_transaction_metrics_data += [transaction_metrics_data_chat[j][i][1][:num_rounds]]
#
#     xs, metrics_data, std_error = np.average(no_chat_xs, axis=0), np.average(chat_transaction_metrics_data, axis=0), \
#         np.std(chat_transaction_metrics_data, axis=0)
#     plt.plot(xs, metrics_data, color='m', label='chat')
#     plt.plot(xs, metrics_data + std_error, color='m', linestyle=(0, (1, 1)))
#     plt.plot(xs, metrics_data - std_error, color='m', linestyle=(0, (1, 1)))
#
#     plt.title("Transaction " + m)
#     # plt.legend()
#     plt.xlabel('Round')
#     plt.ylabel(m)
#     # plt.savefig('networkAnalysis/' + title + ' ' + metric)
#     plt.show()
#     plt.close()
#     plt.clf()
#
#     bar_width = 0.4
#     bins = ['0-5', '6-10']
#     x = np.arange(len(bins))
#     no_chat_metrics_data = [np.mean(np.array(no_chat_transaction_metrics_data)[:, :5]), np.mean(np.array(
#         no_chat_transaction_metrics_data)[:, 5:10])]
#     no_chat_std_error = [np.std(np.array(no_chat_transaction_metrics_data)[:, :5]), np.std(np.array(
#         no_chat_transaction_metrics_data)[:, 5:10])]
#     chat_metrics_data = [np.mean(np.array(chat_transaction_metrics_data)[:, :5]), np.mean(np.array(
#         chat_transaction_metrics_data)[:, 5:10])]
#     chat_std_error = [np.std(np.array(chat_transaction_metrics_data)[:, :5]), np.std(np.array(
#         chat_transaction_metrics_data)[:, 5:10])]
#
#     plt.bar(x, no_chat_metrics_data, width=bar_width, color='c')
#     plt.bar(x + bar_width, chat_metrics_data, width=bar_width, color='m')
#     plt.errorbar(x, no_chat_metrics_data, yerr=no_chat_std_error, fmt="o")
#     plt.errorbar(x + bar_width, chat_metrics_data, yerr=chat_std_error, fmt="o")
#
#     plt.title("Transaction " + m)
#     plt.xticks(x + bar_width / 2, bins)
#     plt.show()
#
#     # Influence Matrix Graphs
#     no_chat_xs = []
#     no_chat_influence_metrics_data = []
#     for j, game in enumerate(no_chat_game_codes):
#         no_chat_xs += [np.arange(len(influence_metrics_data_no_chat[j][i][1][:num_rounds-1]))]
#         no_chat_influence_metrics_data += [influence_metrics_data_no_chat[j][i][1][:num_rounds-1]]
#
#     xs, metrics_data, std_error = np.average(no_chat_xs, axis=0), np.average(no_chat_influence_metrics_data, axis=0), \
#         np.std(no_chat_influence_metrics_data, axis=0)
#     plt.plot(xs, metrics_data, color='c', label='no chat')
#     plt.plot(xs, metrics_data + std_error, color='c', linestyle=(0, (1, 1)))
#     plt.plot(xs, metrics_data - std_error, color='c', linestyle=(0, (1, 1)))
#
#     chat_xs = []
#     chat_influence_metrics_data = []
#     for j, game in enumerate(chat_game_codes):
#         chat_xs += [np.arange(len(influence_metrics_data_chat[j][i][1][:num_rounds-1]))]
#         chat_influence_metrics_data += [influence_metrics_data_chat[j][i][1][:num_rounds-1]]
#
#     xs, metrics_data, std_error = np.average(no_chat_xs, axis=0), np.average(chat_influence_metrics_data, axis=0), \
#         np.std(chat_influence_metrics_data, axis=0)
#     plt.plot(xs, metrics_data, color='m', label='chat')
#     plt.plot(xs, metrics_data + std_error, color='m', linestyle=(0, (1, 1)))
#     plt.plot(xs, metrics_data - std_error, color='m', linestyle=(0, (1, 1)))
#
#     plt.title("Influence " + m)
#     # plt.legend()
#     plt.xlabel('Round')
#     plt.ylabel(m)
#     # plt.savefig('networkAnalysis/' + title + ' ' + metric)
#     plt.show()
#     plt.close()
#     plt.clf()
#
#     bar_width = 0.4
#     bins = ['0-5', '6-10']
#     x = np.arange(len(bins))
#     no_chat_metrics_data = [np.mean(np.array(no_chat_influence_metrics_data)[:, :5]), np.mean(np.array(
#         no_chat_influence_metrics_data)[:, 5:10])]
#     no_chat_std_error = [np.std(np.array(no_chat_influence_metrics_data)[:, :5]), np.std(np.array(
#         no_chat_influence_metrics_data)[:, 5:10])]
#     chat_metrics_data = [np.mean(np.array(chat_influence_metrics_data)[:, :5]), np.mean(np.array(
#         chat_influence_metrics_data)[:, 5:10])]
#     chat_std_error = [np.std(np.array(chat_influence_metrics_data)[:, :5]), np.std(np.array(
#         chat_influence_metrics_data)[:, 5:10])]
#
#     plt.bar(x, no_chat_metrics_data, width=bar_width, color='c')
#     plt.bar(x + bar_width, chat_metrics_data, width=bar_width, color='m')
#     plt.errorbar(x, no_chat_metrics_data, yerr=no_chat_std_error, fmt="o")
#     plt.errorbar(x + bar_width, chat_metrics_data, yerr=chat_std_error, fmt="o")
#
#     plt.title("Influence " + m)
#     plt.xticks(x + bar_width / 2, bins)
#     plt.show()

    # print(dp.get_influence_graphs())
    # print(dp.get_transactions())
