# junior_high_network_playground
junior_high_network_playground

The first thing you will want to do is change the filepath in the configuration.py.  It is marked with the comment: "TODO: Change filepath to your own path to JHG_DATA_SETS".

After this you can edit main_behavior.py to specify the runs you would like to preprocess. You can edit 'game_types' and 'trial_dirs' to preprocess games from the user studies or simulated games. Each is marked with a TODO comment so that it is easy to find.

Then you can run 

```
python main_behavior.py
```

This should do all the preprocessing.  After the preprocessing is finished, you can run:

```
final_data_analysis.py
```

This file is set up to print the results used in the paper as well as some other results.


