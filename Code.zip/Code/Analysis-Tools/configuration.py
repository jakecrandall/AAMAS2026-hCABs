import networkx as nx
import networkx.algorithms.community as nx_comm
import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.use('tkagg')
# mpl.use('module://backend_interagg')
import numpy as np
import seaborn
import re
import json

DATAPATH = '/home/watchtower/Datasets/JuniorHighNetwork/BehaviorStudy/JHG_DataSets/'  # TODO: Change filepath to your own path to JHG_DATA_SETS
DATAPATH_SIMULATED = DATAPATH


included_metrics = [
    # # # Centrality Metrics
    # 'Degree',
    # 'Weighted Degree',
    # 'In-Degree',
    # 'Weighted In-Degree',
    # 'Out-Degree',
    # 'Weighted Out-Degree',
    # 'Average Neighbor Degree',
    # 'Weighted Average Neighbor Degree',
    # # 'Diffusion Centrality',
    # # 'Eigenvector Centrality',
    # 'Katz Centrality',
    # # 'Alpha Centrality',
    # # 'Bonacich Centrality',

    # # Connectivity Metrics
    # 'Density',
    # 'Weighted Density',
    # 'Node Connectivity',
    # 'Radius',
    # 'Diameter',
    # 'Betweenness Centrality',
    # 'Closeness Centrality',
    # 'Load Centrality',

    # # # Homophily
    # 'EI Homophily Index',
    # 'Heterogeneity Index',
    # 'Degree Assortativity',
    # 'Popularity Assortativity',

    # # # Community Metrics
    # 'Reciprocity',
    # 'Transitivity',
    # 'Clustering',
    # 'Louvain Modularity',

    # # # Persistence Metrics
    # 'Degree Persistence',
    # 'Edge Persistence',
    # 'Modularity Persistence',
]

transaction_metrics = [
    # # Centrality Metrics
    'Degree',  # number of friend a node has
    'In-Degree',
    'Out-Degree',
    'Weighted Degree',  # strength of a node's friends
    'Average Neighbor Degree',  # number of a node's friends friends
    'Weighted Average Neighbor Degree',  # strength of a node's friend's friends
    # 'Katz Centrality',  # overall position in the network

    # # Connectivity Metrics
    'Density',
    'Algebraic Connectivity',

    # # Homophily
    'Popularity Assortativity',  # to what degree do popular people cluster together

    # # Community Metrics
    'Reciprocity',  # rate of return based on number of tokens
    'Transitivity',  # strength of personal community (the friends around a node) and
    'Clustering',  # strength of personal community (the friends around a node) and
    # the measure of cooperation in the network

    # 'Louvain Modularity',  # Degree to which the network is unified / divided, maybe it is helpful to see the
    # number of communities that are formed
    # 'Signed Louvain Modularity Custom',
    # 'Signed Louvain Modularity Leskovec',
    # 'Signed Louvain Modularity Karrer',

    # # Persistence Metrics
    'Edge Persistence',  # measures how consistent the network is
    # 'Modularity Persistence'  # measures changes in unification of the network
]

influence_metrics = [
    # # Centrality Metrics
    'Weighted Degree',  # strength of a node's friends takes into account popularity (I think we should normalize
    # by average popularity, so it shows relative strength)
    'Weighted Average Neighbor Degree',  # strength of a node's friend's friends takes into account popularity
    # (I think we should normalize by average popularity, so it shows relative strength)
    # 'Katz Centrality',  # overall position in the network (true measure to optimize)

    # # Connectivity Metrics
    'Algebraic Connectivity',

    # # # Homophily
    'Popularity Assortativity',  # to what degree do popular people cluster together

    # # # Community Metrics
    'Reciprocity',  # rate of return based on popularity
    'Clustering',  # strength of personal community (the friends around a node) and
    # the measure of cooperation in the network

    # 'Louvain Modularity',  # Degree to which the network is unified / divided, maybe it is helpful to see the
    # number of communities that are formed
    # 'Signed Louvain Modularity Custom',
    # 'Signed Louvain  Modularity Leskovec',
    # 'Signed Louvain Modularity Karrer',

    # # # Persistence Metrics
    # 'Modularity Persistence'  # measures changes in unification of the network (I think we should modify this
    # to somehow measure modularity differences between the influence and transaction matrix).  It would measure
]

transaction_metrics = []

influence_metrics = []