import networkx
from numpy.ma.extras import average

import configuration as config
import networkx as nx
# import networkx.algorithms.community as nx_comm
import matplotlib.pyplot as plt
import matplotlib as mpl
from polarization import *

import louvain_modularity
from tmp import individual_distances

mpl.use('tkagg')
# mpl.use('module://backend_interagg')
import numpy as np
import seaborn
import re
import json
import warnings


def fxn():
    warnings.warn("deprecated", DeprecationWarning)


class MetricManager:
    def __init__(self, name, graphs, included_metrics, popularities, outfile):
        self.give_coefficient =1.30
        self.keep_coefficient = 0.95
        self.take_coefficient = 1.60

        self.name = name
        self.included_metrics = included_metrics
        self.popularities = popularities
        self.outfile = outfile

        # Centrality Metrics
        self.degree_vals = ['Degree', [], [], []]  # in-degree centrality (1 norm)
        self.degree_w_vals = ['Weighted Degree', [], [], []]  # in-degree centrality (1 norm)
        self.in_degree_vals = ['In-Degree', [], [], []]  # in-degree centrality (1 norm)
        self.in_degree_w_vals = ['Weighted In-Degree', [], [], []]  # in-degree centrality (1 norm)
        self.out_degree_vals = ['Out-Degree', [], [], []]  # out-degree centrality (1 norm)
        self.out_degree_w_vals = ['Weighted Out-Degree', [], [], []]  # out-degree centrality (1 norm)
        self.average_neighbor_degree_vals = ['Average Neighbor Degree', [], [], []]  # degree centrality (2 norm)
        self.average_neighbor_degree_w_vals = ['Weighted Average Neighbor Degree', [], [],
                                               []]  # degree centrality (2 norm)
        self.diffusion_centrality_vals = ['Diffusion Centrality', [], [], []]  # degree centrality (2 norm)
        self.eigenvector_centrality_vals = ['Eigenvector Centrality', [], [], []]  # degree centrality (infinity norm)
        self.katz_centrality_vals = ['Katz Centrality', [], [], []]  # degree centrality (infinity norm)

        # Connectivity Metrics
        self.density_vals = ['Density', []]
        self.density_w_vals = ['Weighted Density', []]
        self.node_connectivity_vals = ['Node Connectivity', []]
        # Diameter
        # Radius
        self.closeness_centrality_vals = ['Closeness Centrality', [], [], []]
        self.betweenness_centrality_vals = ['Betweenness Centrality', [], [], []]  # flow centrality (infinity norm)
        self.load_centrality_vals = ['Load Centrality', [], [], []]
        self.algebraic_connectivity_vals = ['Algebraic Connectivity', [], [], []]

        # Homophily Metrics
        self.ei_homophily_index_vals = ['EI Homophily Index', []]
        self.heterogeneity_index_vals = ['Heterogeneity Index', []]
        self.degree_assortativity_vals = ['Degree Assortativity', []]
        self.popularity_assortativity_vals = ['Popularity Assortativity', []]

        # Community Metrics
        self.reciprocity_vals = ['Reciprocity', []]  # modularity (1 norm)
        self.transitivity_vals = ['Transitivity', []]  # modularity (2 norm)
        self.clustering_vals = ['Clustering', [], [], []]
        self.louvain_modularity_vals = ['Louvain Modularity', []]  # modularity (infinity norm)
        self.signed_louvain_modularity_custom_vals = ['Signed Louvain Modularity Custom', []]  # modularity (infinity norm)
        self.signed_louvain_modularity_leskovec_vals = ['Signed Louvain Modularity Leskovec', []]  # modularity (infinity norm)
        self.signed_louvain_modularity_karrer_vals = ['Signed Louvain Modularity Karrer', []]  # modularity (infinity norm)
        self.signed_louvain_modularity_xu_vals = ['Signed Louvain Modularity Xu', []]  # modularity (infinity norm)

        # Persistence Metrics
        self.degree_persistence_vals = ['Degree Persistence', [], [], []]
        self.edge_persistence_vals = ['Edge Persistence', [], [], []]
        self.connectivity_persistence_vals = ['Connectivity Persistence', []]
        self.robustness_vals = ['Robustness', []]
        self.community_persistence_vals = ['Community Persistence', []]
        self.modularity_persistence_vals = ['Modularity Persistence', []]

        self.graphs = graphs
        for i in range(len(graphs)):
            if i == 0:
                self.update_metrics(graphs[i], popularities[i])
            else:
                self.update_metrics(graphs[i], popularities[i], graphs[i-1])

    @staticmethod
    def add_to_list(variable_list, variable):
        if len(variable_list) == 4:
            name, var_list0, var_list1, var_list2 = variable_list
            var0, var1, var2 = variable
            var_list0 += [var0]
            var_list1 += [var1]
            var_list2 += [var2]
            return name, var_list0, var_list1, var_list2
        else:
            name, var_list = variable_list
            var_list += [variable]
            return name, var_list

    @staticmethod
    def __my_draw_networkx_edge_labels__(G, pos, edge_labels=None, label_pos=0.5, font_size=10, font_color="k",
                                         font_family="sans-serif", font_weight="normal", alpha=None, bbox=None,
                                         horizontalalignment="center", verticalalignment="center", ax=None, rotate=True,
                                         clip_on=True, rad=0.0):
        """Draw edge labels.

        Parameters
        ----------
        G : graph
            A networkx graph

        pos : dictionary
            A dictionary with nodes as keys and positions as values.
            Positions should be sequences of length 2.

        edge_labels : dictionary (default={})
            Edge labels in a dictionary of labels keyed by edge two-tuple.
            Only labels for the keys in the dictionary are drawn.

        label_pos : float (default=0.5)
            Position of edge label along edge (0=head, 0.5=center, 1=tail)

        font_size : int (default=10)
            Font size for text labels

        font_color : string (default='k' black)
            Font color string

        font_weight : string (default='normal')
            Font weight

        font_family : string (default='sans-serif')
            Font family

        alpha : float or None (default=None)
            The text transparency

        bbox : Matplotlib bbox, optional
            Specify text box properties (e.g. shape, color etc.) for edge labels.
            Default is {boxstyle='round', ec=(1.0, 1.0, 1.0), fc=(1.0, 1.0, 1.0)}.

        horizontalalignment : string (default='center')
            Horizontal alignment {'center', 'right', 'left'}

        verticalalignment : string (default='center')
            Vertical alignment {'center', 'top', 'bottom', 'baseline', 'center_baseline'}

        ax : Matplotlib Axes object, optional
            Draw the graph in the specified Matplotlib axes.

        rotate : bool (deafult=True)
            Rotate edge labels to lie parallel to edges

        clip_on : bool (default=True)
            Turn on clipping of edge labels at axis boundaries

        Returns
        -------
        dict
            `dict` of labels keyed by edge

        Examples
        --------
        >>> G = nx.dodecahedral_graph()
        >>> edge_labels = nx.draw_networkx_edge_labels(G, pos=nx.spring_layout(G))

        Also see the NetworkX drawing examples at
        https://networkx.org/documentation/latest/auto_examples/index.html

        See Also
        --------
        draw
        draw_networkx
        draw_networkx_nodes
        draw_networkx_edges
        draw_networkx_labels
        """
        import matplotlib.pyplot as plt
        import numpy as np

        if ax is None:
            ax = plt.gca()
        if edge_labels is None:
            labels = {(u, v): d for u, v, d in G.edges(data=True)}
        else:
            labels = edge_labels
        text_items = {}
        for (n1, n2), label in labels.items():
            (x1, y1) = pos[n1]
            (x2, y2) = pos[n2]
            (x, y) = (
                x1 * label_pos + x2 * (1.0 - label_pos),
                y1 * label_pos + y2 * (1.0 - label_pos),
            )
            pos_1 = ax.transData.transform(np.array(pos[n1]))
            pos_2 = ax.transData.transform(np.array(pos[n2]))
            linear_mid = 0.5 * pos_1 + 0.5 * pos_2
            d_pos = pos_2 - pos_1
            rotation_matrix = np.array([(0, 1), (-1, 0)])
            ctrl_1 = linear_mid + rad * rotation_matrix @ d_pos
            ctrl_mid_1 = 0.5 * pos_1 + 0.5 * ctrl_1
            ctrl_mid_2 = 0.5 * pos_2 + 0.5 * ctrl_1
            bezier_mid = 0.5 * ctrl_mid_1 + 0.5 * ctrl_mid_2
            (x, y) = ax.transData.inverted().transform(bezier_mid)

            if rotate:
                # in degrees
                angle = np.arctan2(y2 - y1, x2 - x1) / (2.0 * np.pi) * 360
                # make label orientation "right-side-up"
                if angle > 90:
                    angle -= 180
                if angle < -90:
                    angle += 180
                # transform data coordinate angle to screen coordinate angle
                xy = np.array((x, y))
                trans_angle = ax.transData.transform_angles(
                    np.array((angle,)), xy.reshape((1, 2))
                )[0]
            else:
                trans_angle = 0.0
            # use default box of white with white border
            if bbox is None:
                bbox = dict(boxstyle="round", ec=(1.0, 1.0, 1.0), fc=(1.0, 1.0, 1.0))
            if not isinstance(label, str):
                label = str(label)  # this makes "1" and 1 labeled the same

            t = ax.text(
                x,
                y,
                label,
                size=font_size,
                color=font_color,
                family=font_family,
                weight=font_weight,
                alpha=alpha,
                horizontalalignment=horizontalalignment,
                verticalalignment=verticalalignment,
                rotation=trans_angle,
                transform=ax.transData,
                bbox=bbox,
                zorder=1,
                clip_on=clip_on,
            )
            text_items[(n1, n2)] = t

        ax.tick_params(
            axis="both",
            which="both",
            bottom=False,
            left=False,
            labelbottom=False,
            labelleft=False,
        )

        return text_items

    def draw_graphs(self, title):
        for i, G in enumerate(self.graphs):
            plt.title(title + ' Round ' + str(i))
            # labels = nx.get_edge_attributes(G, 'weight')
            # nx.draw_networkx_edge_labels(G, pos=nx.circular_layout(G), edge_labels=labels)
            edges, weights = zip(*nx.get_edge_attributes(G, 'weight').items())
            network_positions = nx.circular_layout(G)
            # color_map = self.get_communities(G)
            nx.draw(G, pos=network_positions, with_labels=True, font_weight='bold', edge_color=weights,
                    connectionstyle='arc3, rad = 0.12')  # node_color=color_map
            labels = nx.get_edge_attributes(G, 'weight')
            # print(directed_louvain(G))
            self.__my_draw_networkx_edge_labels__(G, network_positions, edge_labels=labels, rad=.12)
            plt.savefig('networkAnalysis/' + title + ' Round ' + str(i))
            # plt.show()
            plt.close()
            plt.clf()

    @staticmethod
    def __get_average__(nx_list):
        if type(nx_list) is dict:
            array = np.array(list(nx_list.values()))
        else:
            array = np.array(nx_list)[:, 1]
        return np.average(array), np.var(array), array

    '''Measures of Centrality'''
    def get_degree(self, G, weight=None, popularity=1):
        U = self.directed_to_undirected(G)
        A = np.array(nx.to_numpy_array(U))


        if popularity == 0:
            popularity = 1
        A /= popularity
        U = nx.from_numpy_array(A)
        U = self.remove_self_edges(U)
        num_nodes = nx.number_of_nodes(U)
        v0, v1, v2 = list(np.array(self.__get_average__(U.degree(np.arange(num_nodes), weight=weight)), dtype=object))

        # print(U.degree(np.arange(num_nodes), weight=weight))

        # print('\n\n')

        return v0 / (num_nodes - 1), None, v2 / (num_nodes - 1)

    def get_in_degree(self, G, weight=None):
        num_nodes = nx.number_of_nodes(G)
        v0, v1, v2 = self.__get_average__(G.in_degree(np.arange(num_nodes), weight=weight))
        return v0 / (num_nodes - 1), None, v2 / (num_nodes - 1)

    def get_out_degree(self, G, weight=None):
        num_nodes = nx.number_of_nodes(G)
        v0, v1, v2 = self.__get_average__(G.out_degree(np.arange(num_nodes), weight=weight))
        return v0 / (num_nodes - 1), None, v2 / (num_nodes - 1)

    def get_average_neighbor_degree(self, G, weight=None):
        num_nodes = nx.number_of_nodes(G)
        v0, v1, v2 = self.__get_average__(nx.average_neighbor_degree(G, weight=weight))
        return v0 / (num_nodes - 1), None, v2 / (num_nodes - 1)

    def get_eigenvector_centrality(self, G):
        try:
            return self.__get_average__(nx.eigenvector_centrality(G))
        except:
            return None, None, [None, None, None]

    def get_katz_centrality(self, G):
        return self.__get_average__(nx.katz_centrality(G))

    def get_average_degree_connectivity(self, G):
        return nx.average_degree_connectivity(G)

    '''Measures of Connectivity'''
    def get_node_connectivity(self, G):
        U = self.directed_to_undirected(G)
        return nx.node_connectivity(U)

    # def get_edge_connectivity(self, G):
    #     U = self.directed_to_undirected(G)
    #     return nx.edge_connectivity(U)

    def get_weighted_connectivity(self, G):
        """Computes the weighted connectivity of a weighted directed graph."""

        # Compute the edge betweenness centrality for each edge in G
        edge_betweenness = nx.edge_betweenness_centrality(G, weight='weight', normalized=False)

        # Compute the weighted connectivity of G
        weighted_conn = sum(edge_betweenness.values()) / (len(G.nodes) * (len(G.nodes) - 1))

        return weighted_conn

    def get_density(self, G, weight=None):
        return nx.density(G)

    def get_closeness_centrality(self, G):
        return self.__get_average__(nx.closeness_centrality(G))

    def get_betweenness_centrality(self, G):
        return self.__get_average__(nx.betweenness_centrality(G, weight='weight'))

    def get_load_centrality(self, G):
        return self.__get_average__(nx.load_centrality(G))

    def get_shortest_path(self, G):
        return nx.shortest_path(G)

    def get_sorted_eigenvalues(self, A):
        """
        Sorts the eigenvalues of a matrix in ascending order.

        Args:
            E: 2 arrays of eigenvalues and eigenvectors

        Returns:
            A tuple of the sorted eigenvalues and the corresponding eigenvectors.
        """

        # Calculate the eigenvalues and eigenvectors of the matrix
        eigvals, eigvecs = np.linalg.eig(A)

        # Sort the eigenvalues in ascending order
        idx = np.argsort(eigvals)
        sorted_eigvals = eigvals[idx]
        sorted_eigvecs = eigvecs[:, idx]

        return sorted_eigvals, sorted_eigvecs

    def get_fiedler_eigenvalues(self, L):
        eigvals, eigvecs = self.get_sorted_eigenvalues(L)
        i = 1
        # while eigvals[i] == 0:
        #     i += 1
        return eigvals[i], eigvecs[i]

    def get_algebraic_connectivity(self, G):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            L = np.array(nx.laplacian_matrix(G).todense())  # gets us the graph laplacian
        # find fiedler eigenvalues
        feigval, feigvec = self.get_fiedler_eigenvalues(L)
        return feigval, None, np.abs(feigvec)

        # return nx.algebraic_connectivity(G)

    '''Measures of Homophily'''
    def get_ei_homophily_index(self, G, popularities):
        # Get the number of nodes and edges
        U = self.directed_to_undirected(G)
        num_nodes = U.number_of_nodes()

        # Initialize variables to store the total number of edges and homophilic edges
        total_edges = 0
        homophilic_edges = 0

        # Loop through all pairs of nodes edges (excluding self-loops)
        for i in range(num_nodes):
            for j in nx.neighbors(U, i):
                if i != j:
                    if (np.max(popularities) - np.min(popularities[j])) > 0:
                        homophilic_edges += 1 - np.abs(popularities[i] - popularities[j]) / (np.max(popularities) - np.min(popularities))
                        total_edges += 1

        # Calculate the EI homophily index
        if total_edges > 0:
            ei_index = homophilic_edges / total_edges
        else:
            ei_index = 1

        return ei_index

    def get_heterogeneity_index(self, G, popularities):
        U = self.directed_to_undirected(G)
        A = np.array(nx.to_numpy_matrix(U))
        n = nx.number_of_nodes(U)
        k = U.degree(np.arange(n), weight='weight')

        m = np.sum(k)
        k_avg = np.sum(k) / n

        # Calculate the numerator
        numerator = 0
        for i in range(n):
            for j in range(n):
                if A[i][j] != 0:
                    wij = A[i][j]
                    ki = k[i]
                    kj = k[j]
                    numerator += (wij - (ki * kj) / m) * (ki - k_avg) * (kj - k_avg)

        # Calculate the denominator
        denominator = 0
        for i in range(n):
            denominator += (k[i] - k_avg) ** 2

        # Calculate HE
        return numerator / denominator

    def get_degree_assortativity(self, G):
        U = self.directed_to_undirected(G)
        return nx.degree_assortativity_coefficient(U, weight='weight')

    def get_popularity_assortativity(self, G, popularities):
        # Calculate average and variance of the attribute
        avg_x = np.mean([popularities[node] for node in G.nodes()])
        var_x = np.var([popularities[node] for node in G.nodes()])

        # Calculate the numerator and denominator of the formula
        numerator = 0
        denominator = 0
        for i, j in G.edges():
            xi = popularities[i]
            xj = popularities[j]
            numerator += (xi - avg_x) * (xj - avg_x)
            denominator += 1

        # Calculate the assortativity coefficient
        r = 0
        if denominator * var_x != 0:
            r = numerator / (denominator * var_x)

        return r

    def remove_self_edges(self, G):
        A = nx.to_numpy_array(G)
        for i in range(G.number_of_nodes()):
            A[i, i] = 0
        return nx.from_numpy_array(A, create_using=type(G))


    '''Measures of Community'''
    def get_reciprocity(self, G):
        G = self.remove_self_edges(G)
        if G.number_of_edges() == 0:
            return 0

        return nx.reciprocity(G)

    def get_transitivity(self, G):
        G = self.remove_self_edges(G)
        return nx.transitivity(G)

    def get_clustering(self, G, weight=None):
        G = self.remove_self_edges(G)
        return self.__get_average__(nx.clustering(G, weight))

    @staticmethod
    def directed_to_undirected(G, average=False):
        A = np.array(nx.to_numpy_array(G))
        if average:
            A = np.average([A, A.T], axis=0)  # use average distance
        else:
            A = np.min([A, A.T], axis=0)  # use min distance
        return nx.from_numpy_array(A)

    # def get_modularity(self, G, communities, weight='weight', modularity_function='default'):
    #     U = self.directed_to_undirected(G)
    #     if modularity_function == 'default':
    #         return louvain_modularity.modularity_nx(U, communities, weight=weight)
    #     if modularity_function == 'custom':
    #         return louvain_modularity.modularity_custom(U, communities, weight=weight)
    #     if modularity_function == 'leskovec':
    #         return louvain_modularity.modularity_leskovec(U, communities, weight=weight)
    #     if modularity_function == 'karrer':
    #         return louvain_modularity.modularity_karrer(U, communities, weight=weight)
    #     if modularity_function == 'xu':
    #         return louvain_modularity.modularity_xu(U, communities, weight=weight)
    #     return None

    def get_communities(self, G, weight='weight', modularity_function='custom', average=False):
        U = self.directed_to_undirected(G, average=average)
        return louvain_modularity.louvain_communities(U, weight=weight, modularity_function=modularity_function)

    def get_louvain_modularity(self, G, weight='weight', average=False):
        U = self.directed_to_undirected(G, average=average)
        communities = louvain_modularity.louvain_communities(U, weight=weight, modularity_function='default')
        return louvain_modularity.modularity(U, communities, weight=weight, modularity_function='default')

    def get_signed_louvain_modularity(self, G, weight='weight', modularity_function='custom', average=False):
        U = self.directed_to_undirected(G, average=average)
        communities = louvain_modularity.louvain_communities(U, modularity_function=modularity_function, weight=weight)
        # print(louvain_modularity.modularity_custom(U, communities, weight=weight))
        return louvain_modularity.modularity(U, communities, modularity_function=modularity_function, weight=weight)

    '''Measures of Persistence'''
    def get_degree_persistence(self, PG, G):
        PK = self.get_in_degree(PG, weight='weight')[-1]
        K = self.get_in_degree(G, weight='weight')[-1]

        delta_k = np.abs(PK / 14 - K / 14)

        # print(np.max(delta_k))

        return np.mean(delta_k), None, delta_k

    @staticmethod
    def cosine_similarity(x, y):
        # Compute the magnitude (or length) of each vector
        x_mag = np.sqrt(np.sum(np.square(x)))
        y_mag = np.sqrt(np.sum(np.square(y)))

        # Compute the dot product of the two vectors
        dot_product = np.dot(x / x_mag, y / y_mag)

        # Compute the cosine similarity between the vectors
        similarity = dot_product

        return similarity

    def get_edge_persistence(self, PG, G):
        PA = np.array(nx.to_numpy_array(PG))
        A = np.array(nx.to_numpy_array(G))
        pa_s = PA.flatten()
        a_s = A.flatten()
        cs = []
        for pa, a in zip(PA, A):
            cs += [self.cosine_similarity(pa, a)]

        return self.cosine_similarity(pa_s, a_s), None, np.array(cs)

    def get_connectivity_persistence(self, PG, G):
        pass

    def get_robustness(self, PG, G):
        pass

    def get_community_persistence(self, PG, G):
        pg_communities = self.get_communities(PG)
        g_communities = self.get_communities(G)

        # im not sure how to align communities

        # return len(set.intersection(pg_set, g_set)) / len(set.union(pg_set, g_set))
        return None

    def get_modularity_persistence(self, PG, G, modularity_function='custom'):
        pg_communities = self.get_communities(PG)
        g_communities = self.get_communities(G)

        pg_modularity = louvain_modularity.modularity(PG, pg_communities, modularity_function=modularity_function)
        pg_g_modularity = louvain_modularity.modularity(PG, g_communities, modularity_function=modularity_function)

        g_modularity = louvain_modularity.modularity(G, g_communities, modularity_function=modularity_function)
        g_pg_modularity = louvain_modularity.modularity(G, pg_communities, modularity_function=modularity_function)

        return np.abs(pg_modularity - g_pg_modularity) + np.abs(g_modularity - pg_g_modularity)
        # return np.abs(pg_modularity - pg_g_modularity) + np.abs(g_modularity - g_pg_modularity)

    def print_metrics(self, trial=0, human_study=False):
        metrics = self.get_metrics()
        for metric in metrics:
            print(metric[0], metric[1])
            if human_study:
                np.save(config.DATAPATH + "networkAnalysis/" + self.outfile + "_" + self.name + "_" + metric[0] + '.npy', metric[1])
                # if np.size(metric) > 3:
                #     np.save(config.DATAPATH + "networkAnalysis/" + self.outfile + "_" + self.name + "_" + metric[0] + '_full.npy', metric[3])
            else:
                np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + str(trial) + '/' + self.outfile + "_" + self.name + "_" + metric[0] + '.npy', metric[1])

    def print_pop_metrics(self, trial=0, human_study=False, humans=None):
        x = np.arange(len(self.popularities[:, 0]))
        absolute_popularities = self.popularities
        relative_popularities = self.popularities / np.stack(
            [np.average(self.popularities, axis=1)] * self.popularities.shape[1]).T
        if human_study:
            human_pop = []
            bot_pop = []
            for i in range(absolute_popularities.shape[1]):
                if humans[i] == "Human":
                    human_pop += [absolute_popularities[:,i]]
                else:
                    bot_pop += [absolute_popularities[:,i]]

            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + self.outfile + "_" + self.name +
                    "_" + "Absolute Popularities" + '.npy', absolute_popularities)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + self.outfile + "_" + self.name +
                    "_" + "humanAbsolute Popularities" + '.npy', np.array(human_pop).T)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + self.outfile + "_" + self.name +
                    "_" + "botAbsolute Popularities" + '.npy', np.array(bot_pop).T)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + self.outfile + "_" + self.name +
                    "_" + "Relative Popularities" + '.npy', relative_popularities)
        else:
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + str(trial) + '/' + self.outfile + "_" + self.name +
                    "_" + "Absolute Popularities" + '.npy', absolute_popularities)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + str(trial) + '/' + self.outfile + "_" + self.name +
                    "_" + "Relative Popularities" + '.npy', relative_popularities)

    def get_metrics(self):
        metrics = []
        # Centrality Metrics
        if 'Degree' in self.included_metrics:
            metrics += [self.degree_vals]
        if 'Weighted Degree' in self.included_metrics:
            metrics += [self.degree_w_vals]
        if 'In-Degree' in self.included_metrics:
            metrics += [self.in_degree_vals]
        if 'Weighted In-Degree' in self.included_metrics:
            metrics += [self.in_degree_w_vals]
        if 'Out-Degree' in self.included_metrics:
            metrics += [self.out_degree_vals]
        if 'Weighted Out-Degree' in self.included_metrics:
            metrics += [self.out_degree_w_vals]
        if 'Average Neighbor Degree' in self.included_metrics:
            metrics += [self.average_neighbor_degree_vals]
        if 'Weighted Average Neighbor Degree' in self.included_metrics:
            metrics += [self.average_neighbor_degree_w_vals]
        if 'Eigenvector Centrality' in self.included_metrics:
            metrics += [self.eigenvector_centrality_vals]
        if 'Katz Centrality' in self.included_metrics:
            metrics += [self.katz_centrality_vals]

        # Connectivity Metrics
        if 'Density' in self.included_metrics:
            metrics += [self.density_vals]
        if 'Weighted Density' in self.included_metrics:
            metrics += [self.density_w_vals]
        if 'Node Connectivity' in self.included_metrics:
            metrics += [self.node_connectivity_vals]
        if 'Betweenness Centrality' in self.included_metrics:
            metrics += [self.betweenness_centrality_vals]
        if 'Closeness Centrality' in self.included_metrics:
            metrics += [self.closeness_centrality_vals]
        if 'Load Centrality' in self.included_metrics:
            metrics += [self.load_centrality_vals]
        if 'Algebraic Connectivity' in self.included_metrics:
            metrics += [self.algebraic_connectivity_vals]


        # Homophily Metrics
        if 'EI Homophily Index' in self.included_metrics:
            metrics += [self.ei_homophily_index_vals]
        if 'Heterogeneity Index' in self.included_metrics:
            metrics += [self.heterogeneity_index_vals]
        if 'Degree Assortativity' in self.included_metrics:
            metrics += [self.degree_assortativity_vals]
        if 'Popularity Assortativity' in self.included_metrics:
            metrics += [self.popularity_assortativity_vals]

        # Community Metrics
        if 'Reciprocity' in self.included_metrics:
            metrics += [self.reciprocity_vals]
        if 'Transitivity' in self.included_metrics:
            metrics += [self.transitivity_vals]
        if 'Clustering' in self.included_metrics:
            metrics += [self.clustering_vals]
        if 'Louvain Modularity' in self.included_metrics:
            metrics += [self.louvain_modularity_vals]
        if 'Signed Louvain Modularity Custom' in self.included_metrics:
            metrics += [self.signed_louvain_modularity_custom_vals]
        if 'Signed Louvain Modularity Leskovec' in self.included_metrics:
            metrics += [self.signed_louvain_modularity_leskovec_vals]
        if 'Signed Louvain Modularity Karrer' in self.included_metrics:
            metrics += [self.signed_louvain_modularity_karrer_vals]
        if 'Signed Louvain Modularity Xu' in self.included_metrics:
            metrics += [self.signed_louvain_modularity_xu_vals]

        # Persistence Metrics
        if 'Degree Persistence' in self.included_metrics:
            metrics += [self.degree_persistence_vals]
        if 'Edge Persistence' in self.included_metrics:
            metrics += [self.edge_persistence_vals]
        if 'Connectivity Persistence' in self.included_metrics:
            metrics += [self.connectivity_persistence_vals]
        if 'Robustness' in self.included_metrics:
            metrics += [self.robustness_vals]
        if 'Community Persistence' in self.included_metrics:
            metrics += [self.community_persistence_vals]
        if 'Modularity Persistence' in self.included_metrics:
            metrics += [self.modularity_persistence_vals]

        return metrics

    @staticmethod
    def get_pos_graph(G):
        A = nx.to_numpy_array(G)
        A[A < 0] = 0
        # np.fill_diagonal(A, 20)
        G_pos = nx.from_numpy_array(A.astype(int), create_using=nx.DiGraph)
        return G_pos

    @staticmethod
    def get_neg_graph(G):
        A = nx.to_numpy_array(G)
        A[A > 0] = 0
        A *= -1
        G_neg = nx.from_numpy_array(A.astype(int), create_using=nx.DiGraph)
        return G_neg

    def get_dual_graph(self, G):
        A = np.array(nx.to_numpy_array(G))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            A[A < 0] = 0
            B = 1 / A
            B[B < 0] = 0
            B[B > 1] = 0
            # B[B > 5] = 0
            G_duel = nx.from_numpy_array(B, create_using=nx.DiGraph)
            G_duel = self.directed_to_undirected(G_duel, True)
        return G_duel

    def update_metrics(self, G, popularities, PG=None):
        G_pos = self.get_pos_graph(G)
        G_neg = self.get_neg_graph(G)
        G_duel = self.get_dual_graph(G)

        if PG is not None:
            PG_pos = self.get_pos_graph(PG)
            PG_neg = self.get_neg_graph(PG)
            PG_rev = self.get_dual_graph(PG)
        else:
            PG_pos = None
            PG_neg = None
            PG_rev = None

        average_popularity = (np.average(nx.to_numpy_array(G_pos))) / 2

        # Centrality Metrics
        if 'Degree' in self.included_metrics:
            self.degree_vals = self.add_to_list(self.degree_vals, self.get_degree(G_pos))
        if 'Weighted Degree' in self.included_metrics:
            self.degree_w_vals = self.add_to_list(self.degree_w_vals, self.get_degree(G_pos, weight='weight',
                                                                  popularity=average_popularity))
        if 'In-Degree' in self.included_metrics:
            self.in_degree_vals = self.add_to_list(self.in_degree_vals, self.get_in_degree(G_pos))
        if 'Weighted In-Degree' in self.included_metrics:
            self.in_degree_w_vals = self.add_to_list(self.in_degree_w_vals,
                                                     self.get_in_degree(G_pos, weight='weight'))
        if 'Out-Degree' in self.included_metrics:
            self.out_degree_vals = self.add_to_list(self.out_degree_vals, self.get_out_degree(G_pos))
        if 'Weighted Out-Degree' in self.included_metrics:
            self.out_degree_w_vals = self.add_to_list(self.out_degree_w_vals,
                                                      self.get_out_degree(G_pos, weight='weight'))
        if 'Average Neighbor Degree' in self.included_metrics:
            self.average_neighbor_degree_vals = self.add_to_list(self.average_neighbor_degree_vals,
                                                                 self.get_average_neighbor_degree(G_pos))
        if 'Weighted Average Neighbor Degree' in self.included_metrics:
            self.average_neighbor_degree_w_vals = self.add_to_list(self.average_neighbor_degree_w_vals,
                                                                   self.get_average_neighbor_degree(G_pos,
                                                                                                    weight='weight'))
        if 'Eigenvector Centrality' in self.included_metrics:
            self.eigenvector_centrality_vals = self.add_to_list(self.eigenvector_centrality_vals,
                                                                self.get_eigenvector_centrality(G_pos))
        if 'Katz Centrality' in self.included_metrics:
            self.katz_centrality_vals = self.add_to_list(self.katz_centrality_vals, self.get_katz_centrality(G_pos))
        if 'Load Centrality' in self.included_metrics:
            self.load_centrality_vals = self.add_to_list(self.load_centrality_vals, self.get_load_centrality(G_pos))

        # Connectivity Metrics
        if 'Density' in self.included_metrics:
            self.density_vals = self.add_to_list(self.density_vals, self.get_density(G_pos))
        if 'Weighted Density' in self.included_metrics:
            self.density_w_vals = self.add_to_list(self.density_w_vals, self.get_density(G_pos, weight='weight'))
        if 'Node Connectivity' in self.included_metrics:
            self.node_connectivity_vals = self.add_to_list(self.node_connectivity_vals,
                                                           self.get_node_connectivity(G_pos))
        # Vulnerability Metrics
        # if 'Inverse' in self.included_metrics:
        #     self.density_w_vals = self.add_to_list(self.density_w_vals, self.get_density(G_pos, weight='weight'))
        if 'Betweenness Centrality' in self.included_metrics:
            self.betweenness_centrality_vals = self.add_to_list(self.betweenness_centrality_vals,
                                                                self.get_betweenness_centrality(G_duel))
        if 'Closeness Centrality' in self.included_metrics:
            self.closeness_centrality_vals = self.add_to_list(self.closeness_centrality_vals,
                                                              self.get_closeness_centrality(G_duel))
        if 'Algebraic Connectivity' in self.included_metrics:
            self.algebraic_connectivity_vals = self.add_to_list(self.algebraic_connectivity_vals,
                                                              self.get_algebraic_connectivity(G_duel))

        # Homophily Metrics
        if 'EI Homophily Index' in self.included_metrics:
            self.ei_homophily_index_vals = self.add_to_list(self.ei_homophily_index_vals,
                                                            self.get_ei_homophily_index(G_pos, popularities))
        if 'Heterogeneity Index' in self.included_metrics:
            self.heterogeneity_index_vals = self.add_to_list(self.heterogeneity_index_vals,
                                                             self.get_heterogeneity_index(G_pos, popularities))
        if 'Degree Assortativity' in self.included_metrics:
            self.degree_assortativity_vals = self.add_to_list(self.degree_assortativity_vals,
                                                             self.get_degree_assortativity(G_pos))
        if 'Popularity Assortativity' in self.included_metrics:
            self.popularity_assortativity_vals = self.add_to_list(self.popularity_assortativity_vals,
                                                             self.get_popularity_assortativity(G_pos, popularities))

        # Community Metrics
        if 'Reciprocity' in self.included_metrics:
            self.reciprocity_vals = self.add_to_list(self.reciprocity_vals, self.get_reciprocity(G_pos))
        if 'Transitivity' in self.included_metrics:
            self.transitivity_vals = self.add_to_list(self.transitivity_vals, self.get_transitivity(G_pos))
        if 'Clustering' in self.included_metrics:
            self.clustering_vals = self.add_to_list(self.clustering_vals, self.get_clustering(G_pos))
        if 'Louvain Modularity' in self.included_metrics:
            self.louvain_modularity_vals = self.add_to_list(self.louvain_modularity_vals,
                                                            self.get_louvain_modularity(G_pos))
        if 'Signed Louvain Modularity Custom' in self.included_metrics:
            self.signed_louvain_modularity_custom_vals = self.add_to_list(self.signed_louvain_modularity_custom_vals,
                                                            self.get_signed_louvain_modularity(G, 'weight', 'custom'))
        if 'Signed Louvain Modularity Leskovec' in self.included_metrics:
            self.signed_louvain_modularity_leskovec_vals = self.add_to_list(self.signed_louvain_modularity_leskovec_vals,
                                                            self.get_signed_louvain_modularity(G, 'weight', 'leskovec'))
        if 'Signed Louvain Modularity Karrer' in self.included_metrics:
            self.signed_louvain_modularity_karrer_vals = self.add_to_list(self.signed_louvain_modularity_karrer_vals,
                                                            self.get_signed_louvain_modularity(G, 'weight', 'karrer'))
        if 'Signed Louvain Modularity Xu' in self.included_metrics:
            self.signed_louvain_modularity_xu_vals = self.add_to_list(self.signed_louvain_modularity_xu_vals,
                                                            self.get_signed_louvain_modularity(G, 'weight', 'xu'))

        # Persistence Metrics
        if 'Degree Persistence' in self.included_metrics and PG is not None:
            self.degree_persistence_vals = self.add_to_list(self.degree_persistence_vals,
                                                            self.get_degree_persistence(PG, G))
        if 'Edge Persistence' in self.included_metrics and PG is not None:
            self.edge_persistence_vals = self.add_to_list(self.edge_persistence_vals,
                                                          self.get_edge_persistence(PG_pos, G_pos))
        if 'Connectivity Persistence' in self.included_metrics and PG_pos is not None:
            self.connectivity_persistence_vals = self.add_to_list(self.connectivity_persistence_vals,
                                                                  self.get_connectivity_persistence(PG_pos, G_pos))
        if 'Robustness' in self.included_metrics and PG is not None:
            self.robustness_vals = self.add_to_list(self.robustness_vals, self.get_robustness(PG_pos, G_pos))
        if 'Community Persistence' in self.included_metrics and PG is not None:
            self.community_persistence_vals = self.add_to_list(self.community_persistence_vals,
                                                               self.get_community_persistence(PG_pos, G_pos))
        if 'Modularity Persistence' in self.included_metrics and PG is not None:
            self.modularity_persistence_vals = self.add_to_list(self.modularity_persistence_vals,
                                                                self.get_modularity_persistence(PG_pos, G_pos))
        # nx.voterank(G)
        # get_shortest_path(G)
        # get_average_degree_connectivity(G)

    def print_popularity_plot(self, title):
        x = np.arange(len(self.popularities[:, 0]))
        # print(metric[0])
        # plt.plot(x, metric[1], color='b', label=metric[0])

        relative_popularities = self.popularities / np.stack([np.average(self.popularities, axis=1)] * self.popularities.shape[1]).T
        # plt.plot(x, self.popularities, linestyle='dashed')
        plt.plot(x, relative_popularities, linestyle='dashed')
        # plt.plot(x, np.max(self.popularities, axis=1), linestyle='dashed')
        # plt.plot(x, self.popularities, linestyle='dashed', label=np.arange(7))
        # plt.legend()

        plt.title('Relative Popularities')
        # plt.legend()
        plt.xlabel('Round')
        plt.ylabel('Popularity')
        plt.savefig('networkAnalysis/' + title + ' Relative Popularities')
        # plt.show()
        plt.close()
        # plt.clf()
        # print(self.popularities)
        return relative_popularities

    def print_abs_popularity_plot(self, title):
        x = np.arange(len(self.popularities[:, 0]))
        # print(metric[0])
        # plt.plot(x, metric[1], color='b', label=metric[0])

        absolute_popularities = self.popularities
        # plt.plot(x, self.popularities, linestyle='dashed')
        plt.plot(x, absolute_popularities, linestyle='dashed')
        # plt.plot(x, np.max(self.popularities, axis=1), linestyle='dashed')
        # plt.plot(x, self.popularities, linestyle='dashed', label=np.arange(7))
        # plt.legend()

        plt.title('Absolute Popularities')
        # plt.legend()
        plt.xlabel('Round')
        plt.ylabel('Popularity')
        plt.savefig('networkAnalysis/' + title + ' Absolute Popularities')
        # plt.show()
        plt.close()
        # plt.clf()
        # print(self.popularities)
        return absolute_popularities

    def print_metric_plots(self, title):
        metrics = self.get_metrics()
        for i, metric in enumerate(metrics):
            x = np.arange(len(metrics[i][1]))
            # print(metric[0])
            if len(metric) == 4 and None not in metric[1]:
                plt.plot(x, metric[1], color='b', label=metric[0])
                # plt.plot(x, np.min(metric[3], axis=1), color='b', linestyle='dashed')
                # plt.plot(x, np.max(metric[3], axis=1), color='b', linestyle='dashed')
                plt.plot(x, metric[3], linestyle='dashed', label=np.arange(metric[3][0].shape[0]))
                # plt.legend()

            elif len(metric) == 2 and None not in metric[1]:
                plt.plot(x, metric[1], color='b', label=metric[0])
            plt.title(self.name + ' ' + metric[0])
            # plt.legend()
            plt.xlabel('Round')
            plt.ylabel(metric[0])
            plt.savefig('networkAnalysis/' + title + ' ' + metric[0])
            # plt.show()
            plt.close()
            # plt.clf()

    def get_giving_matrix(self):
        all_graphs = []
        for graph in self.graphs:
            x = nx.to_numpy_array(graph).clip(min=0)
            x[np.diag_indices_from(x)] = 0
            all_graphs.append(x)
        return np.array(all_graphs)

    def get_keeping_matrix(self):
        all_graphs = []
        for graph in self.graphs:
            x = nx.to_numpy_array(graph)
            all_graphs.append(np.diag(x))
        return np.array(all_graphs)

    def get_taking_matrix(self):
        all_graphs = []
        for graph in self.graphs:
            x = nx.to_numpy_array(graph).clip(max=0)
            x[np.diag_indices_from(x)] = 0
            all_graphs.append(x)
        return np.array(all_graphs)

    def print_transactions(self, trial, human_study=False, humans=None):
        giving = self.get_giving_matrix()
        keeping = self.get_keeping_matrix()
        taking = self.get_taking_matrix()
        if human_study:
            human_ids, bot_ids = [], []
            for i, human in enumerate(humans):
                if humans[i] == "Human":
                    human_ids.append(i)
                else:
                    bot_ids.append(i)

            human_giving, bot_giving = giving[:, human_ids], giving[:, bot_ids]
            human_keeping, bot_keeping = keeping[:, human_ids], keeping[:, bot_ids]
            human_taking, bot_taking = taking[:, human_ids], taking[:, bot_ids]

            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_Giving" + '.npy', giving)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_humanGiving" + '.npy', human_giving)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_botGiving" + '.npy', bot_giving)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_Keeping" + '.npy', keeping)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_humanKeeping" + '.npy', human_keeping)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_botKeeping" + '.npy', bot_keeping)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_Taking" + '.npy', taking)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_humanTaking" + '.npy', human_taking)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + '/' + self.outfile + "_" + self.name + "_botTaking" + '.npy', bot_taking)
        else:
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + str(trial) + '/' + self.outfile + "_" + self.name + "_Giving" + '.npy', giving)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + str(trial) + '/' + self.outfile + "_" + self.name + "_Keeping" + '.npy', keeping)
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + str(trial) + '/' + self.outfile + "_" + self.name + "_Taking" + '.npy', taking)

    def create_combine_graph(self):
        transactions = []
        for graph in self.graphs:
            transactions += [nx.to_numpy_array(graph)]

        transactions = np.array(transactions)

        weighted_transactions = np.zeros_like(transactions)
        for r in range(transactions.shape[0]):
            for i in range(transactions.shape[1]):
                for j in range(transactions.shape[2]):
                    if (i == j):
                        weighted_transactions[r][i][j] = 0
                    elif transactions[r][i][j] >= 0:
                        weighted_transactions[r][i][j] = transactions[r][i][j] * self.popularities[r][i] * self.give_coefficient
                    elif transactions[r][i][j] < 0:
                        weighted_transactions[r][i][j] = transactions[r][i][j] * self.popularities[r][i] * self.take_coefficient

        weighted_transactions[weighted_transactions < 0] = 0
        single_weighted_graph = np.sum(weighted_transactions, axis=0)
        return single_weighted_graph / np.sum(single_weighted_graph)

    def create_combine_graph_evolution(self, start_round=None, end_round=None, remove_negative=True):
        transactions = []
        for graph in self.graphs:
            transactions += [nx.to_numpy_array(graph)]

        if start_round is not None and end_round is not None:
            transactions = np.array(transactions)[start_round:end_round]
            popularities = np.array(self.popularities)[start_round:end_round]
        else:
            transactions = np.array(transactions)
            popularities = np.array(self.popularities)

        weighted_transactions = np.zeros_like(transactions)
        for r in range(transactions.shape[0]):
            for i in range(transactions.shape[1]):
                for j in range(transactions.shape[2]):
                    if (i == j):
                        weighted_transactions[r][i][j] = transactions[r][i][j] * popularities[r][i] * self.keep_coefficient
                    elif transactions[r][i][j] >= 0:
                        weighted_transactions[r][i][j] = transactions[r][i][j] * popularities[r][i] * self.give_coefficient
                    elif transactions[r][i][j] < 0:
                        weighted_transactions[r][i][j] = transactions[r][i][j] * popularities[r][i] * self.take_coefficient

        if remove_negative:
            weighted_transactions[weighted_transactions < 0] = 0

        weighted_evolution_graph, window_length = [], 1
        for i in range(len(weighted_transactions) - window_length + 1):
            tmp_graph = np.sum(weighted_transactions[i:i + window_length], axis=0)
            tmp_graph = tmp_graph / np.sum(np.absolute(tmp_graph))
            weighted_evolution_graph += [tmp_graph]

        single_weighted_graph = np.sum(weighted_transactions, axis=0)
        return single_weighted_graph / np.sum(np.absolute(single_weighted_graph)), weighted_evolution_graph

    def calculate_retaliations(self):
        transactions = []
        for graph in self.graphs:
            transactions += [nx.to_numpy_array(graph)]

        transactions = np.array(transactions)

        start_rounds = []
        end_rounds = []
        r = transactions.shape[0] - 1
        while r > 0:
            if np.min(transactions[r]) <= -0.001:
                end_rounds = [r] + end_rounds
                r -= 1
                while r >= 0 and np.min(transactions[r]) <= -0.001:
                    r -= 1
                start_rounds = [r + 1] + start_rounds
            r -= 1

        num_players = transactions.shape[1]
        response_from_perp_to_victim = []
        response_from_victim_to_perp = []
        response_from_others_to_perp = []
        response_from_others_to_victim = []
        for start_round, end_round in zip(start_rounds, end_rounds):
            perpetrators = []
            victims = []
            for i in range(num_players):
                if np.min(transactions[start_round,i]) < 0:
                    perpetrators += [i]
                if np.min(transactions[start_round,:,i]) < 0:
                    victims += [i]
            summary_graph, _ = self.create_combine_graph_evolution(start_round, end_round, remove_negative=False)
            others = list(set(np.arange(num_players)) - set(perpetrators + victims))

            # Used to measure direct reciprocity
            for perp in perpetrators:
                for victim in victims:
                    response_from_perp_to_victim += [summary_graph[perp,victim]]
                    response_from_victim_to_perp += [summary_graph[victim,perp]]

            # Used to measure indirect reciprocity
            for other in others:
                for perp in perpetrators:
                    response_from_others_to_perp += [summary_graph[other,perp]]

                for victim in victims:
                    response_from_others_to_victim += [summary_graph[other,victim]]

        reciprocations_coeff = np.mean(response_from_victim_to_perp)
        weighted_reciprocations_coeff = 0
        retaliation_coeff = np.mean(response_from_perp_to_victim)
        weighted_retaliation_coeff = 0
        indirect_reciprocations_coeff =  np.mean(response_from_others_to_victim)
        weighted_indirect_reciprocations_coeff = 0
        indirect_retaliations_coeff = np.mean(response_from_others_to_perp)
        weighted_indirect_retaliations_coeff = 0

        return (reciprocations_coeff, weighted_reciprocations_coeff, retaliation_coeff, weighted_retaliation_coeff,
                indirect_reciprocations_coeff, weighted_indirect_reciprocations_coeff,
                indirect_retaliations_coeff, weighted_indirect_retaliations_coeff)


    def randr_function(self, receiver_amount, giver_amount):
        if giver_amount < 0:
            return [-(np.max(receiver_amount, 0) - giver_amount) / giver_amount]
        return [(receiver_amount - giver_amount) / giver_amount]



    def calculate_reciprocations_and_retaliations(self):
        transactions = []
        for graph in self.graphs:
            transactions += [nx.to_numpy_array(graph)]

        transactions = np.array(transactions)

        attack_mask = transactions.copy()
        attack_mask[attack_mask > -0.1] = 0 # remove givings
        # attack_mask[attack_mask < -0.1] = 1 # mask attacking

        giving_mask = transactions.copy()
        giving_mask[giving_mask < 0.1] = 0 # remove attacks
        # giving_mask[giving_mask > 0.1] = 1 # mask giving

        for r in np.arange(transactions.shape[0] - 1, -1, -1):
            for i in np.arange(transactions.shape[1] - 1, -1, -1):
                for j in np.arange(transactions.shape[2] - 2, -1, -1):
                    if i == j: # remove keeping
                        giving_mask[r][i][j] = 0
                        attack_mask[r][i][j] = 0

                    if (r > 0 and np.min(attack_mask[r-1]) <= -0.001) or (r > 1 and np.min(attack_mask[r-2]) >= -0.001):
                        attack_mask[r][i][j] = 0

        reciprocations, weighted_reciprocations = [], []
        retaliations, weighted_retaliations = [], []
        indirect_reciprocations, weighted_indirect_reciprocations = [], []
        indirect_retaliations, weighted_indirect_retaliations = [], []

        for r in range(transactions.shape[0] - 1):
            for i in range(transactions.shape[1]):
                for j in range(transactions.shape[2]):
                    if (i != j):
                        if giving_mask[r][i][j] > 0:
                            reciprocations += self.randr_function(transactions[r+1][i][j], transactions[r][i][j])
                            if self.popularities[r][i] > 0.001:
                                weighted_reciprocations += self.randr_function(transactions[r + 1][j][i] * self.popularities[r + 1][j], transactions[r][i][j] * self.popularities[r][i])

                            indirect_reciprocation, weighted_indirect_reciprocation = 0, 0
                            for k in range(transactions.shape[2]):
                                if k != i and k != j:
                                    indirect_reciprocation += transactions[r+1][i][k]
                                    weighted_indirect_reciprocation += transactions[r+1][i][k] * self.popularities[r][k]

                            indirect_reciprocation /= transactions.shape[2] - 2
                            weighted_indirect_reciprocation /= transactions.shape[2] - 2

                            indirect_reciprocations += self.randr_function(indirect_reciprocation, transactions[r][i][j])
                            if self.popularities[r][i] > 0.001:
                                weighted_indirect_reciprocations += self.randr_function(weighted_indirect_reciprocation, transactions[r][i][j] * self.popularities[r][i])

                        if attack_mask[r][i][j] < 0:
                            retaliations += self.randr_function(transactions[r+1][j][i], transactions[r][i][j])
                            if self.popularities[r][i] > 0.001:
                                weighted_retaliations += self.randr_function(transactions[r+1][j][i] * self.popularities[r+1][j], transactions[r][i][j] * self.popularities[r][i])

                            indirect_retaliation, weighted_indirect_retaliation = 0, 0
                            for k in range(transactions.shape[2]):
                                if k != i and k != j:
                                    indirect_retaliation += transactions[r + 1][i][k]
                                    weighted_indirect_retaliation += transactions[r + 1][i][k] * self.popularities[r][k]

                            indirect_retaliation /= transactions.shape[2] - 2
                            weighted_indirect_retaliation /= transactions.shape[2] - 2

                            indirect_retaliations += self.randr_function(indirect_retaliation, transactions[r][i][j])
                            if self.popularities[r][i] > 0.001:
                                weighted_indirect_retaliations += self.randr_function(weighted_indirect_retaliation, transactions[r][i][j] * self.popularities[r][i])

        reciprocations_coeff = np.sum(reciprocations) / len(reciprocations)
        weighted_reciprocations_coeff = np.sum(weighted_reciprocations) / len(weighted_reciprocations)
        indirect_reciprocations_coeff = np.sum(indirect_reciprocations) / len(indirect_reciprocations)
        weighted_indirect_reciprocations_coeff = np.sum(weighted_indirect_reciprocations) / len(weighted_indirect_reciprocations)
        if len(retaliations) > 0:
            retaliation_coeff = np.sum(retaliations) / len(retaliations)
            weighted_retaliation_coeff = np.sum(weighted_retaliations) / len(weighted_retaliations)
            indirect_retaliations_coeff = np.sum(indirect_reciprocations) / len(indirect_reciprocations)
            weighted_indirect_retaliations_coeff = np.sum(weighted_indirect_reciprocations) / len(weighted_indirect_reciprocations)
        else:
            retaliation_coeff = -999
            weighted_retaliation_coeff = -999
            indirect_retaliations_coeff = -999
            weighted_indirect_retaliations_coeff = -999

        return (reciprocations_coeff, weighted_reciprocations_coeff, retaliation_coeff, weighted_retaliation_coeff,
                indirect_reciprocations_coeff, weighted_indirect_reciprocations_coeff,
                indirect_retaliations_coeff, weighted_indirect_retaliations_coeff)

    def compute_weighted_density(self, A):
        """
        Compute the weighted density of a directed weighted graph.

        Parameters:
            A (numpy.ndarray): Weighted adjacency matrix (NxN).

        Returns:
            float: Weighted density of the graph.
        """
        N = A.shape[0]
        if N < 2:
            return 0  # A single node or empty graph has density 0

        total_weight = np.sum(A)  # Sum of all edge weights
        max_edges = N * (N - 1)  # Maximum possible edges (no self-loops)

        return total_weight / max_edges

    def edge_weight_entropy(self, A):
        """
        Compute entropy for each node based on its edge weight distribution.

        Parameters:
            A (numpy.ndarray): Weighted adjacency matrix (NxN).

        Returns:
            dict: Entropy per node and average entropy for the graph.
        """
        N = A.shape[0]
        entropy_values = np.zeros(N)

        for i in range(N):
            total_weight = np.sum(A[i])
            if total_weight == 0:
                continue  # No outgoing edges → entropy is 0

            probs = A[i] / total_weight  # Normalize to get probability distribution
            entropy_values[i] = -np.sum(probs[probs > 0] * np.log(probs[probs > 0]))  # Avoid log(0)

        return entropy_values

    def normalized_edge_weight_entropy(self, A):
        """
        Compute normalized entropy for each node based on its edge weight distribution.

        Parameters:
            A (numpy.ndarray): Weighted adjacency matrix (NxN).

        Returns:
            dict: Normalized entropy per node and average normalized entropy for the graph.
        """
        A[A<0] = 0
        N = A.shape[0]
        entropy_values = np.zeros(N)
        normalized_values = np.zeros(N)

        for i in range(N):
            total_weight = np.sum(A[i])
            k = np.count_nonzero(A[i])  # Number of neighbors with weight > 0

            if total_weight == 0 or k == 1:
                continue  # No outgoing edges or only one → entropy is 0

            probs = A[i] / total_weight  # Normalize to probability distribution
            H = -np.sum(probs[probs > 0] * np.log(probs[probs > 0]))  # Compute entropy
            H_max = np.log(k)  # Maximum entropy

            entropy_values[i] = H
            normalized_values[i] = H / H_max if H_max > 0 else 0  # Normalize

        return normalized_values

    def weighted_average_clustering2(self, A):
        G = nx.DiGraph(A)
        return nx.average_clustering(G, weight="weight")

    # def weighted_average_clustering(self, A, include_entropy=False):
    #     """
    #     Compute the weighted average clustering coefficient for a directed weighted adjacency matrix A.
    #
    #     Parameters:
    #         A (numpy.ndarray): A square weighted adjacency matrix (NxN).
    #
    #     Returns:
    #         float: Weighted global clustering coefficient
    #         list: Weighted local clustering coefficients for each node
    #     """
    #     if include_entropy:
    #         entropies = self.normalized_edge_weight_entropy(A)
    #     else:
    #         entropies = np.zeros(A.shape[0])
    #     num_nodes = A.shape[0]  # Number of nodes
    #     local_clustering_coefficients_w = np.zeros(num_nodes)  # Store local clustering coefficients
    #     global_clustering_coefficients_w = 0
    #
    #     global_triangle_weight_sum, global_num_possible_triangles = 0, 0
    #     for i in range(num_nodes):
    #         outgoing_neighbors = np.nonzero(A[i, :])[0]  # Get neighbors of node i
    #         incoming_neighbors = np.nonzero(A[:, i])[0]
    #         K_i = np.sum(np.append(A[i], A[:, i])) / (2 * num_nodes - 2) # average weighted in/out degree of player i
    #         # K_i = np.median(np.append(np.append(A[i], A[:, i]), [1, 1])) # average weighted in/out degree of player i
    #
    #         triangle_weight_sum, num_possible_triangles = 0, 0
    #         for j in outgoing_neighbors:
    #             for h in incoming_neighbors:
    #                 # A_hi = A[h, i] - K_i
    #                 # A_ij = A[i, j] - K_i
    #                 # A_jh = A[j, h] - K_i
    #                 A_hi = A[h, i]
    #                 A_ij = A[i, j]
    #                 A_jh = A[j, h]
    #                 if j != h and A_hi > 0 and A_ij > 0:
    #                     # triangle_weight_sum += (A[i, j] + A[i, h]) / 2
    #                     strength = np.min([A_hi, A_ij])
    #                     # if A_jh > 0:
    #                     #     triangle_weight_sum += strength
    #                     triangle_weight_sum += strength * (1 - entropies[h]) * max(0, min(1, (A_jh / strength)))
    #                     # triangle_weight_sum += strength * (1 - entropies[h]) * max(0, (A_jh - min(A_hi, A_ij)))
    #                     # triangle_weight_sum += strength * min(1, max(0, (A_jh * (1 - entropies[h])) / min(A_hi, A_ij)))
    #                     num_possible_triangles += strength
    #
    #                 # if j != h and A_hi < 0 and A_ij < 0:
    #                 #     # triangle_weight_sum += (A[i, j] + A[i, h]) / 2
    #                 #     # strength = np.mean([A_hi, A_ij])
    #                 #     triangle_weight_sum += strength * (1 - entropies[h]) * (A_jh - max(A_hi, A_ij))
    #                 #     # triangle_weight_sum += strength * min(1, max(0, (A_jh * (1 - entropies[h])) / min(A_hi, A_ij)))
    #                 #     num_possible_triangles += strength
    #
    #         global_triangle_weight_sum += triangle_weight_sum
    #         global_num_possible_triangles += num_possible_triangles
    #         if num_possible_triangles != 0:
    #             local_clustering_coefficients_w[i] = triangle_weight_sum / num_possible_triangles
    #
    #     if global_num_possible_triangles != 0:
    #         global_clustering_coefficients_w = global_triangle_weight_sum / global_num_possible_triangles
    #
    #     return global_clustering_coefficients_w, local_clustering_coefficients_w  # average clustering coefficient

    def weighted_average_clustering(self, A):
        """
        Compute the weighted directed clustering coefficient for a directed weighted adjacency matrix A using the geometric mean.

        Parameters:
            B (numpy.ndarray): A square weighted adjacency matrix (NxN).

        Returns:
            float: Weighted global clustering coefficient
            list: Weighted local clustering coefficients for each node
        """
        num_nodes = A.shape[0]
        B = A.copy()
        B[B < 0] = 0
        local_clustering_coefficients_w = np.zeros(num_nodes)
        global_triangle_weight_sum, global_num_triplets = 0, 0

        for i in range(num_nodes):
            triangle_weight_sum, num_triplets = 0, 0
            neighbors_out = np.nonzero(B[i, :])[0]
            neighbors_in = np.nonzero(B[:, i])[0]

            for j in neighbors_out:
                for k in neighbors_out:
                    if j != k and B[j, k] > 0:
                        # triangle_weight_sum += np.power(B[i, j] * B[i, k] * B[j, k], 1 / 3)
                        triangle_weight_sum += np.min([B[i, j], B[i, k]]) * np.min([1, B[j, k] / np.min([B[i, j], B[i, k]])])
                        # num_triplets += 1
                        num_triplets += np.min([B[i, j], B[i, k]])

                for k in neighbors_in:
                    if j != k and B[k, j] > 0:
                        # triangle_weight_sum += np.power(B[i, j] * B[k, i] * B[k, j], 1 / 3)
                        triangle_weight_sum += np.min([B[i, j], B[k, i]]) * np.min([1, B[k, j] / np.min([B[i, j], B[k, i]])])
                        # num_triplets += 1
                        num_triplets += np.min([B[i, j] * B[k, i]])

            for j in neighbors_in:
                for k in neighbors_in:
                    if j != k and B[j, k] > 0:
                        # triangle_weight_sum += np.power(B[j, i] * B[k, i] * B[j, k], 1 / 3)
                        triangle_weight_sum += np.min([B[j, i], B[k, i]]) * np.min([1, B[j, k] / np.min([B[j, i], B[k, i]])])
                        # num_triplets += 1
                        num_triplets += np.min([B[j, i], B[k, i]])

            global_triangle_weight_sum += triangle_weight_sum
            global_num_triplets += num_triplets
            if num_triplets > 0:
                local_clustering_coefficients_w[i] = triangle_weight_sum / num_triplets

        global_clustering_coefficient_w = global_triangle_weight_sum / global_num_triplets if global_num_triplets > 0 else 0
        return global_clustering_coefficient_w, local_clustering_coefficients_w

    def calculate_evolution_coeff(self, combined_graph_evolution, n):
        change_coeff = []
        for i in range(len(combined_graph_evolution) - n):
            change_coeff += [np.sum(np.absolute(combined_graph_evolution[i + n] - combined_graph_evolution[i]))]
        return np.mean(change_coeff)

    def save_summary_metric(self, result, metric, trial, human_study=False):
        if human_study:
            np.save(config.DATAPATH + "networkAnalysis/" + self.outfile + "_Summary" + self.name + "_" + metric + ".npy", result)
            # if np.size(metric) > 3:
            #     np.save(config.DATAPATH + "networkAnalysis/" + self.outfile + "_" + self.name + "_" + metric[0] + '_full.npy', metric[3])
        else:
            np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + str(trial) + '/' + self.outfile + "_Summary" + self.name + "_" + metric + ".npy", result)
        pass

    def calculate_reciprocity_coeff(self, combined_graph):
        combined_graph_pos = np.array(combined_graph)
        for i in range(combined_graph_pos.shape[0]):
            combined_graph_pos[i][i] = 0
        combined_graph_pos[combined_graph_pos < 0] = 0
        # combined_graph_pos /= np.sum(combined_graph_pos)

        reciprocity_graph = np.zeros_like(combined_graph_pos)
        for i in range(combined_graph_pos.shape[0]):
            for j in range(combined_graph_pos.shape[1]):
                if combined_graph_pos[i][j] > 0 and combined_graph_pos[j][i] > 0 and i != j:
                    reciprocity_graph[i][j] = min([1, combined_graph_pos[j][i] / combined_graph_pos[i][j]])

                # the_min = np.min([combined_graph_pos[i][j], combined_graph_pos[j][i]])
                # the_max = np.max([combined_graph_pos[i][j], combined_graph_pos[j][i]])
                # if the_max > 0 and the_min > 0 and i != j:
                #     reciprocity_graph[i][j] = the_min / the_max

        return np.sum(reciprocity_graph * combined_graph_pos)


    def calculate_reciprocity_coeff2_helper(self, graph1, graph2):
        graph1_pos = np.array(graph1)
        graph2_pos = np.array(graph2)
        for i in range(graph1_pos.shape[0]):
            graph1_pos[i][i] = 0
            graph2_pos[i][i] = 0

        graph1_pos[graph1_pos < 0] = 0
        graph2_pos[graph2_pos < 0] = 0
        if np.sum(graph1_pos) > 0:
            graph1_pos /= np.sum(graph1_pos)
            graph2_pos /= np.sum(graph1_pos)


        reciprocity_graph = np.zeros_like(graph1_pos)
        for i in range(graph1_pos.shape[0]):
            for j in range(graph1_pos.shape[1]):
                if graph2_pos[j][i] > 0 and graph1_pos[i][j] > 0 and i != j:
                    reciprocity_graph[i][j] = np.min([1, (graph2_pos[j][i]) / graph1_pos[i][j]])

        return np.sum(reciprocity_graph * graph1_pos)

        # reciprocity_graph = np.zeros_like(graph_pos)
        # for i in range(combined_graph_pos.shape[0]):
        #     for j in range(combined_graph_pos.shape[1]):
        #         the_min = np.min([combined_graph_pos[i][j], combined_graph_pos[j][i]])
        #         the_max = np.max([combined_graph_pos[i][j], combined_graph_pos[j][i]])
        #         if the_max > 0 and the_min > 0 and i != j:
        #             reciprocity_graph[i][j] = the_min / the_max

        # return np.sum(reciprocity_graph * combined_graph_pos)

    def calculate_reciprocity_coeff2(self, graphs):
        reciprocity_coeff = 0
        for i in range(len(graphs) - 1):
            reciprocity_coeff += self.calculate_reciprocity_coeff2_helper(graphs[i], graphs[i+1])
        return reciprocity_coeff / (len(graphs)-1)


    def print_modified_metrics(self, trial, human_study=False, humans=None, polarization=None):
        combined_graph, combined_graph_evolution = self.create_combine_graph_evolution(remove_negative=False)

        # reciprocity_graph[reciprocity_graph < 0] = 0
        reciprocity_coeff = self.calculate_reciprocity_coeff(combined_graph)
        self.save_summary_metric(reciprocity_coeff, "Reciprocity", trial, human_study)

        reciprocity_coeff = self.calculate_reciprocity_coeff2(combined_graph_evolution)
        self.save_summary_metric(reciprocity_coeff, "Reciprocity2", trial, human_study)

        # clustering_coeff, _ = self.weighted_average_clustering(combined_graph, include_entropy=False)
        # self.save_summary_metric(clustering_coeff, "Transitivity", trial, human_study)

        clustering_coeff, _ = self.weighted_average_clustering(combined_graph)
        self.save_summary_metric(clustering_coeff, "Clustering", trial, human_study)

        weighted_density = self.compute_weighted_density(combined_graph)
        self.save_summary_metric(weighted_density, "Density", trial, human_study)

        # weighted_indegree = self.compute

        average_entropy = []
        for i in range(len(combined_graph_evolution)):
            average_entropy += [self.normalized_edge_weight_entropy(combined_graph_evolution[i])]

        average_entropy = np.mean(average_entropy)
        self.save_summary_metric(np.mean(average_entropy), "Entropy Short Term", trial, human_study)

        node_entropies = self.normalized_edge_weight_entropy(combined_graph)
        self.save_summary_metric(np.mean(node_entropies), "Entropy", trial, human_study)

        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 1)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient1", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 2)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient2", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 3)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient3", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 4)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient4", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 5)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient5", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 6)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient6", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 7)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient7", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 8)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient8", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 9)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient9", trial, human_study)
        evolution_coeff = self.calculate_evolution_coeff(combined_graph_evolution, 10)
        self.save_summary_metric(np.mean(evolution_coeff), "Evolution Coefficient10", trial, human_study)


        (reciprocations_coeff, weighted_reciprocations_coeff, retaliation_coeff, weighted_retaliation_coeff,
         indirect_reciprocation_coeff, weighted_indirect_reciprocation_coeff, indirect_retaliation_coeff,
         weighted_indirect_retaliation_coeff) = self.calculate_retaliations()

        self.save_summary_metric(np.mean(reciprocations_coeff), "Reciprocations Coefficient", trial, human_study)
        self.save_summary_metric(np.mean(weighted_reciprocations_coeff), "Weighted Reciprocations Coefficient", trial, human_study)
        self.save_summary_metric(np.mean(retaliation_coeff), "Retaliations Coefficient", trial, human_study)
        self.save_summary_metric(np.mean(weighted_retaliation_coeff), "Weighted Retaliations Coefficient", trial, human_study)

        self.save_summary_metric(np.mean(indirect_reciprocation_coeff), "Indirect Reciprocations Coefficient", trial, human_study)
        self.save_summary_metric(np.mean(weighted_indirect_reciprocation_coeff), "Weighted Indirect Reciprocations Coefficient", trial, human_study)
        self.save_summary_metric(np.mean(indirect_retaliation_coeff), "Indirect Retaliations Coefficient", trial, human_study)
        self.save_summary_metric(np.mean(weighted_indirect_retaliation_coeff), "Weighted Indirect Retaliations Coefficient", trial, human_study)

        if polarization is not None:
            if human_study:
                np.save(config.DATAPATH + "networkAnalysis/" + self.outfile + "_Influence_Polarization.npy", polarization)
            else:
                np.save(config.DATAPATH_SIMULATED + "networkAnalysis/" + str(trial) + '/' + self.outfile + "_Influence_Polarization.npy", polarization)

        # human_only_combined_graph = np.zeros_like(combined_graph)
        # bot_only_combined_graph = np.zeros_like(combined_graph)
        # human_bot_combined_graph = np.zeros_like(combined_graph)
        # if human_study:
        #     for i in range(combined_graph.shape[0]):
        #         for j in range(combined_graph.shape[1]):
        #             if humans[i] == "Human" and humans[j] == "Human":
        #                 human_only_combined_graph[i][j] = combined_graph[i][j]
        #             elif humans[i] != "Human" and humans[j] != "Human":
        #                 bot_only_combined_graph[i][j] = combined_graph[i][j]
        #             else:
        #                 human_bot_combined_graph[i][j] = combined_graph[i][j]
        #
        # human_only_combined_graph /= np.sum(human_only_combined_graph)
        # bot_only_combined_graph /= np.sum(bot_only_combined_graph)
        # human_bot_combined_graph /= np.sum(human_bot_combined_graph)
        #
        # human_reciprocity_coeff = np.sum(reciprocity_graph * human_only_combined_graph)
        # bot_reciprocity_coeff = np.sum(reciprocity_graph * bot_only_combined_graph)
        # human_bot_reciprocity_coeff = np.sum(reciprocity_graph * human_bot_combined_graph)
        #
        # self.save_summary_metric(human_reciprocity_coeff, "humanReciprocity", trial, human_study)
        # self.save_summary_metric(bot_reciprocity_coeff, "botReciprocity", trial, human_study)
        # self.save_summary_metric(human_bot_reciprocity_coeff, "humanBotReciprocity", trial, human_study)


