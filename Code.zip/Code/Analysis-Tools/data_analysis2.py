from networkx import Graph
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pandas as pd
import os
import scipy.stats as stats
from scipy.spatial.distance import mahalanobis
from numpy.linalg import pinv
from scipy.stats import chi2

import configuration as config

class FileHandler:

    '''
    simulated: (bool) says whether the games in question are simulated or if they were obtained in a user study
    game_folder: (string) folder where games are stored
    '''
    def __init__(self, trial_folder_name, simulated, player_config, label_name='', color=''):
        self.num_ecab, self.num_hcab, self.num_rand, self.num_ptft, self.num_hplay = player_config
        self.network_analysis_folder = config.DATAPATH_SIMULATED + 'network_analysis/' + trial_folder_name + '/'
        self.simulated = simulated
        self.label_name = label_name
        self.color = color

        if simulated:
            self.num_games = len(os.listdir(config.DATAPATH_SIMULATED + 'simulated_games/' + trial_folder_name + '/'))
            self.network_analysis_trial_folder = config.DATAPATH_SIMULATED + "networkAnalysis/" + trial_folder_name + '/'
            self.game_codes = []
            for i in range(self.num_games):
                self.game_codes += ["log_ecab-" + str(self.num_ecab) + "_hcab-" + str(self.num_hcab) + "_game-" + str(i)]
        else:
            self.num_games = len(os.listdir(config.DATAPATH_SIMULATED + 'study_games/' + trial_folder_name + '/'))
            study_games_folder = config.DATAPATH_SIMULATED + 'study_games/' + trial_folder_name + '/'
            self.network_analysis_trial_folder = config.DATAPATH_SIMULATED + "networkAnalysis/" + trial_folder_name + '/'
            self.game_codes = self.extract_game_codes(study_games_folder)

    def extract_game_codes(self, folder_path):
        # List to store game codes
        game_codes = []

        # Iterate through each file in the folder
        for filename in os.listdir(folder_path):
            # Check if the file matches the expected pattern
            if filename.startswith("jhg_") and filename.endswith(".csv"):
                # Extract the game code part
                game_code = filename[:-4]  # Removes "jhg_" and ".csv"
                game_codes.append(game_code)

        return game_codes

    def get_graph_metric_file_list(self, graph, metric):
        file_list = []
        for game_code in self.game_codes:
            file_list += [self.network_analysis_trial_folder + game_code + "_" + graph + "_" + metric + ".npy"]

        return file_list

# class DataAnalysisDataHandler:
#
#     def __init__(self):
#         self.network_analysis_folder = config.DATAPATH_SIMULATED + 'networkAnalysis/'
#         game_type = ["all_humans"]
#         folder = config.DATAPATH_SIMULATED + 'study_games/' + game_type[i] + '/'
#         game_codes = extract_game_codes(self.network_analysis_folder)
#         pass
#
#     def extract_game_codes(folder_path):
#         # List to store game codes
#         game_codes = []
#
#         # Iterate through each file in the folder
#         for filename in os.listdir(folder_path):
#             # Check if the file matches the expected pattern
#             if filename.startswith("jhg_") and filename.endswith(".csv"):
#                 # Extract the game code part
#                 game_code = filename[4:-4]  # Removes "jhg_" and ".csv"
#                 game_codes.append(game_code)
#
#         return game_codes
#
#
#     def get_network_analysis_file_names_study(self, trial_name, graph, metric, player_config, num_games, game_codes):
#         num_ecab, num_hcab, num_hplay = player_config
#         file = config.DATAPATH_SIMULATED + "networkAnalysis/" + trial_name + '/'
#         for code in game_codes:
#             pass
#
#         return config.DATAPATH_SIMULATED + 'networkAnalysis/'

LAST_ROUND = 20
graphs_folder = config.DATAPATH_SIMULATED + 'graphs/'

# Initialize data and labels
data = []
labels = []
colors = []
errors = []

def plot_bar_graph(value, std_error=None, label_name='', color='k', show_numbers=False):
    """
    Adds a new bar to the bar graph by appending data and re-plotting.

    Parameters:
    - value: Height of the new bar.
    - label: Label for the new bar.
    """
    data.append(value)
    labels.append(label_name)
    colors.append(color)  # Add the color to the list
    errors.append(std_error if std_error is not None else 0)  # Ensure error list matches length

    plt.clf()  # Clear the current figure
    plt.bar(range(len(data)), data, tick_label=labels, color=colors, yerr=errors, capsize=10)

    plt.xticks(rotation=90)
    plt.title("Dynamic Bar Graph")
    plt.ylabel("Value")
    plt.xlabel("Categories")
    plt.tight_layout()

    if show_numbers:
        for i, height in enumerate(data):
            plt.text(
                i,  # x-coordinate (center of the bar)
                height + .00,  # y-coordinate (slightly above the bar)
                f'{height:.2f}',  # Text to display (the bar's height)
                ha='center',  # Horizontal alignment
                va='bottom',  # Vertical alignment
                fontsize=10  # Font size
            )
    # plt.pause(0.5)  # Pause to show updates (useful in interactive sessions)


def plot_scatter_graph(x_data, y_data, x_label='X-Axis', y_label='Y-Axis', x_errors=None, y_errors=None, labels=None, label_fontsize=12,
                       title='Scatter Plot', marker='o', filename=None, colors=None, label_placement=None, scale=None):
    """
    Plots a scatter graph using the given x and y data.

    Parameters:
    - x_data: List of values for the x-axis.
    - y_data: List of values for the y-axis.
    - x_label: Label for the x-axis.
    - y_label: Label for the y-axis.
    - title: Title of the scatter plot.
    - color: Color of the scatter points.
    - marker: Marker style for the points.
    """
    plt.figure()
    ax = plt.gca()  # Get current axis
    # Plot the scatter points with error bars
    for i in range(len(x_data)):
        plt.scatter(x_data[i], y_data[i], marker=marker, linestyle='None', color=colors[i])

        # Add an ellipse representing the error region
        ellipse = patches.Ellipse((x_data[i], y_data[i]),
                                  width=2 * x_errors[i], height=2 * y_errors[i],
                                  edgecolor=colors[i], facecolor=colors[i], alpha=0.3)
        ax.add_patch(ellipse)

    # Add labels to each point if provided
    if labels:
        if label_placement is None:
            label_placement = []
            for i in range(len(labels)):
                label_placement += [['right', 'bottom']]
        for i, label in enumerate(labels):
            plt.text(x_data[i], y_data[i], label, fontsize=label_fontsize, ha=label_placement[i][0], va=label_placement[i][1])

    if scale is not None:
        plt.xlim(scale[0], scale[1])
        plt.ylim(scale[2], scale[3])

    plt.xlabel(x_label, fontweight='bold')
    plt.ylabel(y_label, fontweight='bold')
    # plt.title(title)


    plt.grid(True)
    if filename is None:
        plt.show()
    else:
        plt.savefig(graphs_folder + filename, bbox_inches='tight')

    plt.clf()  # Clears the current figure
    plt.cla()  # Clears the current axes (optional)
    plt.close()  # Closes the figure (optional)


# Example Usage:
# If you want to plot values vs. errors from your bar graph:
# plot_scatter_graph(data, errors, x_label="Bar Values", y_label="Standard Error")


def plot_bar_line(bar_index, line_height, color='k'):
    bar_width = 0.8  # Default bar width in Matplotlib
    x_start = bar_index - bar_width / 2  # Start of the line
    x_end = bar_index + bar_width / 2  # End of the line
    plt.plot([x_start, x_end], [line_height, line_height], color=color, linewidth=2, linestyle='-')


def plot_line_graph(data, label_name=None, color=None):
    if label_name is not None:
        plt.plot(data, label=label_name, color=color)
    else:
        plt.plot(data, color=color)


def display_graph(title=None, ylabel='Metric', xlabel='Round', ylim=None, filename=''):

    if ylim is not None:
        plt.ylim(8, 16)
    if title is not None:
        plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.legend()
    plt.show()
    # Reinitialize data and labels (needed for bar graphs)
    data.clear()
    labels.clear()
    errors.clear()
    colors.clear()

def save_graph(filepath=graphs_folder, title=None, xlabel='Round', ylabel='Metric', ylim=None, filename=''):
    # if ylim is not None:
    #     plt.ylim(8, 16)
    if title is not None:
        plt.title(title)
    plt.xlabel(xlabel, fontweight='bold')
    plt.ylabel(ylabel, fontweight='bold')
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5), fontsize=18)
    # plt.tight_layout()
    # plt.subplots_adjust(bottom=0.2, right=0.75)
    plt.savefig(filepath + filename, bbox_inches='tight')  # Save the graph to the specified file
    plt.close()  # Close the plot to free up memory
    # Reinitialize data and labels (needed for bar graphs)
    data.clear()
    labels.clear()
    errors.clear()
    colors.clear()


# def load_data(file, number_of_rounds=LAST_ROUND):
#     data = np.load(file, allow_pickle=True)
#
#     final_data = np.zeros([number_of_rounds, data.shape[1]])
#     rounds = np.zeros(number_of_rounds)
#     for i in range(min(data.shape[0], number_of_rounds)):
#         final_data[i] = data[i]
#         rounds[i] = 1
#
#     return final_data, rounds


def load_data(file, number_of_rounds=LAST_ROUND):
    data = np.load(file, allow_pickle=True)

    shape = list(data.shape)
    shape[0] = number_of_rounds

    final_data = np.zeros(shape)
    rounds = np.zeros(number_of_rounds)
    for i in range(min(data.shape[0], number_of_rounds)):
        final_data[i] = data[i]
        rounds[i] = 1

    return final_data, rounds


def mean_popularity_over_time(file_handler, metric=''):
    filelist = file_handler.get_graph_metric_file_list('Transaction', metric+'Absolute Popularities')
    avg_pop, rounds = [], np.zeros(LAST_ROUND)
    for file in filelist:
        data, round = load_data(file)
        rounds += round
        avg_pop += [np.mean(data, axis=1)]
    # mean_pop = np.array(avg_pop)

    return np.sum(np.array(avg_pop), axis=0) / rounds


def get_round_lengths(file_handler):
    filelist = file_handler.get_graph_metric_file_list('Transaction', 'Absolute Popularities')
    round_lengths = []
    for file in filelist:
        data, round = load_data(file)
        round_lengths += [int(np.sum(round))]
    return round_lengths


# def load_metric_data(file, number_of_rounds=LAST_ROUND):
#     data = np.load(file, allow_pickle=True)
#
#     final_data = np.zeros([number_of_rounds])
#     rounds = np.zeros(number_of_rounds)
#     for i in range(min(data.shape[0], number_of_rounds)):
#         final_data[i] = data[i]
#         rounds[i] = 1
#
#     return final_data, rounds


def gini_index_over_time(file_handler):
    """
    Calculates the Gini index over time for a set of populations.

    Args:
        file_handler: An object with a method `get_graph_metric_file_list`
                      that retrieves file paths to the required data files.

    Returns:
        A numpy array of Gini indices over time.
    """
    def calculate_gini(array):
        """Helper function to calculate the Gini index of a 1D array."""
        array = np.sort(array)  # Sort the array for Gini calculation
        n = len(array)
        index = np.arange(1, n + 1)  # Indexes from 1 to n
        return (2 * np.sum(index * array) / np.sum(array) - (n + 1)) / n

    filelist = file_handler.get_graph_metric_file_list('Transaction', 'Absolute Popularities')
    gini_values, rounds = [], np.zeros(LAST_ROUND)
    for file in filelist:
        data, round = load_data(file)  # Load data for all rounds up to LAST_ROUND
        gini_per_round = [np.nan_to_num(calculate_gini(pop)) for pop in data]  # Calculate Gini index for each round
        rounds += round
        gini_values.append(gini_per_round)  # Store the Gini indices for this file

    return np.sum(np.array(gini_values), axis=0) / rounds  # Average Gini index across all files


def combined_metric_data(file_handler, graph='Transaction', metric="Reciprocity"):
    filelist = file_handler.get_graph_metric_file_list(graph, metric)
    data = np.zeros([LAST_ROUND, ])
    rounds = np.zeros(LAST_ROUND)
    for file in filelist:
        metric_data, metric_rounds = load_data(file)
        rounds += metric_rounds

        data += metric_data

    return data / rounds


def combined_metric_data_for_summary_graph(file_handler, graph='SummaryTransaction', metric="Reciprocity"):
    filelist = file_handler.get_graph_metric_file_list(graph, metric)
    data = np.zeros(len(filelist))
    for i, file in enumerate(filelist):
        metric_data = np.load(file, allow_pickle=True)
        data[i] = metric_data

    return data


def economic_actions_data(file_handler, graph, metric):
    num_ecab, num_hcab, num_hplay = file_handler.num_ecab, file_handler.num_hcab, file_handler.num_hplay
    total_action = []

    filelist = file_handler.get_graph_metric_file_list(graph, metric)
    rounds = np.zeros(LAST_ROUND)
    for file in filelist:
        try:
            data, metric_rounds = load_data(file)
            rounds += metric_rounds
            data /= data.shape[1] * 2
            data /= data.shape[1]
            data = np.absolute(data)
            if len(data.shape) == 3:
                total_action += [np.sum(np.sum(data, axis=2), axis=1)]
            else:
                total_action += [np.sum(data, axis=1)]
        except:
            pass

    # mean_action = np.zeros_like(len(np.mean(total_action, axis=0)))
    mean_action = np.sum(np.array(total_action), axis=0) / rounds

    return mean_action


def compute_sem(values):
    """
    Compute the Standard Error of the Mean (SEM) for a given list of values.

    Parameters:
        values (list or numpy array): The list of sample values.

    Returns:
        float: The SEM value.
    """
    values = np.array(values)
    n = len(values)
    if n <= 1:
        return 0  # Avoid division by zero for small sample sizes
    return np.std(values, ddof=1) / np.sqrt(n)


def compute_confidence_interval(values, confidence=0.95):
    """
    Compute the confidence interval (CI) for a given list of values.

    Parameters:
        values (list or numpy array): The list of sample values.
        confidence (float): The confidence level (default: 95%).

    Returns:
        tuple: (lower bound, upper bound) of the confidence interval.
    """
    values = np.array(values)
    n = len(values)
    if n <= 1:
        return (np.mean(values), np.mean(values))  # No interval for small sample sizes

    mean_value = np.mean(values)
    sem_value = compute_sem(values)
    t_value = stats.t.ppf((1 + confidence) / 2, df=n - 1)  # Critical t-value

    margin_of_error = t_value * sem_value
    return (mean_value - margin_of_error, mean_value + margin_of_error)


def mahalanobis_distance_between_classes(class1: np.ndarray, class2: np.ndarray, return_individual_distances=False):
    """
    Compute the Mahalanobis distance between the mean vectors of two classes.

    Parameters:
    - class1 (np.ndarray): A NumPy array of shape (N1, D) representing the first class.
    - class2 (np.ndarray): A NumPy array of shape (N2, D) representing the second class.
    - return_individual_distances (bool): If True, also returns the Mahalanobis distances of each
      point in class1 to the mean of class2.

    Returns:
    - mahalanobis_dist (float): The Mahalanobis distance between the mean vectors of class1 and class2.
    - individual_distances (list, optional): A list of Mahalanobis distances for each sample in class1
      to the mean of class2 (if return_individual_distances is True).
    """
    # Compute mean vectors
    mean1 = np.mean(class1, axis=0)
    mean2 = np.mean(class2, axis=0)

    # Compute covariance matrices and pooled covariance matrix
    cov1 = np.cov(class1, rowvar=False)
    cov2 = np.cov(class2, rowvar=False)

    N1, N2 = class1.shape[0], class2.shape[0]  # Number of samples per class
    pooled_cov = ((N1 - 1) * cov1 + (N2 - 1) * cov2) / (N1 + N2 - 2)

    # Compute inverse of pooled covariance matrix
    cov_inv = pinv(pooled_cov)

    # Compute Mahalanobis distance between mean vectors
    mahalanobis_dist = np.sqrt((mean1 - mean2) @ cov_inv @ (mean1 - mean2).T)

    # Compute Mahalanobis distance of each point in class1 to the mean of class2 (if requested)
    individual_distances = None
    if return_individual_distances:
        individual_distances = [mahalanobis(x, mean2, cov_inv) for x in class1]

    return (mahalanobis_dist, individual_distances) if return_individual_distances else mahalanobis_dist


def mahalanobis_probability(distance, df):
    """
    Converts Mahalanobis distance to a probability using the Chi-Squared distribution.

    Parameters:
    - distance (float): Mahalanobis distance
    - df (int): Degrees of freedom (number of features)

    Returns:
    - float: Probability of observing a point at this distance or further under normality assumption
    """
    D_M2 = distance ** 2  # Squared Mahalanobis Distance
    p_value = 1 - chi2.cdf(D_M2, df)  # 1 - CDF gives tail probability
    return p_value


def wasserstein_distance(class1, class2):
    # Compute mean vectors
    mean1 = np.mean(class1, axis=0)
    mean2 = np.mean(class2, axis=0)

    var1 = np.var(class1, axis=0)
    var2 = np.var(class2, axis=0)

    return np.sqrt((mean1 - mean2) ** 2 + (var1 - var2) ** 2)

# mean1, var1 = 2.0, 1.0
# mean2, var2 = 5.0, 2.5
#
# distance = wasserstein_distance(mean1, var1, mean2, var2)
# print("Wasserstein Distance:", distance)




def main():
    LAST_ROUND = 17
    trans_metrics = ['Reciprocity', 'Clustering']
    influ_metrics = ['Reciprocity', 'Clustering']
    economic_actions = ["Giving", "Keeping", "Taking"]

    hcab_folders = ['default_hcab/', 'matching_micro_level_stats/', 'micro_stats_weighted_for_friendship/', 'matching_macro_and_micro_level_stats/'] # , 'default_experienced/', 'default_novice/', default_estimated_expert/, default_estimated_novice/, 'class_behaviors/']
    trial_names = ['Default', 'Matching Micro-Level Stats', 'Weighted For Friendship', 'Matching Macro & Micro Level Stats'] # , 'Default Experienced', 'Default Novice', 'Estimated Experienced', 'Estimated Novice', 'Class Behaviors']

    # hcab_folders = ['ecab_cab_v1-hcab_default/']
    # trial_names = ['eCAB (v1) - hCAB (default)']


    '''This section is looking at humans and bots together (it is limited to 17 rounds because that is how long the human games go)'''
    for hcab_folder, trial_name in zip(hcab_folders, trial_names):
        all_humans_file_handler = FileHandler('all_humans', False, [0, 0, 8])
        # expert_humans_file_handler = FileHandler('expert_humans', False, [0, 0, 8])
        # novice_humans_file_handler = FileHandler('novice_humans', False, [0, 0, 8])

        ecab_cab_v1_file_handler = FileHandler('ecab/ecab_cab_v1', True, [8, 0, 0])
        # ecab_cab_v3_file_handler = FileHandler('ecab/ecab_cab_v3', True, [8, 0, 0])

        default_hcab_absolute_file_handler = FileHandler(hcab_folder + 'hcab_absolute_human_all', True, [0, 8, 0])
        default_hcab_mean_file_handler = FileHandler(hcab_folder + 'hcab_mean_human_all', True, [0, 8, 0])
        # default_hcab_cosine_file_handler = FileHandler(hcab_folder + 'hcab_cosine_human_all', True, [0, 8, 0])


        '''Popularity Centrality'''
        plot_line_graph(mean_popularity_over_time(all_humans_file_handler), label_name="all_humans")
        # plot_line_graph(mean_popularity_over_time(expert_humans_file_handler), label_name="expert_humans")
        # plot_line_graph(mean_popularity_over_time(novice_humans_file_handler), label_name="novice_humans")
        plot_line_graph(mean_popularity_over_time(ecab_cab_v1_file_handler), label_name="ecab_v1")
        # plot_line_graph(mean_popularity_over_time(ecab_cab_v3_file_handler), label_name="ecab_v3")
        plot_line_graph(mean_popularity_over_time(default_hcab_absolute_file_handler), label_name="default_hcab_absolute")
        plot_line_graph(mean_popularity_over_time(default_hcab_mean_file_handler), label_name="default_hcab_mean")
        display_graph(title=trial_name + " Popularity Centrality")


        '''Gini Index'''
        plot_line_graph(gini_index_over_time(all_humans_file_handler), label_name="all_humans")
        # plot_line_graph(gini_index_over_time(expert_humans_file_handler), label_name="expert_humans")
        # plot_line_graph(gini_index_over_time(novice_humans_file_handler), label_name="novice_humans")
        plot_line_graph(gini_index_over_time(ecab_cab_v1_file_handler), label_name="ecab_v1")
        # plot_line_graph(gini_index_over_time(ecab_cab_v3_file_handler), label_name="ecab_v3")
        plot_line_graph(gini_index_over_time(default_hcab_absolute_file_handler), label_name="default_hcab_absolute")
        plot_line_graph(gini_index_over_time(default_hcab_mean_file_handler), label_name="default_hcab_mean")
        display_graph(title=trial_name + " Gini Index")


        '''Other Metrics: Reciprocity, Clustering'''
        for metric in trans_metrics:
            plot_line_graph(combined_metric_data(all_humans_file_handler, metric=metric), label_name="all_humans")
            # plot_line_graph(combined_metric_data(expert_humans_file_handler, metric=metric), label_name="expert_humans")
            # plot_line_graph(combined_metric_data(novice_humans_file_handler, metric=metric), label_name="novice_humans")
            plot_line_graph(combined_metric_data(ecab_cab_v1_file_handler, metric=metric), label_name="ecab_v1")
            # plot_line_graph(combined_metric_data(ecab_cab_v3_file_handler, metric=metric), label_name="ecab_v3")
            plot_line_graph(combined_metric_data(default_hcab_absolute_file_handler, metric=metric), label_name="default_hcab_absolute")
            plot_line_graph(combined_metric_data(default_hcab_mean_file_handler, metric=metric), label_name="default_hcab_mean")
            display_graph(title=trial_name + " " + metric)

        for metric in influ_metrics:
            plot_line_graph(combined_metric_data(all_humans_file_handler, graph="Influence", metric=metric), label_name="all_humans")
            # plot_line_graph(combined_metric_data(expert_humans_file_handler, graph="Influence", metric=metric), label_name="expert_humans")
            # plot_line_graph(combined_metric_data(novice_humans_file_handler, graph="Influence", metric=metric), label_name="novice_humans")
            plot_line_graph(combined_metric_data(ecab_cab_v1_file_handler, graph="Influence", metric=metric), label_name="ecab_v1")
            # plot_line_graph(combined_metric_data(ecab_cab_v3_file_handler, graph="Influence", metric=metric), label_name="ecab_v3")
            plot_line_graph(combined_metric_data(default_hcab_absolute_file_handler, graph="Influence", metric=metric), label_name="default_hcab_absolute")
            plot_line_graph(combined_metric_data(default_hcab_mean_file_handler, graph="Influence", metric=metric), label_name="default_hcab_mean")
            display_graph(title=trial_name + " " + metric)


        '''Economic Actions: Give, Keep, Take'''
        # the_sum = ((economic_actions_data(all_humans_file_handler, graph="Transaction", metric="Giving") +
        #            economic_actions_data(all_humans_file_handler, graph="Transaction", metric="Taking")) +
        #            economic_actions_data(all_humans_file_handler, graph="Transaction", metric="Keeping"))
        # plot_line_graph(the_sum, label_name="all_humans")
        #
        # the_sum = ((economic_actions_data(default_hcab_absolute_file_handler, graph="Transaction", metric="Giving") +
        #            economic_actions_data(default_hcab_absolute_file_handler, graph="Transaction", metric="Taking")) +
        #            economic_actions_data(default_hcab_absolute_file_handler, graph="Transaction", metric="Keeping"))
        # plot_line_graph(the_sum, label_name="default_hcab_absolute")
        #
        # the_sum = ((economic_actions_data(ecab_cab_v1_file_handler, graph="Transaction", metric="Giving") +
        #            economic_actions_data(ecab_cab_v1_file_handler, graph="Transaction", metric="Taking")) +
        #            economic_actions_data(ecab_cab_v1_file_handler, graph="Transaction", metric="Keeping"))
        # plot_line_graph(the_sum, label_name="ecab_cab_v1")
        #
        # display_graph(title="All Actions")
        for action in economic_actions:
            plot_line_graph(economic_actions_data(all_humans_file_handler, graph="Transaction", metric=action), label_name="all_humans")
            # plot_line_graph(economic_actions_data(expert_humans_file_handler, graph="Transaction", metric=action), label_name="expert_humans")
            # plot_line_graph(economic_actions_data(novice_humans_file_handler, graph="Transaction", metric=action), label_name="novice_humans")
            plot_line_graph(economic_actions_data(ecab_cab_v1_file_handler, graph="Transaction", metric=action), label_name="ecab_v1")
            # plot_line_graph(economic_actions_data(ecab_cab_v3_file_handler, graph="Transaction", metric=action), label_name="ecab_v3")
            plot_line_graph(economic_actions_data(default_hcab_absolute_file_handler, graph="Transaction", metric=action), label_name="default_hcab_absolute")
            plot_line_graph(economic_actions_data(default_hcab_mean_file_handler, graph="Transaction", metric=action), label_name="default_hcab_mean")

            display_graph(title=trial_name + " " + action)


    '''This section is looking exclusively at simulations'''
    # LAST_ROUND = 30
    # hcab_folder = 'default_hcab/'
    # trial_name = 'Simulation'
    #
    # ecab_cab_v1_file_handler = FileHandler('ecab/ecab_cab_v1', True, [8, 0, 0])
    # default_hcab_absolute_file_handler = FileHandler(hcab_folder + 'hcab_absolute_human_all', True, [0, 8, 0])
    # default_hcab_mean_file_handler = FileHandler(hcab_folder + 'hcab_mean_human_all', True, [0, 8, 0])
    # default_hcab_cosine_file_handler = FileHandler(hcab_folder + 'hcab_cosine_human_all', True, [0, 8, 0])
    #
    #
    # '''Popularity Centrality'''
    # plot_line_graph(mean_popularity_over_time(ecab_cab_v1_file_handler), label_name="ecab_v1")
    # plot_line_graph(mean_popularity_over_time(default_hcab_absolute_file_handler), label_name="hcab_absolute")
    # plot_line_graph(mean_popularity_over_time(default_hcab_mean_file_handler), label_name="hcab_mean")
    # # plot_line_graph(mean_popularity_over_time(default_hcab_cosine_file_handler), label_name="hcab_cosine")
    # save_graph(title=trial_name + " Popularity Centrality")
    #
    #
    # '''Gini Index'''
    # plot_line_graph(gini_index_over_time(default_hcab_absolute_file_handler), label_name="ecab_v1")
    # plot_line_graph(gini_index_over_time(default_hcab_absolute_file_handler), label_name="hcab_absolute")
    # plot_line_graph(gini_index_over_time(default_hcab_mean_file_handler), label_name="hcab_mean")
    # # plot_line_graph(gini_index_over_time(default_hcab_cosine_file_handler), label_name="hcab_cosine")
    # save_graph(title=trial_name + " Gini Index")
    #
    #
    # '''Other Metrics: Reciprocity, Clustering'''
    # for metric in trans_metrics:
    #     plot_line_graph(combined_metric_data(ecab_cab_v1_file_handler, metric=metric), label_name="ecab_v1")
    #     plot_line_graph(combined_metric_data(default_hcab_absolute_file_handler, metric=metric), label_name="absolute")
    #     plot_line_graph(combined_metric_data(default_hcab_mean_file_handler, metric=metric), label_name="hcab_mean")
    #     # plot_line_graph(combined_metric_data(default_hcab_cosine_file_handler, metric=metric), label_name="hcab_cosine")
    #     save_graph(title=trial_name + " " + metric)
    #
    # for metric in influ_metrics:
    #     plot_line_graph(combined_metric_data(ecab_cab_v1_file_handler, graph="Influence", metric=metric), label_name="ecab_v1")
    #     plot_line_graph(combined_metric_data(default_hcab_absolute_file_handler, graph="Influence", metric=metric), label_name="hcab_absolute")
    #     plot_line_graph(combined_metric_data(default_hcab_mean_file_handler, graph="Influence", metric=metric), label_name="hcab_mean")
    #     # plot_line_graph(combined_metric_data(default_hcab_cosine_file_handler, graph="Influence", metric=metric), label_name="hcab_cosine")
    #     save_graph(title=trial_name + " " + metric)
    #
    #
    # '''Economic Actions: Give, Keep, Take'''
    # for action in economic_actions:
    #     plot_line_graph(economic_actions_data(ecab_cab_v1_file_handler, graph="Transaction", metric=action), label_name="ecab_v1")
    #     plot_line_graph(economic_actions_data(default_hcab_absolute_file_handler, graph="Transaction", metric=action), label_name="hcab_absolute")
    #     plot_line_graph(economic_actions_data(default_hcab_mean_file_handler, graph="Transaction", metric=action), label_name="hcab_mean")
    #     # plot_line_graph(economic_actions_data(default_hcab_cosine_file_handler, graph="Transaction", metric=action), label_name="hcab_cosine")
    #
    #     save_graph(title=trial_name + " " + action)


if __name__ == "__main__":
    main()

