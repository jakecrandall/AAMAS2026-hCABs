import configuration as config
import data_processing2 as data_processing
from metric_manager import *
import networkx as nx
import networkx.algorithms.community as nx_comm
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.use('tkagg')
# mpl.use('module://backend_interagg')
import numpy as np
import seaborn
import re
import json


plt.rcParams.update({'font.size': 14})
plt.rc('axes', labelweight='bold')
plt.rcParams['figure.figsize'] = [6, 6.75]
def gini(x):
    # (Warning: This is a concise implementation, but it is O(n**2)
    # in time and memory, where n = len(x).  *Don't* pass in huge
    # samples!)

    # Mean absolute difference
    mad = np.abs(np.subtract.outer(x, x)).mean()
    # Relative mean absolute difference
    rmad = mad / np.mean(x)
    # Gini coefficient
    g = 0.5 * rmad
    return g


def gini_coefficient(x):
    """Compute Gini coefficient of array of values"""
    diffsum = 0
    for i, xi in enumerate(x[:-1], 1):
        diffsum += np.sum(np.abs(xi - x[i:]), axis=0)
    return diffsum / (len(x) ** 2 * np.mean(x, axis=0))


def pop_init_graph(transaction, metric, mode1, mode2, game_type, game_codes, colors):
    plt.figure()
    barWidth = 0.25

    for n in range(len(game_type)):
        mean_pop, mean_err_pop = [], []
        avg_pop = []
        for i in range(num_games):
            # humans = np.load(config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
            # "_" + "humans" + ".npy", allow_pickle=True)

            file_path = (config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
                         '_' + transaction + "_" + "Absolute Popularities" + ".npy")
            data = np.load(file_path, allow_pickle=True)
            if mode2 == 'mean':
                avg_pop += [np.mean(data[20])]
            elif mode2 == 'gini':
                avg_pop += [gini_coefficient(data.T)[20]]

        mean_pop += [np.mean(np.array(avg_pop))]
        mean_err_pop += [np.std(np.array(avg_pop)) / np.sqrt(len(avg_pop))]
        x = 0
        # print(game_type[m], things[n], mean_pop)
        plt.bar(x + barWidth * n, mean_pop, yerr=mean_err_pop, ecolor='k', capsize=3, width=barWidth, edgecolor='grey',
                label=game_type_names[n], color=colors[n])
        # plt.bar(x + barWidth * n, mean_a_pop, width=barWidth, edgecolor='grey')

    # plt.title("Social Welfare by Game Type")
    plt.xticks([],
               [])
    # plt.xlabel('Initial Conditions')
    if mode2 == 'mean':
        plt.ylabel("Average Ending Popularities")
    elif mode2 == 'gini':
        plt.ylabel("Average Ending Gini Index")
    plt.legend()
    plt.show()


def pop_bot_hum_graph(transaction, metric, mode1, mode2, game_type, game_codes, colors):
    plt.figure()
    barWidth = 0.40
    for j, agents in enumerate(['Human', 'CAB_3']):
        mean_pop, mean_err_pop = [], []
        avg_pop = []
        for n in range(len(game_type)):
            for i in range(num_games):
                humans = np.load(config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
                                 "_" + "humans" + ".npy", allow_pickle=True)

                file_path = (config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
                             '_' + transaction + "_" + "Absolute Popularities" + ".npy")
                data = np.load(file_path, allow_pickle=True)
                if mode2 == 'mean':
                    avg_pop += [np.mean(data[20][humans == agents])]
                elif mode2 == 'gini':
                    avg_pop += [gini_coefficient(data.T)[20]]

        mean_pop += [np.mean(np.array(avg_pop))]
        mean_err_pop += [np.std(np.array(avg_pop)) / np.sqrt(len(avg_pop))]
        x = 0
        # print(game_type[m], things[n], mean_pop)
        plt.bar(x + barWidth * j, mean_pop, yerr=mean_err_pop, ecolor='k', capsize=3, width=barWidth, edgecolor='grey',
                label=agents, color=colors[j])
        # plt.bar(x + barWidth * n, mean_a_pop, width=barWidth, edgecolor='grey')

    # plt.title("Social Welfare by Agent Type")
    plt.xticks([],
               [])
    # plt.xlabel('Initial Conditions')
    if mode2 == 'mean':
        plt.ylabel("Average Ending Popularities")
    elif mode2 == 'gini':
        plt.ylabel("Average Ending Gini Index")
    plt.legend()
    plt.show()


def pop_degree_graph(transaction, metric, mode1, mode2, game_type, game_codes):
    plt.figure()
    barWidth = 0.40

    for j, agents in enumerate(['Human', 'Bot']):
        avg_degree, avg_influences = [], []
        for n in range(len(game_type)):
            for i in range(num_games):
                humans = np.load(config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
                                 "_" + "humans" + ".npy", allow_pickle=True)

                file_path = (config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
                             '_' + "Influence" + "_" + "Weighted Degree_full" + ".npy")
                degree = np.load(file_path, allow_pickle=True)

                file_path = (config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][
                    i] +
                             '_' + "influences" + ".npy")
                influences = np.load(file_path, allow_pickle=True)

                avg_degree += [np.mean(degree[20][humans == agents]) / 16]
                avg_influences += [np.mean(influences[20][humans == agents]) / (np.sum(influences[20]))]
        mean_pop = np.array([np.mean(np.array(avg_degree)),
                             np.mean(np.array(avg_influences))])
        mean_err_pop = np.array([np.std(np.array(avg_degree)) / np.sqrt(len(avg_degree)),
                                 np.std(np.array(avg_influences)) / np.sqrt(len(avg_influences))])
        x = np.array([0, 1])
        # print(game_type[m], things[n], mean_pop)
        plt.bar(x + barWidth * j, mean_pop, yerr=mean_err_pop, ecolor='k', capsize=3, width=barWidth, edgecolor='grey',
                label=agents)
        # plt.bar(x + barWidth * n, mean_a_pop, width=barWidth, edgecolor='grey')

    # plt.title("Social Welfare by Agent Type")
    plt.xticks([r + barWidth * .5 for r in range(2)],
               ['Degree', 'Influence Centrality'])
    # plt.xlabel('Initial Conditions')
    plt.ylabel("Mean Value of Metric")
    plt.legend()
    plt.show()


def friendship_graph(transaction, metric, num_gen, mode1, mode2, game_type, game_codes, colors, font_size):
    plt.figure()
    barWidth = 0.30

    for n in range(len(game_type)):
        avg_metric = []
        for i in range(len(game_codes[n])):
            humans = np.load(
                config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
                "_" + "humans" + ".npy", allow_pickle=True)

            file_path = (config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" +
                         game_codes[n][i] + '_' + transaction + "_" + "Reciprocity" + ".npy")
            data = np.load(file_path, allow_pickle=True)
            avg_metric += [np.mean(data[10:21])]
        mean_rec = np.mean(avg_metric)
        mean_rec_err = np.std(np.array(avg_metric)) / np.sqrt(len(avg_metric))

        avg_metric = []
        for i in range(len(game_codes[n])):
            humans = np.load(
                config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
                "_" + "humans" + ".npy", allow_pickle=True)

            file_path = (config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" +
                         game_codes[n][i] + '_' + transaction + "_" + "Clustering" + ".npy")
            data = np.load(file_path, allow_pickle=True)
            avg_metric += [np.mean(data[10:21])]
        mean_clu = np.mean(avg_metric)
        mean_clu_err = np.std(np.array(avg_metric)) / np.sqrt(len(avg_metric))

        avg_metric = []
        for i in range(len(game_codes[n])):
            humans = np.load(
                config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" + game_codes[n][i] +
                "_" + "humans" + ".npy", allow_pickle=True)

            file_path = (config.DATAPATH + "study_games/networkAnalysis/" + game_type[n] + "/jhg_" +
                         game_codes[n][i] + '_' + transaction + "_" + "Signed Louvain Modularity Custom" + ".npy")
            data = np.load(file_path, allow_pickle=True)
            avg_metric += [np.mean(data[10:21])]
        mean_mod = np.mean(avg_metric)
        mean_mod_err = np.std(np.array(avg_metric)) / np.sqrt(len(avg_metric))

        mean_metric = np.array([mean_rec, mean_clu, mean_mod])
        mean_metric_err = np.array([mean_rec_err, mean_clu_err, mean_mod_err])
        x = np.arange(np.size(mean_metric))
        plt.bar(x + barWidth * n, mean_metric, yerr=mean_metric_err, ecolor='k', capsize=3, width=barWidth, edgecolor='grey',
                label=game_type_names[n], color=colors[n])
        # plt.plot(x, np.mean(mean_rec, axis=0), label='Reciprocity - Simulated')
        # plt.plot(x, np.mean(mean_clu, axis=0), label='Clustering - Simulated')
        # plt.plot(x, np.mean(mean_mod, axis=0), label='Modularity - Simulated')
    # plt.title("Mixing Patterns: Study Results")
    plt.xlabel('Metric', fontsize=font_size)
    plt.rcParams.update({'font.size': font_size})
    x1, x2, y1, y2 = plt.axis()
    plt.axis((x1, x2, 0, 1))
    plt.xticks([r + barWidth * 1 for r in range(3)],
               ['Reciprocity', 'Clustering', 'Modularity'], fontsize=font_size)
    plt.yticks(fontsize=font_size)
    plt.ylabel('Mean Value of Round 10-20', fontsize=font_size)
    plt.legend()
    plt.show()

num_games = 6
num_rounds = 30

game_type = ["majority_bot", "half_human_bot", "majority_human"]
game_type_names = ["Majority CAB_3", "Half Human and CAB_3", "Majority Human"]
game_codes = [['GXVS', 'HNCQ', 'SHFC', 'TKRW', 'WCJQ', 'WHRP'],
              ['CXJR', 'MCZG', 'PSGN', 'VBLN', 'WQDS', 'XSVC'],
              ['GCVN', 'GJFD', 'TDGM', 'WQJR', 'WRBV', 'XTWS']]


human_color, bot_color, mixed_color = '#34BDC5', '#F47C6F', '#6FFF6F'

# pop_init_graph("Transaction", "Absolute Popularities", 'mean', 'mean', game_type, game_codes, colors=[bot_color, mixed_color, human_color])
# pop_init_graph("Transaction", "Absolute Popularities", 'mean', 'gini', game_type, game_codes, colors=[bot_color, mixed_color, human_color])

# pop_bot_hum_graph("Transaction", "Absolute Popularities", 'mean', 'mean', game_type, game_codes, colors=[human_color, bot_color])
# pop_degree_graph("Transaction", "Absolute Popularities", 'mean', 'mean', game_type, game_codes)


friendship_graph("Transaction", "Reciprocity", 0, 'mean', 'mean', game_type, game_codes, colors=[bot_color, mixed_color, human_color], font_size=18)



