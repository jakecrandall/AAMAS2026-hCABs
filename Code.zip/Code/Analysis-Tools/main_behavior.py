from threading import Thread
# from concurrent.futures import ThreadPoolExecutor

import configuration as config
import data_processing2 as data_processing
from main import num_players
from metric_manager import *
import networkx as nx
import networkx.algorithms.community as nx_comm
import matplotlib.pyplot as plt
import matplotlib as mpl
mpl.use('tkagg')
# mpl.use('module://backend_interagg')
import numpy as np
import seaborn
import re
import json
import sys
import os
import argparse

num_rounds = 30

games = []
# # Initial Conditions Test
# for num_gene_pools in ['1', '3']:
#     for game_type in ['equal', 'highlow', 'power', 'random', 'step']:
#         for gen in ['199']:
#             for varied in ['equal', 'varied']:
#                 games += ["RndGames_" + num_gene_pools + "_" + varied + "_" + gen + "_" + game_type + "/game_"]
#
# for num_gene_pools in ['1', '3']:
#     for game_type in ['equal']:
#         for gen in ['199']:
#             for varied in ['equal', 'varied']:
#                 games += ["AssGames_" + num_gene_pools + "_" + varied + "_" + gen + "_" + game_type + "/game_"]
#
#
# # games += ["AssGames_1_equal_199_equal" + "/game_"]
# # games += ["AssGames_3_varied_189_equal" + "/game_"]
# # games += ["RndGames_1_equal_199_equal" + "/game_"]
# # games += ["RndGames_1_varied_199_equal" + "/game_"]
#
#
# # Generations Test
# for num_gene_pools in ['3']:
#     for game_type in ['equal']:
#         for gen in ['9', '19', '29', '39', '49', '59', '69', '79', '89', '99', '109', '119', '129', '139', '149', '159', '169', '179', '189']:
#             for varied in ['varied']:
#                 games += ["RndGames_" + num_gene_pools + "_" + varied + "_" + gen + "_" + game_type + "/game_"]
#                 # games += ["AssGames_" + num_gene_pools + "_" + varied + "_" + gen + "_" + game_type + "/game_"]


# for game in games:
#     print("mkdir /home/watchtower/Datasets/JuniorHighNetwork/simulated_games_2/out/0/" + game[:-6])

def extract_game_codes(folder_path):
    # List to store game codes
    game_codes = []

    # Iterate through each file in the folder
    for filename in os.listdir(folder_path):
        # Check if the file matches the expected pattern
        if filename.startswith("jhg_") and filename.endswith(".csv"):
            # Extract the game code part
            game_code = filename[4:-4]  # Removes "jhg_" and ".csv"
            game_codes.append(game_code)

    return game_codes


def threaded_function_simulation(game_file, trial_dir):
    print("\nGame: " + '.../' + game_file)
    dp = data_processing.DataProcessing(
        config.DATAPATH_SIMULATED + "simulated_games/" + trial_dir + "/" + game_file)
        # config.DATAPATH_SIMULATED + "simulated_games/" + chat + name + '.csv')

    # print(dp.get_transactions())
    # print(dp.get_influence_graphs())

    trans_gs = dp.get_transaction_graphs()
    influ_gs = dp.get_influence_graphs()
    pop = dp.get_popularities()

    polarization = dp.get_polarization_metrics(transpose_influence=True)

    transaction_mm = MetricManager('Transaction', graphs=trans_gs, included_metrics=config.transaction_metrics,
                                   popularities=pop[:-1], outfile=game_file[:-4])
    influence_mm = MetricManager('Influence', graphs=influ_gs, included_metrics=config.influence_metrics,
                                 popularities=pop[1:], outfile=game_file[:-4])

    # Draw Graphs
    # transaction_mm.draw_graphs(name+'_Transaction')
    # influence_mm.draw_graphs(name+'_Influence')
    #
    # # Plot Popularity
    # transaction_mm.print_abs_popularity_plot(name)
    # transaction_mm.print_popularity_plot(name)
    #
    # # Plot Metrics
    # transaction_mm.print_metric_plots(name+'_Transaction')
    # influence_mm.print_metric_plots(name+'_Influence')

    transaction_mm.print_transactions(trial=trial_dir)

    transaction_mm.print_modified_metrics(trial=trial_dir, polarization=polarization)

    transaction_mm.print_metrics(trial=trial_dir)
    influence_mm.print_metrics(trial=trial_dir)

    transaction_mm.print_pop_metrics(trial=trial_dir)


def threaded_function_study(game_codes, game_type):
    transaction_metrics_data_no_chat, influence_metrics_data_no_chat = [], []
    for name in game_codes:
        # name = str(num)
        print("\nGame: " + game_type + '/' + name + '.csv')
        dp = data_processing.DataProcessing(
            config.DATAPATH + "study_games/" + game_type + '/jhg_' + name + '.csv')

        dp.transactions = dp.get_transactions() / (dp.get_transactions().shape[1] * 2)  # this converts study games to look like simulated games

        # print(dp.get_transactions().shape[1])
        # print(np.sum(np.abs(dp.get_transactions() / (dp.get_transactions().shape[1] * 2)), axis=2))

        trans_gs = dp.get_transaction_graphs()
        influ_gs = dp.get_influence_graphs()
        pop = dp.get_popularities()

        polarization = dp.get_polarization_metrics(transpose_influence=False)

        transaction_mm = MetricManager('Transaction', graphs=trans_gs, included_metrics=config.transaction_metrics,
                                       popularities=pop[:-1], outfile=game_type + '/jhg_' + name)
        influence_mm = MetricManager('Influence', graphs=influ_gs, included_metrics=config.influence_metrics,
                                     popularities=pop[1:], outfile=game_type + '/jhg_' + name)

        transaction_mm.print_transactions(trial=game_type, human_study=True, humans=dp.get_human())

        transaction_mm.print_modified_metrics(trial=game_type, human_study=True, humans=dp.get_human(), polarization=polarization)

        transaction_mm.print_metrics(trial=game_type, human_study=True)
        influence_mm.print_metrics(trial=game_type, human_study=True)

        transaction_mm.print_pop_metrics(trial=game_type, human_study=True, humans=dp.get_human())

        humans = dp.get_human()
        np.save(config.DATAPATH + "networkAnalysis/" + game_type + '/jhg_' + name + '_humans.npy', humans)
        np.save(config.DATAPATH + "networkAnalysis/" + game_type + '/jhg_' + name + '_influences.npy', np.sum(dp.get_influences(), axis=1))



def main():
    game_types = ["testing_set_experienced", "training_set_experienced", "hCABs"]  # TODO: Add games from user studies to preprocess
    # game_types = ["testing_set_experienced"]
    threads = []
    for i in range(len(game_types)):
        folder = config.DATAPATH + 'study_games/' + game_types[i]
        game_codes = extract_game_codes(folder)
        threads += [Thread(target=threaded_function_study, args=[np.array(game_codes), game_types[i]])]
        threads[-1].start()

        # threads[-1].join() # stop threading
    for thread in threads:
        thread.join()


    trial_dirs = [  # TODO: Add games from simulated games to preprocess
        "29-genetic_population_summarization/hcab_mean_human_all/", "29-genetic_population_summarization/hcab_property_human_all/",
        "29-society_1/hcab_mean_human_all/", "29-society_1/hcab_property_human_all/",
        "29-tit_for_tat_1/hcab_mean_human_all/", "29-genetic_tit_for_tat/hcab_mean_human_all/",
        "29-tit_for_tat_1/hcab_property_human_all/", "29-genetic_tit_for_tat/hcab_property_human_all/",
        "29-random_agents/", "29-ecab"
    ]

    for trial_dir in trial_dirs:
        game_files = os.listdir(config.DATAPATH_SIMULATED + "simulated_games/" + trial_dir)

        for game_file in game_files:
            threads = []

            for i in range(1):
                threads += [Thread(target=threaded_function_simulation, args=[game_file, trial_dir])]
                threads[-1].start()

            for thread in threads:
                thread.join()

if __name__ == "__main__":
    main()

