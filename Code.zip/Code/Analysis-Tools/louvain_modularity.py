from collections import defaultdict, deque

import networkx as nx
from networkx import NetworkXError
from networkx.utils import py_random_state
import numpy as np
import copy


class NotAPartition(NetworkXError):
    """Raised if a given collection is not a partition."""

    def __init__(self, G, collection):
        msg = f"{G} is not a valid partition of the graph {collection}"
        super().__init__(msg)


def is_partition(G, communities):
    """Returns *True* if `communities` is a partition of the nodes of `G`.

    A partition of a universe set is a family of pairwise disjoint sets
    whose union is the entire universe set.

    Parameters
    ----------
    G : NetworkX graph.

    communities : list or iterable of sets of nodes
        If not a list, the iterable is converted internally to a list.
        If it is an iterator it is exhausted.

    """
    # Alternate implementation:
    # return all(sum(1 if v in c else 0 for c in communities) == 1 for v in G)
    if not isinstance(communities, list):
        communities = list(communities)
    nodes = {n for c in communities for n in c if n in G}

    return len(G) == len(nodes) == sum(len(c) for c in communities)


def modularity_nx(G, communities, weight="weight", resolution=1):
    if not isinstance(communities, list):
        communities = list(communities)
    if not is_partition(G, communities):
        raise NotAPartition(G, communities)

    directed = G.is_directed()
    if directed:
        out_degree = dict(G.out_degree(weight=weight))
        in_degree = dict(G.in_degree(weight=weight))
        m = sum(out_degree.values())
        norm = 1 / m**2
    else:
        out_degree = in_degree = dict(G.degree(weight=weight))
        deg_sum = sum(out_degree.values())
        m = deg_sum / 2
        norm = 1 / deg_sum**2

    def community_contribution(community):
        comm = set(community)
        L_c = sum(wt for u, v, wt in G.edges(comm, data=weight, default=1) if v in comm)

        out_degree_sum = sum(out_degree[u] for u in comm)
        in_degree_sum = sum(in_degree[u] for u in comm) if directed else out_degree_sum
        # print(L_c / m - resolution * out_degree_sum * in_degree_sum * norm)
        return L_c / m - resolution * out_degree_sum * in_degree_sum * norm

    return sum(map(community_contribution, communities))


def modularity_custom(G, communities, weight='weight', resolution=1):
    # Convert the list of sets to a dictionary where the keys are the nodes and the values are the community labels
    c = {}  # get communities
    for i, community in enumerate(communities):
        for node in community:
            c[node] = i

    # Loop through all edges in the graph
    A = np.array(nx.to_numpy_array(G, weight=weight))
    k_neg = np.sum(np.abs(A), axis=1) - np.sum(A, axis=1)
    k_pos = np.sum(np.abs(A), axis=1) - k_neg + np.diag(A)
    # k_pos = np.array(list(dict(nx.degree(G, weight=weight)).values()))
    k = k_pos + k_neg
    m = np.sum(k) / 2
    Qp_in, Qp_out, Qn_in, Qn_out = 0, 0, 0, 0
    for i in range(A.shape[0]):
        for j in range(A.shape[1]):
            if c[i] == c[j]:
                if A[i, j] >= 0:
                    if i == j:
                        Qp_in += (2 * A[i, j] - (k_pos[i] * k_pos[j]) / (2 * m))
                    else:
                        Qp_in += (A[i, j] - (k_pos[i] * k_pos[j]) / (2 * m))
                if A[i, j] < 0:
                    if i == j:
                        Qn_in += (k_neg[i] * k_neg[j]) / (2 * m) - (2 * A[i, j])
                    else:
                        Qn_in += (k_neg[i] * k_neg[j]) / (2 * m) - A[i, j]
            else:
                if A[i, j] >= 0:
                    Qp_out += (k_pos[i] * k_pos[j]) / (2 * m) - A[i, j]
                if A[i, j] < 0:
                    Qn_out += A[i, j] - (k_neg[i] * k_neg[j]) / (2 * m)
    Qp_in /= 2 * m
    Qp_out /= 2 * m
    Qn_in /= 2 * m
    Qn_out /= 2 * m

    return (Qp_in + Qp_out + Qn_in + Qn_out) / 2
    # return (Qp_in + Qp_out) / 2

# def modularity_custom(G, communities, weight='weight', resolution=1):
#     # Get the total sum of weights in the graph
#     total_weight = sum(nx.get_edge_attributes(G, weight).values())
#
#     # Convert the list of sets to a dictionary where the keys are the nodes and the values are the community labels
#     community_dict = {}
#     for i, community in enumerate(communities):
#         for node in community:
#             community_dict[node] = i
#
#     # Initialize variables to store the positive and negative weights for each community
#     pos_weight = {i: 0 for i in range(len(communities))}
#     neg_weight = {i: 0 for i in range(len(communities))}
#
#     # Loop through all edges in the graph
#     for (u, v, data) in G.edges(data=True):
#         # Get the weight of the edge
#         w = data.get(weight, 1.0)
#
#         # Get the community of each node
#         cu = community_dict[u]
#         cv = community_dict[v]
#
#         # Add the weight to the appropriate community counts
#         if cu == cv:
#             pos_weight[cu] += w
#         else:
#             neg_weight[cu] += w
#             neg_weight[cv] += w
#
#     # Compute the modularity
#     Q = 0
#     for i in range(len(communities)):
#         # Get the size of the community
#         size_c = len(communities[i])
#
#         # Get the positive and negative weights for the community
#         pc = pos_weight[i] / total_weight
#         nc = neg_weight[i] / total_weight
#
#         # Compute the modularity contribution for the community
#         Q += pc - resolution * nc ** 2 - resolution * pc ** 2
#
#     return Q


# def modularity_custom(G, communities, weight="weight", resolution=1):
#     if not isinstance(communities, list):
#         communities = list(communities)
#     if not is_partition(G, communities):
#         raise NotAPartition(G, communities)
#
#     if G.is_directed():
#         raise Exception('Does not accept directed graphs!')
#
#     A = nx.to_numpy_matrix(G)
#     A[A < 0] = 0
#     G_pos = nx.from_numpy_matrix(A.astype(int))
#
#     A = nx.to_numpy_matrix(G)
#     A[A > 0] = 0
#     A *= -1
#     G_neg = nx.from_numpy_matrix(A.astype(int))
#
#     degree_pos = dict(G_pos.degree(weight=weight))
#     degree_neg = dict(G_neg.degree(weight=weight))
#     deg_pos_sum = sum(degree_pos.values())
#     deg_neg_sum = sum(degree_neg.values())
#     deg_sum = deg_pos_sum + deg_neg_sum
#     m = deg_sum / 2
#     norm = 1 / deg_sum**2
#
#     def community_contribution(community):
#         comm = set(community)
#         L_c_pos = sum(wt for u, v, wt in G_pos.edges(comm, data=weight, default=1) if v in comm and wt > 0)
#         L_c_pos -= sum(wt for u, v, wt in G_neg.edges(comm, data=weight, default=1) if v in comm and wt > 0)
#         L_c_neg = sum(wt for u, v, wt in G_neg.edges(comm, data=weight, default=1) if v not in comm and wt > 0)
#         L_c_neg -= sum(wt for u, v, wt in G_pos.edges(comm, data=weight, default=1) if v not in comm and wt > 0)
#         degree_sum = sum(degree_pos[u] for u in comm) + sum(degree_neg[u] for u in comm)
#
#         norm_L_c_pos = L_c_pos / (2 * m)
#         norm_L_c_neg = 0
#         if m > 0:
#             norm_L_c_neg = L_c_neg / (2 * m)
#
#         print(norm_L_c_pos + norm_L_c_neg)
#         return norm_L_c_pos + norm_L_c_neg - resolution * degree_sum**2 * norm
#
#     return sum(map(community_contribution, communities))


def modularity_leskovec(G, communities, weight="weight", resolution=1):
    if not isinstance(communities, list):
        communities = list(communities)
    if not is_partition(G, communities):
        raise NotAPartition(G, communities)

    if G.is_directed():
        raise Exception('Does not accept weighted degree!')

    A = nx.to_numpy_array(G)
    A[A < 0] = 0
    G_pos = nx.from_numpy_array(A.astype(int))

    A = nx.to_numpy_array(G)
    A[A > 0] = 0
    A *= -1
    G_neg = nx.from_numpy_array(A.astype(int))

    degree_pos = dict(G_pos.degree(weight=weight))
    degree_neg = dict(G_neg.degree(weight=weight))
    deg_pos_sum = sum(degree_pos.values())
    deg_neg_sum = sum(degree_neg.values())
    deg_sum = deg_pos_sum + deg_neg_sum
    m = deg_sum / 2
    norm = 1 / deg_sum ** 2

    def community_contribution(community):
        comm = set(community)
        L_c_pos = sum(wt for u, v, wt in G_pos.edges(comm, data=weight, default=1) if v in comm and wt > 0)
        L_c_neg = sum(wt for u, v, wt in G_neg.edges(comm, data=weight, default=1) if v in comm and wt > 0)
        degree_sum = sum(degree_pos[u] for u in comm) + sum(degree_neg[u] for u in comm)

        norm_L_c_pos = L_c_pos / m
        norm_L_c_neg = 0
        if m > 0:
            norm_L_c_neg = L_c_neg / m

        return norm_L_c_pos - norm_L_c_neg - resolution * degree_sum ** 2 * norm

    return sum(map(community_contribution, communities))


def modularity_karrer(G, communities, weight="weight", resolution=1):
    if not isinstance(communities, list):
        communities = list(communities)
    if not is_partition(G, communities):
        raise NotAPartition(G, communities)

    if G.is_directed():
        raise Exception('Does not accept weighted degree!')

    A = nx.to_numpy_array(G)
    A[A < 0] = 0
    G_pos = nx.from_numpy_array(A.astype(int))

    A = nx.to_numpy_array(G)
    A[A > 0] = 0
    A *= -1
    G_neg = nx.from_numpy_array(A.astype(int))

    degree_pos = dict(G_pos.degree(weight=weight))
    degree_neg = dict(G_neg.degree(weight=weight))
    deg_pos_sum = sum(degree_pos.values())
    deg_neg_sum = sum(degree_neg.values())
    deg_sum = deg_pos_sum + deg_neg_sum
    m = deg_sum / 2
    norm = 1 / deg_sum ** 2

    def community_contribution(community):
        comm = set(community)
        L_c_pos = sum(wt for u, v, wt in G_pos.edges(comm, data=weight, default=1) if v in comm and wt > 0)
        L_c_neg = sum(wt for u, v, wt in G_neg.edges(comm, data=weight, default=1) if v in comm and wt > 0)
        degree_sum = sum(degree_pos[u] for u in comm) - sum(degree_neg[u] for u in comm)

        norm_L_c_pos = L_c_pos / m
        norm_L_c_neg = 0
        if m > 0:
            norm_L_c_neg = L_c_neg / m

        return norm_L_c_pos - norm_L_c_neg - resolution * degree_sum ** 2 * norm

    return sum(map(community_contribution, communities))


def modularity_xu(G, communities, weight="weight", resolution=1):
    return 0


def modularity(G, communities, modularity_function="default", weight="weight", resolution=1):
    if modularity_function == 'default':
        return modularity_nx(G, communities, weight=weight, resolution=resolution)
    elif modularity_function == 'custom':
        return modularity_custom(G, communities, weight=weight, resolution=resolution)
    elif modularity_function == 'leskovec':
        return modularity_leskovec(G, communities, weight=weight, resolution=resolution)
    elif modularity_function == 'karrer':
        return modularity_karrer(G, communities, weight=weight, resolution=resolution)
    elif modularity_function == 'xu':
        return modularity_xu(G, communities, weight="weight", resolution=resolution)


def louvain_communities(
    G, weight="weight", resolution=1, threshold=0.0000001, seed=None, modularity_function='default'
):
    r"""Find the best partition of a graph using the Louvain Community Detection
    Algorithm.

    Louvain Community Detection Algorithm is a simple method to extract the community
    structure of a network. This is a heuristic method based on modularity optimization. [1]_

    The algorithm works in 2 steps. On the first step it assigns every node to be
    in its own community and then for each node it tries to find the maximum positive
    modularity gain by moving each node to all of its neighbor communities. If no positive
    gain is achieved the node remains in its original community.

    The modularity gain obtained by moving an isolated node $i$ into a community $C$ can
    easily be calculated by the following formula (combining [1]_ [2]_ and some algebra):

    .. math::
        \Delta Q = \frac{k_{i,in}}{2m} - \gamma\frac{ \Sigma_{tot} \cdot k_i}{2m^2}

    where $m$ is the size of the graph, $k_{i,in}$ is the sum of the weights of the links
    from $i$ to nodes in $C$, $k_i$ is the sum of the weights of the links incident to node $i$,
    $\Sigma_{tot}$ is the sum of the weights of the links incident to nodes in $C$ and $\gamma$
    is the resolution parameter.

    For the directed case the modularity gain can be computed using this formula according to [3]_

    .. math::
        \Delta Q = \frac{k_{i,in}}{m}
        - \gamma\frac{k_i^{out} \cdot\Sigma_{tot}^{in} + k_i^{in} \cdot \Sigma_{tot}^{out}}{m^2}

    where $k_i^{out}$, $k_i^{in}$ are the outer and inner weighted degrees of node $i$ and
    $\Sigma_{tot}^{in}$, $\Sigma_{tot}^{out}$ are the sum of in-going and out-going links incident
    to nodes in $C$.

    The first phase continues until no individual move can improve the modularity.

    The second phase consists in building a new network whose nodes are now the communities
    found in the first phase. To do so, the weights of the links between the new nodes are given by
    the sum of the weight of the links between nodes in the corresponding two communities. Once this
    phase is complete it is possible to reapply the first phase creating bigger communities with
    increased modularity.

    The above two phases are executed until no modularity gain is achieved (or is less than
    the `threshold`).

    Parameters
    ----------
    G : NetworkX graph
    weight : string or None, optional (default="weight")
        The name of an edge attribute that holds the numerical value
        used as a weight. If None then each edge has weight 1.
    resolution : float, optional (default=1)
        If resolution is less than 1, the algorithm favors larger communities.
        Greater than 1 favors smaller communities
    threshold : float, optional (default=0.0000001)
        Modularity gain threshold for each level. If the gain of modularity
        between 2 levels of the algorithm is less than the given threshold
        then the algorithm stops and returns the resulting communities.
    seed : integer, random_state, or None (default)
        Indicator of random number generation state.
        See :ref:`Randomness<randomness>`.

    Returns
    -------
    list
        A list of sets (partition of `G`). Each set represents one community and contains
        all the nodes that constitute it.

    Examples
    --------
    >>> import networkx as nx
    >>> import networkx.algorithms.community as nx_comm
    >>> G = nx.petersen_graph()
    >>> nx_comm.louvain_communities(G, seed=123)
    [{0, 4, 5, 7, 9}, {1, 2, 3, 6, 8}]

    Notes
    -----
    The order in which the nodes are considered can affect the final output. In the algorithm
    the ordering happens using a random shuffle.

    References
    ----------
    .. [1] Blondel, V.D. et al. Fast unfolding of communities in
       large networks. J. Stat. Mech 10008, 1-12(2008). https://doi.org/10.1088/1742-5468/2008/10/P10008
    .. [2] Traag, V.A., Waltman, L. & van Eck, N.J. From Louvain to Leiden: guaranteeing
       well-connected communities. Sci Rep 9, 5233 (2019). https://doi.org/10.1038/s41598-019-41695-z
    .. [3] Nicolas Dugué, Anthony Perez. Directed Louvain : maximizing modularity in directed networks.
        [Research Report] Université d’Orléans. 2015. hal-01231784. https://hal.archives-ouvertes.fr/hal-01231784

    See Also
    --------
    louvain_partitions
    """
    return louvain_partitions(G, weight, resolution, threshold, seed, modularity_function=modularity_function)


@py_random_state("seed")
def louvain_partitions(
    G, weight="weight", resolution=1, threshold=0.0000001, seed=None, modularity_function="default"
):
    """Yields partitions for each level of the Louvain Community Detection Algorithm

    Louvain Community Detection Algorithm is a simple method to extract the community
    structure of a network. This is a heuristic method based on modularity optimization. [1]_

    The partitions at each level (step of the algorithm) form a dendogram of communities.
    A dendrogram is a diagram representing a tree and each level represents
    a partition of the G graph. The top level contains the smallest communities
    and as you traverse to the bottom of the tree the communities get bigger
    and the overal modularity increases making the partition better.

    Each level is generated by executing the two phases of the Louvain Community
    Detection Algorithm.

    Parameters
    ----------
    G : NetworkX graph
    weight : string or None, optional (default="weight")
     The name of an edge attribute that holds the numerical value
     used as a weight. If None then each edge has weight 1.
    resolution : float, optional (default=1)
        If resolution is less than 1, the algorithm favors larger communities.
        Greater than 1 favors smaller communities
    threshold : float, optional (default=0.0000001)
     Modularity gain threshold for each level. If the gain of modularity
     between 2 levels of the algorithm is less than the given threshold
     then the algorithm stops and returns the resulting communities.
    seed : integer, random_state, or None (default)
     Indicator of random number generation state.
     See :ref:`Randomness<randomness>`.

    Yields
    ------
    list
        A list of sets (partition of `G`). Each set represents one community and contains
        all the nodes that constitute it.

    References
    ----------
    .. [1] Blondel, V.D. et al. Fast unfolding of communities in
       large networks. J. Stat. Mech 10008, 1-12(2008)

    See Also
    --------
    louvain_communities
    """

    partition = [{u} for u in G.nodes()]
    mod = modularity(G, partition, resolution=resolution, weight=weight, modularity_function=modularity_function)
    is_directed = G.is_directed()
    if G.is_multigraph():
        graph = _convert_multigraph(G, weight, is_directed)
    else:
        graph = G.__class__()
        graph.add_nodes_from(G)
        graph.add_weighted_edges_from(G.edges(data=weight, default=1))

    inner_partition = partition
    improvement = True
    while improvement:
        m = graph.size(weight="weight")
        partition, inner_partition, improvement = _one_level(
            graph, m, inner_partition, resolution, is_directed, seed, modularity_function=modularity_function, weight=weight
        )
        # graph = _gen_graph(graph, inner_partition)
    return partition


def _one_level(G, m, partition, resolution=1, threshold=0.0000001, seed=None, modularity_function="default", weight='weight'):
    """Calculate one level of the Louvain partitions tree

    Parameters
    ----------
    G : NetworkX Graph/DiGraph
        The graph from which to detect communities
    m : number
        The size of the graph `G`.
    partition : list of sets of nodes
        A valid partition of the graph `G`
    resolution : positive number
        The resolution parameter for computing the modularity of a partition
    is_directed : bool
        True if `G` is a directed graph.
    seed : integer, random_state, or None (default)
        Indicator of random number generation state.
        See :ref:`Randomness<randomness>`.

    """
    c = {}  # get communities
    for i, community in enumerate(partition):
        for node in community:
            c[node] = i
    # inner_partition = [{u} for u in G.nodes()]
    degrees = dict(G.degree(weight=weight))
    Stot = [deg for deg in degrees.values()]
    nbrs = {u: {v: data[weight] for v, data in G[u].items() if v != u} for u in G}
    rand_nodes = list(G.nodes)
    seed.shuffle(rand_nodes)
    nb_moves = 1
    improvement = False
    mod_org = modularity(G, partition, modularity_function=modularity_function, weight=weight, resolution=resolution)
    best_mod = mod_org
    inner_partition = copy.deepcopy(partition)
    while nb_moves > 0:
        nb_moves = 0
        for u in rand_nodes:
            inner_partition[c[u]].remove(u)
            best_p = c[u]
            for p, _ in enumerate(inner_partition):
                if u not in inner_partition[p]:
                    inner_partition[p].add(u)
                    gain = modularity(G, inner_partition, modularity_function=modularity_function, weight=weight, resolution=resolution)
                    inner_partition[p].remove(u)
                    if gain > best_mod + threshold:
                        best_mod = gain
                        best_p = p
                        improvement = True
            inner_partition[best_p].add(u)

    # partition = list(filter(len, partition))
    inner_partition = list(filter(len, inner_partition))
    return partition, inner_partition, improvement


def _neighbor_weights(nbrs, node2com):
    """Calculate weights between node and its neighbor communities.

    Parameters
    ----------
    nbrs : dictionary
           Dictionary with nodes' neighbours as keys and their edge weight as value.
    node2com : dictionary
           Dictionary with all graph's nodes as keys and their community index as value.

    """
    weights = defaultdict(float)
    for nbr, wt in nbrs.items():
        weights[node2com[nbr]] += wt
    return weights


def _gen_graph(G, partition):
    """Generate a new graph based on the partitions of a given graph"""
    H = G.__class__()
    node2com = {}
    for i, part in enumerate(partition):
        nodes = set()
        for node in part:
            node2com[node] = i
            nodes.update(G.nodes[node].get("nodes", {node}))
        H.add_node(i, nodes=nodes)

    for node1, node2, wt in G.edges(data=True):
        wt = wt["weight"]
        com1 = node2com[node1]
        com2 = node2com[node2]
        temp = H.get_edge_data(com1, com2, {"weight": 0})["weight"]
        H.add_edge(com1, com2, **{"weight": wt + temp})
    return H


def _convert_multigraph(G, weight, is_directed):
    """Convert a Multigraph to normal Graph"""
    if is_directed:
        H = nx.DiGraph()
    else:
        H = nx.Graph()
    H.add_nodes_from(G)
    for u, v, wt in G.edges(data=weight, default=1):
        if H.has_edge(u, v):
            H[u][v]["weight"] += wt
        else:
            H.add_edge(u, v, weight=wt)
    return H


if __name__ == "__main__":
    print()
    A = np.array(
        [[0, 6, 6, 0, 0, 0, 0, 6, 0],
         [6, 0, 0, 6, 6, 0, 0, 0, 0],
         [9, 6, 0, 0, 1, 0, 0, 0, 2],
         [0, 5, 0, 6, 0, 0, 4, 0, 3],
         [0, 5, 5, 2, 0, 2, 2, 0, 2],
         [2, 2, 2, 2, 2, 2, 2, 2, 2],
         [0, 0, 5, 3, 3, 1, 1, 4, 1],
         [2, 0, 0, 6, 2, 0, 4, 0, 4],
         [2, 0, 5, 3, 2, 2, 0, 4, 0]]
    )
    G = nx.from_numpy_array(A)
    communities = [{0}, {1, 2, 3, 4, 5, 6, 7, 8}]
    print("NetworkX: ", modularity_nx(G, communities, weight="weight", resolution=1))
    print("Custom  : ", modularity_custom(G, communities, weight="weight", resolution=1))
