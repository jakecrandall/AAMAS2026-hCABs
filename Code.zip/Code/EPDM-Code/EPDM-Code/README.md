This folder contains code to create the hCAB-EPDM and hTFT-EPDM models

Here are steps to be able to run the code:

1.  Compile the code.  In linux or mac, you can compile the code from the terminal.  Go to the EPDM folder, then type:

    g++ EPDM.cpp -o epdm

2.  Run the code.  From the terminal, type:

    ./epdm [tft/cab] PS

    Choose tft as the second parameter to train the hTFT-EPDM parameterizations, or cab to train hCAB-EPDM parameterizations

Notes:

- When finished the parameterizations will be stored in the parameterPools folder.  The parametizations for each pool are stored in 
    successive gen_i.csv files.  The final genes are stored in gen_Z.csv.

- The pretrained parameterizations (used in the paper) for hCAB-EPDM are stored in the parameterPools_CAB-PS-1-.01 folder

- The pretrained parameterizations (used in the paper) for hTFT-EPDM are stored in the parameterPools_TFT-PS-1-.01 folder
